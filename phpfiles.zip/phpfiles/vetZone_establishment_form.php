<?php 
    include("registrationinit.php");

    $vetzone_id = $_GET["vetzone_id"];

    $findregistered = find("first","vetzone","*","where vetzone_id='$vetzone_id' and is_registered='N'",array());

    if(!$findregistered)
    {
        echo "<div style='height: 73px;background: #a9a9d747;text-align: center;padding-top: 10;'>";
        echo"<h2 style='font-family: cursive;'> You have already registered , kindly wait for approval !</h2>";
        echo"</div>";
        exit();
    }

    if(isset($_POST["submit"]))
    {
        $owner_name   = $_POST["cust_name"];
        $vetzone_name   = $_POST["vetzone_name"];
        $email = $_POST["email"];
        $mobile = $_POST["mob_no"];
        $type = $_POST["vetzone_type"];

        $setval = "name=:name,owner_name=:owner_name,email=:email,mobile_number=:mobile_number,type=:type,is_registered=:is_registered";
        $where = "where vetzone_id='$vetzone_id'";
        $exe = array(":name"=>$vetzone_name,":owner_name"=>$owner_name,":email"=>$email,":mobile_number"=>$mobile,":type"=>$type,":is_registered"=>"Y");
        $update = update("vetzone",$setval,$where,$exe);
        
        $data = $_POST;
        if($update)
        {
            foreach($data as $key=>$val)
            {
                $vetzone_meta_key	= $key;
                $vetzone_meta_value = $val;

                $fields = "vetzone_id,vetzone_meta_key,vetzone_meta_value";
                $values = ":vetzone_id,:vetzone_meta_key,:vetzone_meta_value";
                $exe = array(":vetzone_id"=>$vetzone_id,":vetzone_meta_key"=>$vetzone_meta_key,":vetzone_meta_value"=>$vetzone_meta_value);
                $savevetzonemeta = save("vetzone_meta",$fields,$values,$exe);
            }
        
            if($savevetzonemeta)
            {
                $filename =  $_FILES['file']['name'];
                $filetempname =  $_FILES['file']['tmp_name'];

                // print_r($filename);
                // exit;
                $i=0;
                foreach ($filename as $key) {

                    $fname = $filename[$i];
                    $ftname = $filetempname[$i];
                    
                    // $filenames = $name."_".$fname;
                    
                    $i++;
                    move_uploaded_file($ftname, "vetzone_kyc_documents/" . $fname);

                    $fields = "vetzone_id,document";
                    $values = ":vetzone_id,:document";
                    $exe = array(":vetzone_id" => $vetzone_id,
                                ":document" => $fname
                            );
                    $savekyc = save("vetzone_kyc_document",$fields,$values,$exe);
                    
                }

                $url = "https://vscm.vetrinahealthcare.com/PHPMailer/send_mail.php";
                    $data = array(
                            "mailto" => $email,
                            "subject" => "VetZone Registration at VetrinaHealthcare" ,
                            "fullname" => "VetZone Registration",
                            "fromname" => "Vetrina Healthcare",
                            "message" => "Dear ".$name.",<br>
                                        Thank you so much for showing interest. You are our valued customer. 
                                        <br> We will come back to you soon with your Login credentials.  
                                        Cheers !<br>
                                        For more information please contact  <a href='tel:8600844450'>8600844450.</a>"
                    );

                    $curl = curl_init($url);
                    curl_setopt($curl, CURLOPT_POST, true);
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                    $res = curl_exec($curl);
                    curl_close($curl);

                    $send_form_id = "0";
                    $send_to_id = "9";
                    $notify_text = "New Vetzone Registration Done , pending for Approval";
                    notify($send_form_id,$send_to_id,$notify_text);
            } 
        } 

    }

    $table = "vetzone as v inner join vetzone_type as vt on v.type=vt.v_type_id";
    $vetzone_type = find("all","vetzone_type","*","where 1",array());
    $findvetzone_details = find("first",$table,"*","where vetzone_id='$vetzone_id'",array());
    $findheadquarter = find("all","headquarters","*","where 1",array());
    $finddivision =  find("all","divisions","*","where 1",array());

    $vetzone_meta = find("all","vetzone_meta","*","where vetzone_id='$vetzone_id'",array());

       foreach($vetzone_meta as $key=>$val)
        {
            if($val["vetzone_meta_value"]!="")
            {
                define($val["vetzone_meta_key"],$val["vetzone_meta_value"]);
            }
            else
            {
                define($val["vetzone_meta_key"],"0");
            }
        }

        $stateid = State;
        $findstatename = find("first","state","*","where state_id='$stateid'",array());
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("registration_header.php"); ?>
        <!-----maincontent start----->
            <div class="content-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">

                            <form action="" method="POST" enctype="multipart/form-data">
                                <div class="card">
                                <div class="card-body">
                                    <br>
                                    <div class="row">
                                            <div class="col-4">
                                            <label for="">VetZone ID</label>
                                            <input type="text" name="customer_id" id="" readonly value="<?=$findvetzone_details["vetzone_id"]?>" readonly class="form-control">
                                        </div>
                                            <div class="col-4">
                                            <label for="">Name of Owner</label>
                                            <input type="text" name="cust_name" class="form-control" readonly value="<?=$findvetzone_details["owner_name"]?>" readonly id="">
                                        </div>
                                        <div class="col-4">
                                            <label for="">Email </label>
                                            <input type="email" name="email" class="form-control" readonly value="<?=$findvetzone_details["email"]?>" readonly id="">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-3">
                                            <label for="">Type</label>
                                            <select name="vetzone_type" id="" readonly class="form-control">
                                                    <?php
                                                        foreach($vetzone_type as $k=>$v) { ?>
                                                        <option <?php if($findvetzone_details["type"]==$v["v_type_id"]) { echo "selected"; }?> value="<?=$v["v_type_id"]?>"><?=$v["v_type_name"]?></option>
                                                    <?php } ?>    
                                            </select>
                                        </div>

                                        <div class="col-3">
                                            <label for="">Address l1</label>
                                            <textarea name="addressl1" id="" readonly class="form-control"><?=addressl1?></textarea>
                                        </div>

                                        <div class="col-3">
                                            <label for="">Address l2</label>
                                            <textarea name="addressl2" id="" readonly class="form-control"><?=addressl2?></textarea>
                                        </div>

                                        <div class="col-3">
                                            <label for="">Village</label>
                                            <input type="text" name="Village" id="" readonly value="<?=Village?>" class="form-control">
                                        </div>

                                    </div>    
                                    <br>
                                    <div class="row">
                                        <div class="col-3">
                                            <label for="">Taluka</label>
                                            <input type="text" name="taluka" readonly class="form-control" value="<?=taluka?>" id="">
                                        </div>
                                    
                                        <div class="col-3">
                                            <label for="">District</label>
                                            <input type="text" name="District" readonly class="form-control" value="<?=District?>" id="">
                                        </div>
                                        <div class="col-3">
                                            <label for="">State</label>
                                                <input type="text" name="State" hidden readonly class="form-control" value="<?=State?>" id="">
                                                <input type="text" name="statename" class="form-control" value="<?=$findstatename["state_name"]?>" id="">

                                        </div>

                                        <div class="col-3">
                                            <label for="">Pincode</label>
                                                <input type="text" name="Pin_code" readonly class="form-control" value="<?=Pin_code?>" id="">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                    
                                        <div class="col-4">
                                            <label for="">Mobile Number</label>
                                            <input type="number" name="mob_no" readonly class="form-control" value="<?=$findvetzone_details["mobile_number"]?>" id="">
                                        </div>

                                        <div class="col-4">
                                            <label for="">Total Milk Collection</label>
                                            <input type="text" value="<?=total_milk_collection?>" readonly name="total_milk_collection" class="form-control" id="">
                                        </div>

                                        <div class="col-4">
                                            <label for="">Total Number of MCC </label>
                                            <input type="text" value="<?=total_number_MCC?>"  readonly name="total_number_MCC" class="form-control" id="">
                                        </div>
                                        
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-4">
                                            <label for="">Headquarter</label>
                                                <select name="hq" class="form-control" id="hq">
                                                <option value="">Select Headquarter</option>
                                                <?php foreach($findheadquarter as $k=>$v) { ?>
                                                    <option <?php if(hq==$v["hq_id"]) { echo "selected"; }?> readonly value="<?=$v["hq_id"]?>"><?=$v["hq_name"]?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="col-4">
                                            <label for="">Division</label>
                                            <select name="division" class="form-control" id="divsion" onchange="getmanagers(this.value)">
                                                <option value="">Select division</option>
                                                <?php foreach($finddivision as $k=>$v) { ?>
                                                    <option <?php if(division==$v["division_id"]) { echo "selected"; }?> value="<?=$v["division_id"]?>"><?=$v["division_name"]?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-4">
                                            <label for="">Name of VetZone</label>
                                            <input type="text" name="vetzone_name" value="<?=$findvetzone_details["name"]?>" readonly class="form-control" value="" id="">
                                        </div>
                                        <div class="col-4">
                                            <label for="">Address of VetZone</label>
                                            <input type="text" name="vetzone_address" value="<?=vetzone_address?>" readonly class="form-control" id="">
                                        </div>
                                        <div class="col-4">
                                            <label for="">Alternate Contact Number</label>
                                            <input type="text" name="alternate_contact_number" value="<?=alternate_contact_number?>" readonly class="form-control" id="">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-4">
                                            <label for="">Establishment Date</label>
                                            <input type="date" name="establishment_date" value="<?=establishment_date?>" readonly class="form-control" id="">
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row">
                                        <strong><u>KYC & Documents </u> (Upload scan copy of Authorized person,  Proprietor/ Partner/ Director etc. as well as firm)  </strong>
                                        <br>
                                        <label class="label label-danger">Note * : upload documents with customer name_filename (mahesh_adharcard)</label>
                                    </div>

                                    <div class="row mt-4">
                                        <div class="col-4">
                                            <label for="">Address Proof - (Driving Licence/ Aadhar card/ Light bill/Pass Port etc)</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file" accept="application/pdf" name="file[]" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <label for="">Address Proof (VetZone)</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file"  accept="application/pdf" name="file[]" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-4">
                                            <label for="">Pan card</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file"  name="file[]" accept="application/pdf" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mt-4">
                                        <div class="col-4">
                                            <label for="">Aadhar Card</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file"  name="file[]" accept="application/pdf" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-4">
                                            <label for="">Photo</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file"  name="file[]" accept="image/*" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-4">
                                            <label for="">VetZone Shop Photo</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file"  name="file[]" accept="image/*" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                        
                                    <div class="row mt-4">

                                        <div class="col-4">
                                            <label for="">Shot Act Liecence</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file"  name="file[]" accept="application/pdf" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-4">
                                            <label for="">VetZone Deposite (Upload payment receipt and details)</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file"  accept="application/pdf" name="file[]" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                    
                                        <?php if($findvetzone_details["type"]=="1") { ?>
                                        <div class="col-4">
                                            <label for="">Rent Agreement</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file"  name="file[]" accept="application/pdf" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                    
                                    <br>

                                    <div class="row mt-4">
                                        <div class="col-4">
                                            <label for="">Cheque</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file"  name="file[]" accept="application/pdf" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-4">
                                            <label for="">Other Document</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file"  name="file[]" accept="application/pdf" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <?php if($findvetzone_details["type"]=="5") { ?>
                                     <div class="row mt-4">

                                        <div class="col-4">
                                            <label for="">VetZone Registration fees</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file"  name="file[]" accept="application/pdf" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-4">
                                            <label for="">Furniture Amount</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">Upload</span>
                                                </div>
                                                <div class="custom-file">
                                                    <input type="file"  accept="application/pdf" name="file[]" class="custom-file-input">
                                                    <label class="custom-file-label">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                    
                                        <?php } ?>
                                    </div>

                                    <br>
                                        
                                    <div class="row mt-3">
                                        <input type="checkbox" name="" onclick="acceptTerms()" id="terms"> &nbsp;&nbsp; I Accept all terms and conditions. <br>
                                    </div>
                                    <div class="row mt-3">
                                        <button type="submit" id="submitbtn" disabled name="submit" class="btn btn-success btn-lg shadow">Submit</button>
                                    </div>
                                        
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <!-------main content end----->
<?php include("footer.php"); ?>
    </div>
<?php include("jslink.php"); ?>
    <script>
        <?php if($savekyc) { ?>

            swal("Thank you so much for showing interest."," You are our valued customer.We will come back to you soon with your Login credentials","success");

        <?php } ?>

        function acceptTerms()
            {
                if($("#terms:checked")){
                    $('#submitbtn').removeAttr('disabled'); 
                    $('#submitbtn').css('backgroundcolor','#2bc155');
                }
                else
                {
                    $('#submitbtn').attr('disabled','true'); 
                }
               
            }
    </script>
</body>
</html>
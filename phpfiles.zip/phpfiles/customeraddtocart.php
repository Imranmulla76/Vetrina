<?php 
    include("../init.php");
    $response["status"]="error";
    $response["msg"]="Something went wrong, Try again later";

    // $_SESSION["product_id"][] = $_POST["product_id"];
    // $_SESSION["order_qnty"][] = $_POST["order_qnty"];
    // $_SESSION["scheme"][] = $_POST["scheme"];

    // print_r($_SESSION["order_id"]);

    if(!isset($_SESSION["order_id"]))
    {
        $fld= "created_date,status,is_invoiced,is_placed_order,user_id,user_role";
        $vlue= ":created_date,:status,:is_invoiced,:is_placed_order,:user_id,:user_role";
        $exe= array(":created_date"=>date("Y-m-d H:i:s"),":status"=>"P",":is_invoiced"=>"N",":is_placed_order"=>"N",":user_id"=>$_SESSION["user_id"],":user_role"=> $_SESSION["role"]);
        $saveorder = save("customer_placeorder",$fld,$vlue,$exe);
        $order_id = $saveorder;
        $_SESSION["order_id"]= $order_id;
    }
    else
    {
        $order_id = $_SESSION["order_id"];
    }
    
    if(isset($_POST["supplier_id"]))
    {
        $supplier_id = $_POST["supplier_id"];
        $getrole = find("first","customer as c inner join customer_roles as cr on c.role=cr.cust_role_id","*","where customer_id='$user_id'",array());
        $user_role = $getrole["role_name"];
    }
    else {

        $supplier_id = $_SESSION["user_id"];
        $user_role = $_SESSION["role"];
    }
    
    $product_id =  $_POST["product_id"];
    $quantity = $_POST["order_qnty"];
    $customer_id = $_POST["customer_id"];
    $batch = $_POST["batch"];
    $mrp = "";
    $ffld= "order_id,product_id,batch,rate,disc,tax,mrp,rate_mode,quantity,customer_id,seller_user_id,seller_user_role,status,created_at"; 
    $vvld= ":order_id,:product_id,:batch,:rate,:disc,:tax,:mrp,:rate_mode,:quantity,:customer_id,:seller_user_id,:seller_user_role,:status,:created_at";
    $eeld= array(":order_id"=>$order_id,":product_id"=>$product_id,":batch"=>$batch,":rate"=>$rate,":disc"=>"",":tax"=>"",":mrp"=>$mrp,":rate_mode"=>$rate_mode,":quantity"=>$quantity,"customer_id"=>$customer_id,":seller_user_id"=>$supplier_id,":seller_user_role"=>$user_role,":status"=>"Y",":created_at"=>date("Y-m-d H:i:s"));
    $save = save("customer_order_table_product",$ffld,$vvld,$eeld);
    if($save)
    {
        $response["status"]="success";
        $response["msg"]= "Wow! Product added in your cart.";
    }

    echo json_encode($response);
?>
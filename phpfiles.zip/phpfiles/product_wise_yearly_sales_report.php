<?php 
    include("init.php");

    $admin_id = $_SESSION["user_id"];

    $year = date("Y");
    $table = "order_table_product as otp inner join product as p on otp.product_id=p.product_id";
    $get_product_sale = find("all",$table,"*, sum(quantity) as qnty","where YEAR(created_at)=$year group by otp.product_id",array());
   

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
       <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <b class="card-title">Product wise Monthly Sales</b>
                            </div>
                            <div class="card-body">
                            
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                       <thead>
                                            <tr>
                                                <td>Sr.No</td>
                                                <td>Product Name</td>
                                                <td>Unit</td>
                                                <td>Year <?=$year?> Qunatity</td>
                                            </tr>
                                       </thead>
                                       <tbody>
                                        <?php 
                                            $i=0;
                                            foreach($get_product_sale as  $k=>$v) 
                                            { $i++; 
                                        ?>
                                        <tr>
                                            <td><?=$i?></td>
                                            <td><?=$v["product_name"]?></td>
                                            <td><?=$v["unit"]?></td>
                                            <td><?=$v["qnty"]?></td>
                                        </tr>
                                        <?php } ?>
                                       </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
        <script>

        $(function(){
            $('#tasklist').DataTable({
            "lengthMenu": [10, 100, 500, 1000, 10000],
			"responsive": true,
			"processing": true,
			"serverSide": true,
			"buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"],
			"bDestroy": true,
            });
        });

            function getreport()
            {
                var from = $("#from").val();
                var to = $("#to").val();

                $.ajax({
                    url:"ajax/product_wise_monthly_sale_report.php",
                    type:"POST",
                    data:{from:from,to:to},
                }).done(function(response){
                        $('#example3').html(response);
                    });
            }
        </script>
</body>
</html>
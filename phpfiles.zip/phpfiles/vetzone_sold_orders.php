<?php 
    include("init.php");

    // $table = "order_table_product as otp inner join placeorder as p otp.order_id=p.stockiest_order_id";
    $user_id = $_SESSION["user_id"]; 
    $role = $_SESSION["roll"]; 
   
    $table = "customer_placeorder as cp inner join vetzone as c on cp.user_id=c.vetzone_id inner join customer_order_table_product as cotp on cp.customer_order_id=cotp.order_id inner join vetzone_end_customer as vec on cotp.customer_id=vec.end_customer_id";
   
    if(isset($_POST["action"]))
    {

        // Order Approval

        if($_POST["action"]=="Approve")
    {
        $order_id = $_POST["order_id"];
        
        $findcust = find("first","customer_placeorder","*","where customer_order_id='$order_id' and user_role='VetZone'",array());
        $customer_id = $findcust["user_id"];
        
        $product_id = $_POST["product_id"];
        $batch = $_POST["batch"];
        $rates = $_POST["rate"];
        $mrps = $_POST["mrp"];

            foreach($product_id as $key=>$val)
            {
                $prod = $product_id[$key];
                $batchs = $batch[$key];
                $rate = $rates[$key];
                $mrp = $mrps[$key];

                $setval = "batch=:batch,mrp=:mrp,rate=:rate";
                $wh = "where order_id='$order_id' and product_id='$prod'";
                $exe = array(":batch"=>$batchs,":rate"=>$rate,":mrp"=>$mrp);

                // print_r($exe);
                // exit;
                
                $updateorder = update("customer_order_table_product",$setval,$wh,$exe);
            }
    }

    //Decline

    if($_POST["action"]=="Decline")
    {
        $order_id = $_POST["order_id"];
        $setval = "status=:status";
        $where = "where customer_order_id='$order_id'";
        $exe = array(":status"=>"N");
        $cancelorder = update("customer_placeorder",$setval,$where,$exe);

        if($cancelorder)
        {
             $getcustomer_id = find("first","customer_placeorder","*","where customer_order_id='$order_id'",array());
            $customer_id = $getcustomer_id["user_id"];
            $comment = $getcustomer_id["comment"];

            $send_form_id = $user_id;
			$send_to_id = $customer_id;
			$notify_text = "<a href='my_orders.php'>Your order is cancelled . <br> <b> Reason : ". $comment ."</b></a>";
			cust_notify($send_form_id,$send_to_id,$notify_text);
        }
    }
}

    if(isset($_POST["savelrnumber"]))
    {
        $order_id = $_POST["order_id"];
        $lrno = $_POST["lrno"];
        $filename = $_FILES['file']["name"];
        $filetempname = $_FILES['file']['tmp_name'];

        $fields = "lrno,order_id,file";
        $values = ":lrno,:order_id,:file";
        $exe = array(":lrno"=>$lrno,":order_id"=>$order_id,":file"=>$filename);
        $savelrdetails = save("customer_lr_details",$fields,$values,$exe);

        if($savelrdetails)
        {
            move_uploaded_file($filetempname, "customer_lr_reciepts/" . $filename);

            $setval = "status=:status,is_invoiced=:is_invoiced";
            $wh = "where customer_order_id='$order_id'";
            $exe = array(":status"=>"Y",":is_invoiced"=>"Y");
            $update = update("customer_placeorder",$setval,$wh,$exe);
        }   

    }

    $orders = find("all",$table,"* , cp.status as cpstatus , vec.name as vcname","where is_placed_order='Y' and cotp.seller_user_id='$user_id' group by cotp.order_id order by cp.customer_order_id desc",array());

?>
<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table bordered id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Customer Name</th>
                                                <th>Customer Role</th>
                                                <th>Order Date</th>
                                                <th>Status</th>
                                                <!-- <th>Dispatch Date</th> -->
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                
                                                $i=0; foreach($orders as $key=>$val) { $i++;
                                                $order_date = $val["created_date"];
                                                $date = date("d-m-Y",strtotime($order_date));
                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["vcname"]?></td>
                                                <td><?=$val["user_role"]?></td>
                                                <td><?=$date?></td>
                                                <td>
                                                <?php if($val["status"]=="P") {
                                                        echo "<label class='label label-warning'>Pending</label>";
                                                    }
                                                    else if($val["status"]=="N")
                                                    {
                                                        echo "<label class='label label-danger'>Cancelled</label>";
                                                    }
                                                    else if($val["status"]=="Y")
                                                    {
                                                        echo "<label class='label label-success'>Order Dispatched</label>";
                                                    }
                                                    else if($val["status"]=="I")
                                                    {
                                                        echo "<label class='label label-info'>In Process</label>";
                                                    }
                                                    else if($val["status"]=="D")
                                                    {
                                                        echo "<label class='label label-success'>Dilivered</label>";
                                                    }
                                                    ?>
                                                </td> 
                                                <!-- <td>
                                                    <?php 

                                                      //  $disdate = date("d-m-Y  H:i",strtotime($val["on_date"]));
                                                    ?>                                                     
                                                </td> -->
                                                <td>
                                                     <div class="d-flex">
                                                        <form action="" method="POST">
                                                            <input type="text" name="order_id" hidden value="<?=$val["customer_order_id"]?>" id="">
                                                            <span type="submit" name="view_details" onclick="view_order_details('<?=$val['customer_order_id']?>')"  class="btn btn-info shadow btn-xs sharp"><i class="fa fa-eye"></i></span>
                                                        </form>
                                                        <?php if($role=="14") { ?>
                                                            <span onclick="editorders(<?=$val['customer_order_id']?>)" class="btn btn-primary shadow btn-xs sharp mr-2"><i class="fa fa-pencil"></i></span>
                                                        <?php } ?>
                                                    </div>
                                                </td>
                                                
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>        
                            </div>
                        </div>            
                    </div>            
                </div>            
            </div>            
        </div>            
        <!-------main content end----->
        

         <!-- Order Modal -->
    <div class="modal fade ordersdetails" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Order Details</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST">
                    <div class="modal-body" id="order_details">
                        
                        
                    </div>
                    <!-- <div class="modal-footer">
                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                        <select name="action" id="" class="form-control"> 
                            <option value="Approve">Approve</option>
                            <option value="Decline">Decline</option>
                        </select>
                        <button type="submit" class="btn btn-primary" name="approve">Submit</button>
                     
                    </div> -->
                </form>
            </div>
        </div>
    </div>

    <!-- order Modal -->

    <!-- Lr Details Modal -->
    <div class="modal fade lrdetails" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header"> 
                    <h5 class="modal-title">LR Details</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <form action="" method="POST" enctype="multipart/form-data">
                    
                    <div class="modal-body" id="lrdetails">
                        
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" name="savelrnumber">Save LR Details</button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <!-- Lr Details Modal -->

        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

        <script>

            function view_order_details(order_id)
            {
                $(".ordersdetails").modal("show");

                $.ajax(
                {
                     url:"ajax/get_customer_order_details.php",
                     method:"POST",
                     data:{order_id:order_id}

                }).done(function(response){
                    $("#order_details").html(response);
                });
            }

            function getmrprate(product_id,batch,row)
            {
                $.ajax({
                    url:"ajax/getitemrates.php",
                    method:"POST",
                    data:{product_id:product_id, batch:batch, row:row }
                }).done(function(response){
                     var data = JSON.parse(response);
                     $("#mrp"+row).val(data['mrp']);
                     $("#rate"+row).val(data['rate']);
                });
            }

            function editorders(order_id)
            {
                $(".lrdetails").modal("show");

                $.ajax({
                    url:"ajax/lrdetails.php",
                    method:"POST",
                    data:{ order_id:order_id }
                }).done(function(response){
                    $("#lrdetails").html(response);
                });

                // $("#order_id").val(order_id);
            }

        </script>
    </body>
</html>
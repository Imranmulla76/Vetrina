<?php

$vetzone_id = $_SESSION["user_id"];

if(date("m") > 3)
{
    $fyear = date("Y").'/04/01  - '.(date("Y")+1).'/03/31';
    $from_dt = date("Y").'-04-01';
    $to_dt = (date("Y")+1).'-03-31';
}
else
{
    $from_dt = (date("Y")-1).'-04-01';
    $to_dt = date("Y").'-03-31';
}

//Avg Sale per month
$where = "where seller_user_id = $vetzone_id and seller_user_role = 'VetZone' and created_at between '$from_dt' and '$to_dt' group by month(created_at);";
$avgSaleQry =  find("all", "customer_order_table_product", "sum(rate * quantity) monthlySale", $where, array());

$count = sizeof($avgSaleQry);
$totalSale = 0;

foreach($avgSaleQry as $key => $val)
{
    $totalSale += $val['monthlySale'];
}
$avgSale = $totalSale / $count;

//Avg Sale per Customer
$where = "where seller_user_id = $vetzone_id and seller_user_role = 'VetZone' and created_at between '$from_dt' and '$to_dt' group by customer_id;";
$avgCustSaleQry =  find("all", "customer_order_table_product", "sum(rate * quantity) custwiseSale", $where, array());

$count = sizeof($avgCustSaleQry);
$totalSale = 0;

foreach($avgCustSaleQry as $key => $val)
{
    $totalSale += $val['custwiseSale'];
}
$avgCustSale = $totalSale / $count;

//Total Number of Customers
$totalCustQry = find("first", "customer_order_table_product", "count(distinct customer_id) total", "", array());
$totalEndCustQry = find("first", "vetzone_end_customer", "count(end_customer_id) total", "where created_by_user_id = $vetzone_id", array());
$totalCust = $totalCustQry['total'] + $totalEndCustQry['total'];

//Cumulative Sale
$where = "where seller_user_id = $vetzone_id and seller_user_role = 'VetZone' and created_at between '$from_dt' and '$to_dt'";
$cumulativeSaleQry = find("first", "customer_order_table_product", "sum(rate * quantity) cumulativeSale", $where, array());
$cumulativeSale = $cumulativeSaleQry['cumulativeSale'];

//Total Inventory Value
$instock = find("first", "vetzone_instock", "sum(ptv * quantity) inventoryValue", "where created_by = $vetzone_id", array());
$sold = find("first", "customer_order_table_product", "sum(rate * quantity) inventoryValue", "where seller_user_id = $vetzone_id and seller_user_role = 'VetZone' and created_at between '$from_dt' and '$to_dt'", array());

$totalInventoryValue = $instock['inventoryValue'] - $sold['inventoryValue'];

?>


<div class="content-body">
    <!-- row -->
    <div class="container-fluid">        
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="card avtivity-card">
                            <div class="card-body">
                                <div class="media align-items-center">
                                    <span class="activity-icon bgl-success mr-md-4 mr-3">
                                        <img src="images/commission.png" alt="" width="40" height="40">
                                    </span>
                                    <div class="media-body">
                                        <p class="fs-14 mb-2">Avg. Sale Per Month</p>
                                        <span class="title text-black font-w600">Rs. <?=$avgSale;?>/-</span>
                                    </div>
                                </div>
                                <div class="progress" style="height:5px;">
                                    <div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="effect bg-success"></div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="card avtivity-card">
                            <div class="card-body">
                                <div class="media align-items-center">
                                    <span class="activity-icon bgl-secondary  mr-md-4 mr-3">
                                        <img src="images/commission.png" alt="" width="40" height="40">
                                    </span>
                                    <div class="media-body">
                                        <p class="fs-14 mb-2">Avg. Sale Per Customer</p>
                                        <span class="title text-black font-w600"><?=$avgCustSale?>/-</span>
                                    </div>
                                </div>
                                <div class="progress" style="height:5px;">
                                    <div class="progress-bar bg-secondary" style="width: 100%; height:5px;" role="progressbar">
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="effect bg-secondary"></div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="card avtivity-card">
                            <div class="card-body">
                                <div class="media align-items-center">
                                    <span class="activity-icon bgl-danger mr-md-4 mr-3">
                                        <img src="images/commission.png" alt="" width="40" height="40">
                                    </span>
                                    <div class="media-body">
                                        <p class="fs-14 mb-2">Total Number of Customers</p>
                                        <span class="title text-black font-w600"><?=$totalCust;?></span>
                                    </div>
                                </div>
                                <div class="progress" style="height:5px;">
                                    <div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="effect bg-danger"></div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="card avtivity-card">
                            <div class="card-body">
                                <div class="media align-items-center">
                                    <span class="activity-icon bgl-danger mr-md-4 mr-3">
                                        <img src="images/commission.png" alt="" width="40" height="40">
                                    </span>
                                    <div class="media-body">
                                        <p class="fs-14 mb-2">Cumulative Sale</p>
                                        <span class="title text-black font-w600">Rs. <?=$cumulativeSale;?>/-</span>
                                    </div>
                                </div>
                                <div class="progress" style="height:5px;">
                                    <div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="effect bg-danger"></div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="card avtivity-card">
                            <div class="card-body">
                                <div class="media align-items-center">
                                    <span class="activity-icon bgl-danger mr-md-4 mr-3">
                                        <img src="images/commission.png" alt="" width="40" height="40">
                                    </span>
                                    <div class="media-body">
                                        <p class="fs-14 mb-2">Total Inventory Value</p>
                                        <span class="title text-black font-w600">Rs. <?=$totalInventoryValue;?>/-</span>
                                    </div>
                                </div>
                                <div class="progress" style="height:5px;">
                                    <div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="effect bg-danger"></div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
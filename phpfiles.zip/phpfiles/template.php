<?php include("init.php");
        //check_login();
        $role = $_SESSION["roll"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <?php ?>
        <?php if($role == "1")
        {
            include("admin_dashboard.php"); 
        }
        else if($role=="3")
        {
            include("nsm_dashboard.php");
        }
        else if($role=="4")
        {
            include("zsm_dashboard.php");
        }
        else if($role=="5")
        {
            include("asm_dashboard.php");
        }
        else if($role=="6")
        {
            include("vso_dashboard.php");
        }
        else if($role=="7")
        {
            include("voe_dashboard.php");
        }
        else if($role=="8")
        {
            include("com_dashboard.php");
        }
        else if($role=="9")
        {
            include("finance_dashboard.php");
        }
        else if($role=="11")
        {
            include("ceo_dashboard.php");
        }
         else if($role=="14")
        {
            include("coe_dashboard.php");
        }
         
        ?>
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
</body>
</html>
<?php

include("init.php");
// print_r($_SESSION);exit;
$roles = $_SESSION['role'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    <link rel="stylesheet" href="./vendor/select2/css/select2.min.css">

</head>
<body>

<?php include("preloader.php") ?>

<div id="main-wrapper">
    <?php include("navbar.php"); ?>
    <?php include("chatbox.php"); ?>
    <?php include("header.php"); ?>
    <?php include("sidebar.php"); ?>
    <!-----maincontent start----->
    <div class="content-body">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="cnreport" class="display min-w850">

                                    <thead>                                        
                                        <tr>
                                            <th>Sr.No</th>
                                            <th>return_id</th>
                                            <?php
                                            if($roles == "COM  (Commercial Operation Manager)")
                                            {
                                            ?>
                                            <th>Customer Id</th>
                                            <th>Customer</th>
                                            <?php
                                            }
                                            else if($roles == "VOE (VetZone Operation Executive)")
                                            {
                                            ?>
                                            <th>Vetzone Id</th>
                                            <th>VetZone</th>
                                            <?php } ?>
                                            <th>Product Id</th>
                                            <th>Product</th>
                                            <th>SKU</th>
                                            <th>Batch</th>
                                            <th>Quantity</th>
                                            <th>NetRate</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td> 
                                            <td></td>
                                            <td></td>
                                            <td></td>                                      
                                        </tr>
                                        
                                    </tbody>

                                    <tfoot>
                                        <tr>                                            
                                        </tr>
                                    </tfoot>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-------main content end----->
<?php include("footer.php"); ?>
</div> 
<?php include("jslink.php"); ?>


<script>

$(document).ready(function () {
    getreport();
    /* alert("function called");
    $.ajax({ 
        url: "ajax/get_cnreport.php",
        type: "POST",
        data: { 
            action : 'getcnreport',
        },
        success: function(data) {
            alert(data);
            }
    }); */
});

function getreport()
{  
    carttable = $("#cnreport").DataTable({
        responsive: true,
        dom: 'lfrtip',

        "ajax":
			  {
			  	'url' : 'ajax/get_cnreport.php',
				'type': 'POST',
				'data': {
						 action : 'getcnreport',
						},
				
			  },        

        columnDefs: [
            {
                render: function (data, type, row) {
                    // return '<a class = "nav-danger" onclick = "removeproduct('+row[1]+');" id = "remove"> - Remove </a>';
                    return '<select name="action" id="action" onchange="getValue('+row[1]+', this.value);"> <option>Select</option> <option value="RU">Reuse</option> <option value="RP">Reprocess</option> <option value="RO">Right off</option> </select>'
                },
                targets: -1,
            },

            { 
                visible: false, 
                targets: [1,2,4] 
            },
        ],

        destroy : true,
        
    });    

    // carttable.destroy();

}


function getValue(returnid, act)
{
    alert("function called " + returnid + "value : " + act);
    $.ajax({ 
        url: "ajax/get_cnreport.php",
        type: "POST",
        data: { 
            action : 'approval',
            returnid : returnid,
            act : act,
        },
        success: function(data) {
            alert(data);
            }
    });
}

</script>

</body>
</html>
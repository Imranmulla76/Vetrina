<?php include("init.php");?>
<div class="deznav">
    <div class="deznav-scroll">
		<ul class="metismenu" id="menu">
			<!--  Admin  -->
                <?php if($_SESSION["roll"]==1 && $_SESSION["role"]=="Admin") { ?>
					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-folder-14"></i>
							<span class="nav-text">Master</span>
						</a>
                        <!-- <ul aria-expanded="false">
							<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
								<i class="flaticon-381-add-3"></i>
								<span class="nav-text">Create</span>
								</a> -->
								<ul aria-expanded="false">
									<li><a href="create_designation.php">Create Designation / Position</a></li>
									<li><a href="create_headquarter.php">Create Headquarter</a></li>
									<li><a href="create_users.php">Create User</a></li>
									<li><a href="create_division.php">Create Division</a></li>
									<li><a href="create_category.php">Create Category</a></li>
									<li><a href="create_product.php">Create Product</a></li>
									<li><a href="create_supplier.php">Create Supplier</a></li>
									<li><a href="create_vetzone_type.php">Create Type of VetZone</a></li>
									<li><a href="create_pricing.php">Create Sales Pricing structure</a></li> 
									<li><a href="create_product_catalogue.php">Upload Product Catalogue</a></li>
									<li><a href="create_vetzone_broucher.php">Upload VetZone Brochure</a></li>
									<li><a href="create_target.php">Create Target</a></li>
								</ul>
							<!-- </li>
						</ul> -->
                    </li> 

					<li>
						<a class="" href="approvals.php" aria-expanded="false">
							<i class="flaticon-381-success"></i>
							<span class="nav-text">Approvals</span>
						</a>
					</li>
					
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-user-9"></i>
							<span class="nav-text">Customers List</span>
						</a>
						<ul aria-expanded="false">
				   			<li><a href="customers.php">Customers</a></li>
				   			<li><a href="vetzones.php">VetZones</a></li>
						</ul>
					</li>
					
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Purchase Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="admin_reports/division_wise_purchase_report.php">Division Wise Purchase Report</a></li>
										<li><a href="admin_reports/supplier_wise_purchase_report.php">Supplier Wise Purchase Report</a></li>
										<li><a href="admin_reports/product_wise_batch_wise_purchase_report.php">Product wise ,Batch Wise purchase report </a></li>
										<li><a href="admin_reports/cumulative_purchase_report.php">Cumulative Purchase Report </a></li>
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Sale Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">										
										<li><a href="admin_reports/hQ_wise_sale_report.php">HQ wise  Sale Report </a></li>										
										<li><a href="admin_reports/hQ_product_wise_sale_report.php">HQ Product wise  Sale Report </a></li>
										<li><a href="admin_reports/hQ_party_invoicewise_sale_report.php">HQ Party Invocie Wise Sale Report </a></li>
										<li><a href="admin_reports/hQ_party_productwise_sale_report.php">HQ Party Product Wise Sale Report </a></li>
										<li><a href="admin_reports/partywise_productwise_batch_wise_sale_report.php">Party Wise Batchwise Product Wise Sale Report </a></li>
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-edit"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								
								<ul aria-expanded="false">
									<ul aria-expanded="false">										
										<li>
											<a class="has-arrow ai-icon" href="#" aria-expanded="false">
												<i class="flaticon-381-menu-3"></i>
												<span class="nav-text">Vetrina</span>
											</a>
											<ul aria-expanded="false">
												<li><a href="admin_reports/Inventory_Stock_Sales_report.php">Inventory Stock Sales Report</a></li>
												<li><a href="admin_reports/material_sale_report.php">Material Sale Report</a></li>
												<li><a href="admin_reports/productwise_batchwise_inventory_report.php">Product wise Batch wise Inventory Report</a></li>
												<li><a href="admin_reports/expiry_report.php">Expiry Report</a></li>
												<li><a href="admin_reports/product_moment_report.php">Product moment Report </a></li>
											</ul>										
										</li>
										<li>
											<a class="has-arrow ai-icon" href="#" aria-expanded="false">
												<i class="flaticon-381-menu-3"></i>
												<span class="nav-text">Vetrina Godown</span>
											</a>
											<ul aria-expanded="false">
												<li><a href="admin_reports/godown_stock_sales_report.php">Stock inward outward Report</a></li>
												<li><a href="admin_reports/godown_productwise_batchwise_inventory.php">Product wise Batch wise Inventory Report</a></li>
												<li><a href="admin_reports/godown_expiry_report.php">Expiry Report</a></li>
												<li><a href="admin_reports/product_moment_report.php">Product moment Report </a></li>
											</ul>
										</li>
										<li>
											<a class="has-arrow ai-icon" href="#" aria-expanded="false">
												<i class="flaticon-381-menu-3"></i>
												<span class="nav-text">C & F</span>
											</a>
											<ul aria-expanded="false">
												<li><a href="admin_reports/c&f_stock_sale_inventory_report.php">Stock Sales Report</a></li>
												<li><a href="admin_reports/c&f_material_sale_report.php">Material Sale Report</a></li>
												<li><a href="admin_reports/c&f_product_wise_batchwise_inventory_report.php">Product wise Batch wise Inventory Report</a></li>
												<li><a href="admin_reports/c&f_expiry_report.php">Expiry Report</a></li>
												<li><a href="admin_reports/product_moment_report.php">Product moment Report </a></li>
											</ul>
										</li>
										<li>
											<a class="has-arrow ai-icon" href="#" aria-expanded="false">
												<i class="flaticon-381-menu-3"></i>
												<span class="nav-text">Vetzone</span>
											</a>
											<ul aria-expanded="false">
												<li><a href="admin_reports/vetzone_stock_sale_inventory_report.php">Stock Sales Report</a></li>
												<li><a href="admin_reports/vetzone_material_sale_report.php">Material Sale Report</a></li>
												<li><a href="admin_reports/vetzone_productwise_batchwise_inventory_report.php">Product wise Batch wise Inventory Report</a></li>
												<li><a href="admin_reports/vetzone_expiry_report.php">Expiry Report</a></li>
												<li><a href="admin_reports/product_moment_report.php">Product moment Report </a></li>
											</ul>
										</li>
									</ul>
								</ul>
							</li>
						</ul>
						
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-ring"></i>
							<span class="nav-text">Notifications</span>
						</a>
						<ul aria-expanded="false">
							<li><a href="notification.php">Notifications</a></li>
							<li><a href="send_notification.php">Send Notifications</a></li>
						</ul>
					</li>

					<?php } ?>

					<!-- //Admin  -->

					<!-- //ASM   -->

                   <?php if($_SESSION["roll"]==5 && $_SESSION["role"]=="ASM (Area Sales Manager)") { ?>

					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>

					
					
					 <li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sales</span>
						</a>
						<ul aria-expanded="false">
							<ul aria-expanded="false">
								<li><a href="sales.php">Sales</a></li>
								<li><a href="quaterly_sales.php">Quaterly Sales</a></li>
								<li><a href="sales_plan.php">Sales Plan</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-calculator"></i>
							<span class="nav-text">Collection</span>
						</a>
						<ul aria-expanded="false">
							<ul aria-expanded="false">
								<li><a href="collection_dashboard.php">Collection Plan</a></li>
								<li><a href="weekly_collection.php">Weekly Collection Plan</a></li>
							</ul>
						</ul>
					</li>	


					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Sale Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="asm_reports/headquarterwise_partywise_sales_report.php">Headquarter wise Party wise Sale Report</a></li>
										<li><a href="asm_reports/headquarterwise_productwise_sales_report.php">Headquarter wise Productwise Sales report</a></li>
										<li><a href="asm_reports/product_wise_sales_report.php">Product wise Sale Report</a></li>
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="asm_reports/partywise_stock & sales_report.php">Party wise Stock & Sales Reports </a></li>
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a href="#" aria-expanded="false">
									<i class="flaticon-381-edit"></i>
									<span class="nav-text">C N Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="asm_reports/party_wise_CN & DN_report.php">Party wise CN & DN Repot</a></li>
									</ul>
								</ul>
							</li>
						</ul>
						
					</li>

					<li>
						<a class="" href="notification.php" aria-expanded="false">
							<i class="flaticon-381-ring"></i>
							<span class="nav-text">Notifications</span>
						</a>
					</li>

					<?php } ?>

				<!-- / ASM  -->
				<!-- //ZSM   -->

                   <?php if($_SESSION["roll"]==4 && $_SESSION["role"]=="ZSM (Zonal Sales Manager)") { ?>

					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>

					
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sales</span>
						</a>
						<ul aria-expanded="false">
							<ul aria-expanded="false">
								<li><a href="sales.php">Sales</a></li>
								<li><a href="zsm_reports/quarterly_sales.php">Quaterly Sales</a></li>
								<li><a href="sales_plan.php">Sales Plan</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-calculator"></i>
							<span class="nav-text">Collection</span>
						</a>
						<ul aria-expanded="false">
							<ul aria-expanded="false">
								<li><a href="collection_dashboard.php">Collection Plan</a></li>
								<li><a href="weekly_collection.php">Weekly Collection Plan</a></li>
							</ul>
						</ul>
					</li>


					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Sale Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="zsm_reports/asm_wise_sales_report.php">ASM Wise,Hq Wise Sales</a></li>
										<li><a href="zsm_reports/asm_wise_vetzone_wise_product_wise_sales.php">ASM wise ,VetZone wise Productwise Sales Report</a></li>
										<li><a href="zsm_reports/vetzone_wise_sales_report.php">VetZone wise Sales Report</a></li>
										<li><a href="zsm_reports/asm_wise_hq_wise_product_wise_report.php">ASM wise HQ Wise Product wise Sales Report</a></li>
										<li><a href="zsm_reports/vetzone_wise_product_wise_report.php">VetZone wise Productwise Sales Report</a></li>										
									</ul>
								</ul>
							</li>
						</ul>

					
						
					</li>

					<li>
						<a class="" href="notification.php" aria-expanded="false">
							<i class="flaticon-381-ring"></i>
							<span class="nav-text">Notifications</span>
						</a>
					</li>
					
					<?php } ?>

					<!-- / ZSM  -->
					 <!-- //NSM   -->

                   <?php if($_SESSION["roll"]==3 && $_SESSION["role"]=="NSM (National Sales Manager)") { ?>

					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>

					
					
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sales</span>
						</a>
						<ul aria-expanded="false">
							<ul aria-expanded="false">
								<li><a href="sales.php">Sales</a></li>
								<li><a href="nsm_reports/quarterly_sales.php">Quaterly Sales</a></li>
								<li><a href="sales_plan.php">Sales Plan</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-calculator"></i>
							<span class="nav-text">Collection</span>
						</a>
						<ul aria-expanded="false">
							<ul aria-expanded="false">
								<li><a href="collection_dashboard.php">Collection Plan</a></li>
								<li><a href="weekly_collection.php">Weekly Collection Plan</a></li>
							</ul>
						</ul>
					</li>


					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Sale Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="nsm_reports/zsm_wise_sales_report.php">ZSM Wise,Hq Wise Sales</a></li>
										<li><a href="nsm_reports/zsm_wise_vetzone_wise_product_wise_sales.php">ZSM wise ,VetZone wise Productwise Sales Report</a></li>
										<li><a href="nsm_reports/vetzone_wise_sales_report.php">VetZone wise Sales Report</a></li>
										<li><a href="nsm_reports/zsm_wise_hq_wise_product_wise_report.php">ZSM wise HQ Wise Product wise Sales Report</a></li>
										<li><a href="nsm_reports/vetzone_wise_product_wise_report.php">VetZone wise Productwise Sales Report</a></li>
									</ul>
								</ul>
							</li>
						</ul>					
					</li>

					<li>
						<a class="" href="notification.php" aria-expanded="false">
							<i class="flaticon-381-ring"></i>
							<span class="nav-text">Notifications</span>
						</a>
					</li>
					
					<?php } ?>

					<!-- / NSM  -->

					 <!-- //Finance   -->

                   <?php if($_SESSION["roll"]==9 && $_SESSION["role"]=="FM (Finance Manager)") { ?>

					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-folder-14"></i>
							<span class="nav-text">Approvals</span>
						</a>
						<ul aria-expanded="false">
				   			<li><a href="approvals.php">Customer Approvals</a></li>
				   			<li><a href="vetzone_approvals.php">VetZone Approvals</a></li>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-user-9"></i>
							<span class="nav-text">Customers List</span>
						</a>
						<ul aria-expanded="false">
				   			<li><a href="customers.php">Customers</a></li>
				   			<li><a href="vetzones.php">VetZones</a></li>
						</ul>
					</li>

					<li>
						<a class="" href="orders.php" aria-expanded="false">
							<i class="flaticon-381-box"></i>
							<span class="nav-text">Orders</span>
						</a>
					</li>		
					
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-lock"></i>
							<span class="nav-text">Credit Approval Dashboard</span>
						</a>
						<ul aria-expanded="false">
				   			<li><a href="trade_credit_approval_dashboard.php">Trade Credit Approval</a></li>
				   			<li><a href="vetzone_credit_approval_dashboard.php">VetZone Credit Approval</a></li>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-lock"></i>
							<span class="nav-text">Customer Re Conciliation</span>
						</a>
						<ul aria-expanded="false">
				   			<li><a href="customer_payments_report.php">Customer Payments</a></li>
				   			<li><a href="customer_accepted_payments.php">Accepted list of payment</a></li>
				   			<li><a href="customer_rejected_payments.php">Rejected list of Payment</a></li>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-calculator-1"></i>
							<span class="nav-text">VetZone Re Conciliation</span>
						</a>
						<ul aria-expanded="false">
				   			<li><a href="vetzone_payments_report.php">VetZone Payments</a></li>
				   			<li><a href="vetZone_accepted_payments.php">Accepted list of payment</a></li>
				   			<li><a href="vetZone_rejected_payments.php">Rejected list of Payment</a></li>
						</ul>
						
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-percentage-1"></i>
							<span class="nav-text">Commission</span>
						</a>
						<ul aria-expanded="false">
				   			<li><a href="comission.php">Commision</a></li>
				   			<li><a href="commission_payable.php">Commision Payable</a></li>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-calculator"></i>
							<span class="nav-text">Collection Dashboard</span>
						</a>
						<ul aria-expanded="false">
				   			<li><a href="collection_dashboard.php">Collection Dashboard</a></li>
				   			<li><a href="weekly_collection.php">Weekly Collection</a></li>
						</ul>
						
					</li>

					<li>
						<a class="" href="vetZone_fullnfinal.php" aria-expanded="false">
							<i class="flaticon-381-calculator-1"></i>
							<span class="nav-text">Finance Full & Final Settlement</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>

						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Sales Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="#">Trade Sales Report Month Wise</a></li>
										<li><a href="#">Trade Sales Report Division Wise</a></li>
										<li><a href="#">VetZone Sales Report</a></li>
										<li><a href="#">VetZone Wise Products Wise Sales Report</a></li>
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="finance_reports/product_wise_stock_report.php">ProductWise Stock Report</a></li>
										<li><a href="#">VetZone Wise Stock Report</a></li>
									</ul>
								</ul>
							</li>
						</ul>
				    </li>

					<li>
						<!-- <ul aria-expanded="false"> -->
							
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-calculator"></i>
									<span class="nav-text">Collection Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										
										<li><a href="#">Customer Weekly collection</a></li>
										<li><a href="#">Sale V/s Collection</a></li>
										<li><a href="#">Outstanding above 90 days</a></li>
										<li><a href="#">Commission Payable</a></li>
									</ul>
								</ul>
							
						<!-- </ul> -->
						
					</li>

					<li>
						<a class="" href="notification.php" aria-expanded="false">
							<i class="flaticon-381-ring"></i>
							<span class="nav-text">Notifications</span>
						</a>
					</li>
					
					<?php } ?>

					<!-- / Finance  -->

					 <!-- //CEO   -->

                   <?php if($_SESSION["roll"]==11 && $_SESSION["role"]=="CEO (Chief Executive Officer)") { ?>

					<li>
						<a class="" href="template.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>

					<li>
						<a class="" href="approvals.php" aria-expanded="false">
							<i class="flaticon-381-success"></i>
							<span class="nav-text">Approvals</span>
						</a>
					</li>
					
					 <li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-notepad"></i>
							<span class="nav-text">Analysis</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="reports.php">Reports</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="" href="notification.php" aria-expanded="false">
							<i class="flaticon-381-ring"></i>
							<span class="nav-text">Notifications</span>
						</a>
					</li>
					
					<?php } ?>

					<!-- / CEO  -->

					<!-- / VOE  -->

					 <?php if($_SESSION["roll"]==7 && $_SESSION["role"]=="VOE (VetZone Operation Executive)") { ?>

					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-success"></i>
							<span class="nav-text">VetZone Registration Dashboard</span>
						</a>
						<ul aria-expanded="false">
							<ul aria-expanded="false">
								<li><a href="vetzone_approvals.php">VetZone Registration List </a></li>
								<li><a href="vetZone_enquiry_list.php">VetZone Enquiry List</a></li>
								
							</ul>
						</ul>
					</li>
					
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">VetZone Installation</span>
						</a>
						<ul aria-expanded="false">
							<ul aria-expanded="false">
								<li><a href="vetZone_establishment.php">VetZone Establishment List </a></li>
								<li><a href="vetZone_list.php">VetZone List</a></li>
								
							</ul>
						</ul>
					</li>

					<li>
						<a class="" href="vetzone_orders.php" aria-expanded="false">
							<i class="flaticon-381-box"></i>
							<span class="nav-text">VetZone Orders</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">VetZone</span>
						</a>
						<ul aria-expanded="false">
							<ul aria-expanded="false">
								<li><a href="vetzone_inventory.php">VetZone Inventory </a></li>
								<li><a href="active_VetZone_List.php">Active VetZone List</a></li>
								<li><a href="vetZone_closed_list.php">Closed VetZone List</a></li>
								<li><a href="vetzone_close_request.php">Send VetZone Close Request</a></li>
							</ul>
						</ul>					
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Inventory Report</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
									    <li><a href="VetZone_wise_Quantity_wise_Stock_Report.php">VetZone wise Quantity wise  Stock Report</a></li>
										<li><a href="Vetzone_Wise_Amount_wise_Stock_Report.php">VetZone wise Amount wise  Stock Report</a></li>
										<li><a href="Vetzonewise_Quantity_and_Amount_Stock_Report.php">VetZone wise Quantity and Amount Stock Report</a></li>
										
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Sales Report</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
									    <li><a href="Vetzone_Wise_Quantity_wise_Sales_Report.php">VetZone wise Quantity wise  Sales Report</a></li>
										<li><a href="Vetzone_Wise_Amount_wise_Sales_Report.php">VetZone wise Amount wise  Sales Report</a></li>
                                        <li><a href="Vetzone_Wise_Amount_wise_Sales_Report.php">VetZone wise Quantity and Amount Sales Report</a></li>
									
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Purchase Report</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="com_reports/purchase_report.php">Purchase report</a></li>
										<li><a href="com_reports/batch_wise_purchase_report.php">Batch wise Purchase report</a></li>
										<li><a href="com_reports/product_batch_wise_purchase_report.php">Product, Batch ,Purchase report</a></li>

										<li><a href="com_reports/batch_wise_distribution_report.php">Batch wise Distribution</a></li>
										<li><a href="com_reports/near_expiry_batch_report.php">Near expiry batchwise report</a></li>
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-edit"></i>
									<span class="nav-text">Good Returns</span>
								</a>
								
							</li>
						</ul>
						
					</li>
					
					<li>
						<a class="" href="notification.php" aria-expanded="false">
							<i class="flaticon-381-ring"></i>
							<span class="nav-text">Notifications</span>
						</a>
					</li>
					
					<?php } ?>

					<!-- / VOE  -->

					<!-- VSO -->

					<?php if($_SESSION["roll"]==6 && $_SESSION["role"]=="VSO (Veterinary Sales Officer)") { ?>

					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>

					
					 <li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sales</span>
						</a>
						<ul aria-expanded="false">
							<ul aria-expanded="false">
								<li><a href="sales.php">Sales</a></li>
								<li><a href="quaterly_sales.php">Quaterly Sales</a></li>
								<li><a href="sales_plan.php">Sales Plan</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-calculator"></i>
							<span class="nav-text">Collection</span>
						</a>
						<ul aria-expanded="false">
							<ul aria-expanded="false">
								<li><a href="collection_dashboard.php">Collection Plan</a></li>
								<li><a href="weekly_collection.php">Weekly Collection Plan</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Sale Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="vso_reports/party_wise_sales_report.php">Party-wise Sale Repot</a></li>
										<li><a href="vso_reports/party_wise_invoice_wise_sales_report.php">Party wise invoice wise sale report</a></li>
										<li><a href="vso_reports/partywise_product_wise_sales_report.php">Party wise product wise sale report</a></li>
										<li><a href="vso_reports/product_wise_month_wise_sales_report.php">Product wise monthwise sale report</a></li>
										<li><a href="vso_reports/product_wise_yearly_sales_report.php">Product wise Yearly sale report</a></li>
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="vso_reports/partywise_stock_sales_report.php">Partywise stock & Sale report</a></li>
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-edit"></i>
									<span class="nav-text">C N Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="vso_reports/party_wise_cn_report.php">Party wise CN Repot</a></li>
										<li><a href="vso_reports/party_wise_product_wise_cn_report.php">Party wise Productwise CN report</a></li>
									</ul>
								</ul>
							</li>
						</ul>
						
					</li>
					
					<li>
						<a class="" href="notification.php" aria-expanded="false">
							<i class="flaticon-381-ring"></i>
							<span class="nav-text">Notifications</span>
						</a>
					</li>
					
					<?php } ?>

					<!-- / VSO -->

					<!-- //COM   -->

                   <?php if($_SESSION["roll"]==8 && $_SESSION["role"]=="COM  (Commercial Operation Manager)") { ?>

					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Purchase</span>
						</a>
						<ul aria-expanded="false">
							<li><a href="purchase.php">Purchase</a></li>
							<li><a href="challan_report.php">Challan Report</a></li>
						</ul>
					</li>

					<li>
						<a class="" href="inventory.php" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Inventory</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-note"></i>
							<span class="nav-text">Requisition</span>
						</a>
						<ul aria-expanded="false">
							<li><a href="requisition.php">Generate Requisition</a></li>
							<li><a href="requisition_list.php">Requisition</a></li>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-box"></i>
							<span class="nav-text">Orders</span>
						</a>
						<ul aria-expanded="false">
							<li><a href="orders.php">Customer Orders</a></li>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Sales Report</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="com_reports/stock_and_sales_report.php">Stock and Sales Report (Vetrina Godown)</a></li>
										<li><a href="com_reports/product_wise_batch_wise_stock_report.php">Product wise Batch wise stock report</a></li>
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Purchase Report</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="com_reports/purchase_report.php">Purchase report</a></li>
										<li><a href="com_reports/batch_wise_purchase_report.php">Batch wise Purchase report</a></li>
										<li><a href="com_reports/product_batch_wise_purchase_report.php">Product, Batch ,Purchase report</a></li>

										<li><a href="com_reports/batch_wise_distribution_report.php">Batch wise Distribution</a></li>
										<li><a href="com_reports/near_expiry_batch_report.php">Near expiry batchwise report</a></li>
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-edit"></i>
									<span class="nav-text">C N Report</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="com_reports/credit_note_report.php">Credit Note Report and Approve</a></li>
									</ul>
								</ul>
							</li>
						</ul>
						
					</li>
					 

					<li>
						<a class="" href="notification.php" aria-expanded="false">
							<i class="flaticon-381-ring"></i>
							<span class="nav-text">Notifications</span>
						</a>
					</li>
					
					<?php } ?>

					<!-- / COM  -->

					<!-- //COE   -->

                   <?php if($_SESSION["roll"]==14 && $_SESSION["role"]=="COE (Commercial Operation Executive)") { ?>

					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-note"></i>
							<span class="nav-text">Requisition</span>
						</a>
						<ul aria-expanded="false">
							<li><a href="requisition.php">Generate Requisition</a></li>
							<li><a href="requisition_list.php">Requisition</a></li>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-box"></i>
							<span class="nav-text">Orders</span>
						</a>
						<ul aria-expanded="false">
							<li><a href="orders.php">Customer Orders</a></li>
							<li><a href="vetzone_orders.php">Vetzone Orders</a></li>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Stock and Sales Report ( Vetrina Godown)</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
									<li><a href="coe_reports/stock_and_sales_report.php">Stock_And_Sales_Seport.php</a></li>
										<li><a href="coe_reports/product_wise_batch_wise_stock_report.php">Product wise Batch wise stock report</a></li>
										<li><a href="coe_reports/purchase_report.php">Purchase report</a></li>
										<li><a href="coe_reports/batch_wise_purchase_report.php">Batch Purchase report</a></li>
										<li><a href="coe_reports/product_batch_wise_purchase_report.php">Product, Batch ,Purchase report</a></li>

										<li><a href="#">Batch wise Distribution</a></li>
										<li><a href="#">Near expiry batchwise report</a></li>
										<!-- <li><a href="#">Product wise Batch wise stock report</a></li>
										<li><a href="#">Purchase Report</a></li>
										<li><a href="#">Batch wise Purchase report</a></li>
										<li><a href="#">Product, Batch ,Purchase report</a></li>
										<li><a href="#">Batch wise Distribution</a></li>
										<li><a href="#">Near expiry batchwise report</a></li> -->
									</ul>
								</ul>
							</li>
						</ul>

						<ul aria-expanded="false">
							<li>
								<a href="#" aria-expanded="false">
									<i class="flaticon-381-edit"></i>
									<span class="nav-text">C N Reports</span>
								</a>
							</li>
						</ul>
						
					</li>
					 

					<li>
						<a class="" href="notification.php" aria-expanded="false">
							<i class="flaticon-381-ring"></i>
							<span class="nav-text">Notifications</span>
						</a>
					</li>
					
					<?php } ?>

					<!-- / COE  -->


					<!-- ===================== Customer Sidebars ========================== -->
					
					<!-- // Stockiest  -->

					<?php if($_SESSION["roll"]==2 && $_SESSION["role"]=="Stockiest") { ?>
					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Purchase</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="placeorder.php">Product Purchase</a></li>
								<li><a href="my_orders.php">My Purchase Orders</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sale</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="sale_product.php">Sale</a></li>
								<li><a href="sold_orders.php">Sold Order</a></li>
								<li><a href="#">Dispatched order</a></li>
								<li><a href="generateCreditNote.php">Generate Credit Note</a></li>
							</ul>
						</ul>
					</li>
					
					<li>
						<a class="" href="customer_orders.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Customer Orders</span>
						</a>
					</li>

					<li>
						<a class="" href="distribution_network.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Distribution network</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-smartphone-3"></i>
							<span class="nav-text">Pay now dashboard</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="customer_payments.php">Payment</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Sale Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="quantity_wise_sale_report.php">Product- Quantity wise Sale Repot (Qty & Value)</a></li>
										<li><a href="retailer_customer_wise_sale_report">Retailer / Customer wise sale Report</a></li>
										<li><a href="product_value_wise_sale_report">Product-Value wise Sale Report (SKU/Value)</a></li>
										<li><a href="product_batch_customer_wise_sale_report">Product wise Batch wise Customer wise Sale report</a></li>
									</ul>
								</ul>
							</li>
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="Stock_Sale_statement_view">Stock & Sales statement View</a></li>
										<li><a href="inventory_report_view.php">Inventory reports View</a></li>
									</ul>
								</ul>
							</li> 

							<li>
							      <a class="" href="c_n_report.php" aria-expanded="false">
									<i class="flaticon-381-paperclip"></i>
									<span class="nav-text">Credit Note</span>
								</a>
							</li>
						</ul>
					</li>

					<li>
						<a class="" href="#" aria-expanded="false">
							<i class="flaticon-381-notification"></i>
							<span class="nav-text">Product Information</span>
						</a>
					</li>
					
					<li>
						<a class="" href="view_pricing_structure.php" aria-expanded="false">
							<i class="flaticon-381-windows-1"></i>
							<span class="nav-text">Pricing Structure</span>
						</a>
					</li>
					 
					<?php } ?>

					<!-- Stockiest End  -->
					<!-- C&F -->

					<?php if($_SESSION["roll"]==1 && $_SESSION["role"]=="C&F") { ?>
					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Purchase</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="c&f_placeorder.php">Product Purchase</a></li>
								<li><a href="my_orders.php">My Purchase Orders</a></li>
							</ul>
						</ul>
					</li>

							<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sale</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="#">Pending Order</a></li>
								<li><a href="#">Dispatched order</a></li>
								<li><a href="generateCreditNote.php">Generate Credit Note</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="" href="distribution_network.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Distribution network</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-smartphone-3"></i>
							<span class="nav-text">Pay now dashboard</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="customer_payments.php">Payment</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Sale Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="quantity_wise_sale_report.php">Product- Quantity wise Sale Repot (Qty & Value)</a></li>
										<li><a href="retailer_customer_wise_sale_report.php">Retailer / Customer wise sale Report</a></li>
										<li><a href="product_value_wise_sale_report.php">Product-Value wise Sale Report (SKU/Value)</a></li>
										<li><a href="product_batch_customer_wise_sale_report.php">Product wise Batch wise Customer wise Sale report</a></li>
									</ul>
								</ul>
							</li>

							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="Stock_Sale_statement_view.php">Stock & Sales statement View</a></li>
										<li><a href="inventory_report_view.php">Inventory reports View</a></li>
									</ul>
								</ul>
							</li>

							<li>
							      <a class="" href="c_n_report.php" aria-expanded="false">
									<i class="flaticon-381-paperclip"></i>
									<span class="nav-text">Credit Note</span>
								</a>
							</li>
						</ul>
					</li>
					<li>
						<a class="" href="#" aria-expanded="false">
							<i class="flaticon-381-notification"></i>
							<span class="nav-text">Product Information</span>
						</a>
					</li>
					
					<li>
						<a class="" href="view_pricing_structure.php" aria-expanded="false">
							<i class="flaticon-381-windows-1"></i>
							<span class="nav-text">Pricing Structure</span>
						</a>
					</li>
					 
					<?php } ?>

					<!-- C&F End -->
					<!-- Key Account -->

					<?php if($_SESSION["roll"]==3 && $_SESSION["role"]=="Key Account") { ?>
					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Purchase</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="key_account_placeorder.php">Product Purchase</a></li>
								<li><a href="my_orders.php">My Purchase Orders</a></li>
							</ul>
						</ul>
					</li>

							<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sale</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="#">Pending Order</a></li>
								<li><a href="#">Dispatched order</a></li>
								<li><a href="generateCreditNote.php">Generate Credit Note</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="" href="distribution_network.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Distribution network</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-smartphone-3"></i>
							<span class="nav-text">Pay now dashboard</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="customer_payments.php">Payment</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">			

							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="Stock_Sale_statement_view.php">Stock & Sales statement View</a></li>
										<li><a href="inventory_report_view.php">Inventory reports View</a></li>
									</ul>
								</ul>
							</li>

							<li>
							          <a class="" href="c_n_report.php" aria-expanded="false">
									<i class="flaticon-381-paperclip"></i>
									<span class="nav-text">Credit Note</span>
								</a>
							</li>
						</ul>
					</li>

					<li>
						<a class="" href="#" aria-expanded="false">
							<i class="flaticon-381-notification"></i>
							<span class="nav-text">Product Information</span>
						</a>
					</li>
					
					<li>
						<a class="" href="view_pricing_structure.php" aria-expanded="false">
							<i class="flaticon-381-windows-1"></i>
							<span class="nav-text">Pricing Structure</span>
						</a>
					</li>
					 
					<?php } ?>

					<!-- Key Account End -->
					<!-- Retailer -->

					<?php if($_SESSION["roll"]==4 && $_SESSION["role"]=="Retailer") { ?>
					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Purchase</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="retailer_placeorder.php">Product Purchase</a></li>
								<li><a href="my_orders.php">My Purchase Orders</a></li>
								<li><a href="placeorder.php">GRN (Good Reciept)</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sale</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="sale_product.php">Sale</a></li>
								<li><a href="sold_orders.php">Pending Order</a></li>
								<li><a href="#">Dispatched order</a></li>
								<li><a href="generateCreditNote.php">Generate Credit Note</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="" href="customer_orders.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Customer Orders</span>
						</a>
					</li>

					<li>
						<a class="" href="distribution_network.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Distribution network</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-smartphone-3"></i>
							<span class="nav-text">Pay now dashboard</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="customer_payments.php">Payment</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
									     <li><a href="Stock_Sale_statement_view.php">Stock & Sales statement View</a></li>
										<li><a href="inventory_report_view.php">Inventory reports View</a></li>
									</ul>
								</ul>
							</li>

							<li>
							<a class="" href="c_n_report.php" aria-expanded="false">
									<i class="flaticon-381-paperclip"></i>
									<span class="nav-text">Credit Note</span>
								</a>
							</li>
						</ul>
					</li>

					<li>
						<a class="" href="#" aria-expanded="false">
							<i class="flaticon-381-notification"></i>
							<span class="nav-text">Product Information</span>
						</a>
					</li>
					
					<li>
						<a class="" href="view_pricing_structure.php" aria-expanded="false">
							<i class="flaticon-381-windows-1"></i>
							<span class="nav-text">Pricing Structure</span>
						</a>
					</li>
					 
					<?php } ?>

					<!-- Retailer End -->
					<!-- Petshop -->

					<?php if($_SESSION["roll"]==5 && $_SESSION["role"]=="Pet Shop") { ?>
					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Purchase</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="petshop_placeorder.php">Product Purchase</a></li>
								<li><a href="my_orders.php">My Purchase Orders</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sale</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="sale_product.php">Sale</a></li>
								<li><a href="sold_orders.php">Sold Order</a></li>
								<li><a href="#">Dispatched order</a></li>
								<li><a href="generateCreditNote.php">Generate Credit Note</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="" href="distribution_network.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Distribution network</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-smartphone-3"></i>
							<span class="nav-text">Pay now dashboard</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="customer_payments.php">Payment</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Sale Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="quantity_wise_sale_report.php">Product- Quantity wise Sale Repot (Qty & Value)</a></li>
										<li><a href="retailer_customer_wise_sale_report.php">Retailer / Customer wise sale Report</a></li>
										<li><a href="product_value_wise_sale_report.php">Product-Value wise Sale Report (SKU/Value)</a></li>
										<li><a href="product_batch_customer_wise_sale_report.php">Product wise Batch wise Customer wise Sale report</a></li>
									</ul>
								</ul>
							</li>

							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="Stock_Sale_statement_view.php">Stock & Sales statement View</a></li>
										<li><a href="inventory_report_view.php">Inventory reports View</a></li>
									</ul>
								</ul>
							</li>

							<li>
							        <a class="" href="c_n_report.php" aria-expanded="false">
									<i class="flaticon-381-paperclip"></i>
									<span class="nav-text">Credit Note</span>
								</a>
							</li>
						</ul>
					</li>
					<li>
						<a class="" href="#" aria-expanded="false">
							<i class="flaticon-381-notification"></i>
							<span class="nav-text">Product Information</span>
						</a>
					</li>
					
					<li>
						<a class="" href="view_pricing_structure.php" aria-expanded="false">
							<i class="flaticon-381-windows-1"></i>
							<span class="nav-text">Pricing Structure</span>
						</a>
					</li>
					 
					<?php } ?>

					<!-- PetShop End -->
					<!-- Farmer -->

					<?php if($_SESSION["roll"]==6 && $_SESSION["role"]=="Farmer") { ?>
					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Purchase</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="farmer_placeorder.php">Product Purchase</a></li>
								<li><a href="my_orders.php">My Purchase Orders</a></li>
								<li><a href="generateCreditNote.php">Generate Credit Note</a></li>
							</ul>
						</ul>
					</li>
					 
					<!-- <li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sale</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="#">Pending Order</a></li>
								<li><a href="#">Dispatched order</a></li>
								
							</ul>
						</ul>
					</li> -->

					<!-- <li>
						<a class="" href="#" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Distribution network</span>
						</a>
					</li> -->

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-smartphone-3"></i>
							<span class="nav-text">Pay now dashboard</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="customer_payments.php">Payment</a></li>
							</ul>
						</ul>
					</li>
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="Stock_Sale_statement_view.php">Stock & Sales statement View</a></li>
										<li><a href="inventory_report_view.php">Inventory reports View</a></li>
									</ul>
								</ul>
							</li>

							<li>
							        <a class="" href="c_n_report.php" aria-expanded="false">
									<i class="flaticon-381-paperclip"></i>
									<span class="nav-text">Credit Note</span>
								</a>
							</li>
						</ul>
					</li>
					<!-- <li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="#">Stock & Sales statement View</a></li>
										<li><a href="#">Inventory reports View</a></li>
									</ul>
								</ul>
							</li>

							<li>
								<a class="" href="#" aria-expanded="false">
									<i class="flaticon-381-paperclip"></i>
									<span class="nav-text">Credit Note</span>
								</a>
							</li>
						</ul>
					</li> -->

					<li>
						<a class="" href="#" aria-expanded="false">
							<i class="flaticon-381-notification"></i>
							<span class="nav-text">Product Information</span>
						</a>
					</li>
					
					<li>
						<a class="" href="view_pricing_structure.php" aria-expanded="false">
							<i class="flaticon-381-windows-1"></i>
							<span class="nav-text">Pricing Structure</span>
						</a>
					</li>

					<?php } ?>

					<!-- Farmer End -->
					
					<!-- Doctor -->

					<?php if($_SESSION["roll"]==7 && $_SESSION["role"]=="Doctor") { ?>
					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Purchase</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="doctor_placeorder.php">Product Purchase</a></li>
								<li><a href="my_orders.php">My Purchase Orders</a></li>
							</ul>
						</ul>
					</li>

							<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sale</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="sale_product.php">Sale</a></li>
								<li><a href="#">Pending Order</a></li>
								<li><a href="#">Dispatched order</a></li>
								<li><a href="generateCreditNote.php">Generate Credit Note</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="" href="distribution_network.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Distribution network</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-smartphone-3"></i>
							<span class="nav-text">Pay now dashboard</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="customer_payments.php">Payment</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Sale Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="quantity_wise_sale_report.php">Product- Quantity wise Sale Repot (Qty & Value)</a></li>
										<li><a href="retailer_customer_wise_sale_report.php">Retailer / Customer wise sale Report</a></li>
										<li><a href="product_value_wise_sale_report.php">Product-Value wise Sale Report (SKU/Value)</a></li>
										<li><a href="product_batch_customer_wise_sale_report.php">Product wise Batch wise Customer wise Sale report</a></li>
									</ul>
								</ul>
							</li>

							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="Stock_Sale_statement_view.php">Stock & Sales statement View</a></li>
										<li><a href="inventory_report_view.php">Inventory reports View</a></li>
									</ul>
								</ul>
							</li>

							<li>
							        <a class="" href="c_n_report.php" aria-expanded="false">
									<i class="flaticon-381-paperclip"></i>
									<span class="nav-text">Credit Note</span>
								</a>
							</li>
						</ul>
					</li>

					<li>
						<a class="" href="#" aria-expanded="false">
							<i class="flaticon-381-notification"></i>
							<span class="nav-text">Product Information</span>
						</a>
					</li>
					
					<li>
						<a class="" href="view_pricing_structure.php" aria-expanded="false">
							<i class="flaticon-381-windows-1"></i>
							<span class="nav-text">Pricing Structure</span>
						</a>
					</li>
					 
					<?php } ?>

					<!-- Doctor End -->

					<!-- LSS -->

					<?php if($_SESSION["roll"]==8 && $_SESSION["role"]=="LSS") { ?>
					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Purchase</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="LSS_placeorder.php">Product Purchase</a></li>
								<li><a href="my_orders.php">My Purchase Orders</a></li>
							</ul>
						</ul>
					</li>
					
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sale</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="#">Pending Order</a></li>
								<li><a href="#">Dispatched order</a></li>
								<li><a href="generateCreditNote.php">Generate Credit Note</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="" href="distribution_network.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Distribution network</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-smartphone-3"></i>
							<span class="nav-text">Pay now dashboard</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="customer_payments.php">Payment</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
									<li><a href="Stock_Sale_statement_view.php">Stock & Sales statement View</a></li>
										<li><a href="inventory_report_view.php">Inventory reports View</a></li>
									</ul>
								</ul>
							</li>

							<li>
							        <a class="" href="c_n_report.php" aria-expanded="false">
									<i class="flaticon-381-paperclip"></i>
									<span class="nav-text">Credit Note</span>
								</a>
							</li>
						</ul>
					</li>

					<li>
						<a class="" href="#" aria-expanded="false">
							<i class="flaticon-381-notification"></i>
							<span class="nav-text">Product Information</span>
						</a>
					</li>
					
					<li>
						<a class="" href="view_pricing_structure.php" aria-expanded="false">
							<i class="flaticon-381-windows-1"></i>
							<span class="nav-text">Pricing Structure</span>
						</a>
					</li>
					 
					<?php } ?>

					<!-- LSS End -->
					
					<!-- Pet Owner -->

					<?php if($_SESSION["roll"]==9 && $_SESSION["role"]=="Pet Owner") { ?>
					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Purchase</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="petowner_placeorder.php">Product Purchase</a></li>
								<li><a href="my_orders.php">My Purchase Orders</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sale</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="#">Pending Order</a></li>
								<li><a href="#">Dispatched order</a></li>
								<li><a href="generateCreditNote.php">Generate Credit Note</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="" href="distribution_network.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Distribution network</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-smartphone-3"></i>
							<span class="nav-text">Pay now dashboard</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="customer_payments.php">Payment</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Sale Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="quantity_wise_sale_report.php">Product- Quantity wise Sale Repot (Qty & Value)</a></li>
										<li><a href="retailer_customer_wise_sale_report.php">Retailer / Customer wise sale Report</a></li>
										<li><a href="product_value_wise_sale_report.php">Product-Value wise Sale Report (SKU/Value)</a></li>
										<li><a href="product_batch_customer_wise_sale_report.php">Product wise Batch wise Customer wise Sale report</a></li>
									</ul>
								</ul>
							</li>

							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<li><a href="Stock_Sale_statement_view.php">Stock & Sales statement View</a></li>
										<li><a href="inventory_report_view.php">Inventory reports View</a></li>
									</ul>
								</ul>
							</li>

							<li>
							        <a class="" href="c_n_report.php" aria-expanded="false">
									<i class="flaticon-381-paperclip"></i>
									<span class="nav-text">Credit Note</span>
								</a>
							</li>
						</ul>
					</li>

					<li>
						<a class="" href="#" aria-expanded="false">
							<i class="flaticon-381-notification"></i>
							<span class="nav-text">Product Information</span>
						</a>
					</li>
					
					<li>
						<a class="" href="view_pricing_structure.php" aria-expanded="false">
							<i class="flaticon-381-windows-1"></i>
							<span class="nav-text">Pricing Structure</span>
						</a>
					</li>
					 
					<?php } ?>

					<!-- Pet Owner End -->

					<!-- //  VetZone  -->

					<?php if($_SESSION["roll"]==10 && $_SESSION["role"]=="VetZone") { ?>
					<li>
						<a class="" href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Purchase</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="vetzone_placeorder.php">Product Purchase</a></li>
								<li><a href="my_orders.php">My Orders</a></li>
								<li><a href="my_inventory.php">My Inventory</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-price-tag"></i>
							<span class="nav-text">Sale</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="vetzone_sale_product.php">Sale</a></li>
								<li><a href="vetzone_sold_orders.php">Sold Orders</a></li>
								<li><a href="#">Dispatched order</a></li>
								<li><a href="generateCreditNote.php">Generate Credit Note</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="" href="vetzone_customer_orders.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Customer Orders</span>
						</a>
					</li>
					<li>
						<a class="" href="distribution_network.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Distribution network</span>
						</a>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-smartphone-3"></i>
							<span class="nav-text">Pay now dashboard</span>
						</a>
						<ul aria-expanded="false">
							
							<ul aria-expanded="false">
								<li><a href="vetzone_payments.php">Payment</a></li>
							</ul>
						</ul>
					</li>

					<li>
						<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Reports</span>
						</a>
						<ul aria-expanded="false">
							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notepad"></i>
									<span class="nav-text">Sale Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
									<li><a href="vs_report/quantity_wise_sale_report.php">Product- Quantity Value wise Sale Repot (Qty & Value)</a></li>
										<li><a href="vs_report/customer_wise_sale_report.php">Customer wise sale Report</a></li>
										<li><a href="vs_report/vetZone_customer_list.php">Customer List</a></li>
										<!-- <li><a href="#">Product wise Batch wise Customer wise Sale report</a></li> -->
									</ul>
								</ul>
							</li>

							<li>
								<a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
									<i class="flaticon-381-notebook-1"></i>
									<span class="nav-text">Inventory Reports</span>
								</a>
								<ul aria-expanded="false">
									<ul aria-expanded="false">
										<!-- <li><a href="#">Stock & Sales statement View</a></li> -->
										<li><a href="vs_report/Inventory_report.php">Inventory Reports View</a></li>
									</ul>
								</ul>
							</li>

							<li>
								<a class="" href="c_n_report.php" aria-expanded="false">
									<i class="flaticon-381-paperclip"></i>
									<span class="nav-text">Credit Note</span>
								</a>
							</li>
						</ul>
					</li>

					
					<li>
						<a class="" href="view_pricing_structure.php" aria-expanded="false">
							<i class="flaticon-381-windows-1"></i>
							<span class="nav-text">Pricing Structure</span>
						</a>
					</li>
					 
					<?php } ?>

					<!-- VetZone  -->

                </ul>
				<!-- <div class="add-menu-sidebar">
					<img src="images/calendar.png" alt="" class="mr-3">
					<p class="	font-w500 mb-0">View your Calendar</p>
				</div> -->
				<div class="copyright">
					<p><strong>Vetrinahealthcare</strong> © 2022 All Rights Reserved</p>
					<p>Made with <span class="heart"></span> by TDTL</p>
				</div>
			</div>
</div>
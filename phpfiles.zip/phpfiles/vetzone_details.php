<?php include("init.php");
    
    $roll = $_SESSION["roll"];
    $user_loged_in = $_SESSION["user_id"];
    $vetzone_id = $_GET["vetzone_id"];

    $table = "vetzone as v inner join vetzone_type as vt on v.type=vt.v_type_id inner join vetzone_hq_div as vhd on v.vetzone_id=vhd.vetzone_id inner join headquarters as h on h.hq_id=vhd.hq_id inner join divisions as d on d.division_id=vhd.div_id";

    if(isset($_POST["send_form"]))
        {

            $owner_name   = $_POST["cust_name"];
            $vetzone_name   = $_POST["vetzone_name"];
            $email = $_POST["email"];
            $mobile = $_POST["mob_no"];
            $type = $_POST["vetzone_type"];
            $headquarter = $_POST["hq"];
            $division = $_POST["division"];
            $approval_admin_id = $_POST["approval_admin_id"];

            $setval = "name=:name,owner_name=:owner_name,email=:email,mobile_number=:mobile_number,type=:type";
            $where = "where vetzone_id='$vetzone_id'";
            $exe = array(":name"=>$vetzone_name,":owner_name"=>$owner_name,":email"=>$email,":mobile_number"=>$mobile,":type"=>$type);
            $update = update("vetzone",$setval,$where,$exe);

            
            if($update)
            {
                $fields = "vetzone_id,hq_id,div_id,approval_admin_id";
                $values = ":vetzone_id,:hq_id,:div_id,:approval_admin_id";

                $ex = array(":vetzone_id"=>$vetzone_id,":hq_id"=>$headquarter,":div_id"=>$division,":approval_admin_id"=>$approval_admin_id);
                $save_vetzone_hq_div = save("vetzone_hq_div",$fields,$values,$ex);

                $data = $_POST;

                $where = "where vetzone_id='$vetzone_id'";
                $exe = array();
                $delete = delete("vetzone_meta",$where,$exe);

                foreach($data as $key=>$val)
                {
                        $vetzone_meta_key	= $key;
                        $vetzone_meta_value = $val;

                        $fields = "vetzone_id,vetzone_meta_key,vetzone_meta_value";
                        $values = ":vetzone_id,:vetzone_meta_key,:vetzone_meta_value";
                        $exe = array(":vetzone_id"=>$vetzone_id,":vetzone_meta_key"=>$vetzone_meta_key,":vetzone_meta_value"=>$vetzone_meta_value);
                        $savevetzonemeta = save("vetzone_meta",$fields,$values,$exe);
                }

                $getemail = find("first","vetzone","*","where vetzone_id='$vetzone_id' and is_registered='N'",array());
                $email = $getemail["email"];
                $name = $getemail["name"];

                 // mail to send Establishment form
                
                    $url = "https://vscm.vetrinahealthcare.com/PHPMailer/send_mail.php";
                    $data = array(
                            "mailto" => $email,
                            "subject" => "VetZone Registration at VetrinaHealthcare" ,
                            "fullname" => "VetZone Establishment Form",
                            "fromname" => "Vetrina Healthcare",
                            "message" => "Dear ".$name.",<br>
                                    Thank you so much for showing interest. You are our valued customer.
                                    <br>Kindly Fillup the below form for establishment.
                                    <br>Please , Click on to the below link to open form.  
                                    <br>Link: <a href='https://vscm.vetrinahealthcare.com/vetZone_establishment_form.php?vetzone_id=".$vetzone_id."'>Vetzone Establishment Form</a>
                                    <br>For more information please contact  <a href='tel:8600844450'>8600844450.</a>"
                    );

                    $curl = curl_init($url);
                    curl_setopt($curl, CURLOPT_POST, true);
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                    $res = curl_exec($curl);
                    curl_close($curl);

                redirectfn("vetZone_enquiry_list.php");
            }
        } 

        if(isset($_POST["update_vetzone"]))
        {

            $owner_name   = $_POST["cust_name"];
            $vetzone_name   = $_POST["vetzone_name"];
            $email = $_POST["email"];
            $mobile = $_POST["mob_no"];
            $type = $_POST["vetzone_type"];
            

           if($roll=="9")
            {
                $setval = "approval_status=:approval_status,kyc_status=:kyc_status";
                $ap_st = "F";
                $exe = array(":approval_status"=>$ap_st,":kyc_status"=>"Y");
            }
            else {
                 $setval = "name=:name,owner_name=:owner_name,email=:email,mobile_number=:mobile_number,type=:type,approval_status=:approval_status";
                $ap_st = "Y";
                $exe = array(":name"=>$vetzone_name,":owner_name"=>$owner_name,":email"=>$email,":mobile_number"=>$mobile,":type"=>$type,":approval_status"=>$ap_st);
            }
            
            $where = "where vetzone_id='$vetzone_id'";
            $update = update("vetzone",$setval,$where,$exe);


            $data = $_POST;

            $where = "where vetzone_id='$vetzone_id'";
            $exe = array();
            $delete = delete("vetzone_meta",$where,$exe);

            foreach($data as $key=>$val)
            {
                    $vetzone_meta_key	= $key;
                    $vetzone_meta_value = $val;

                    $fields = "vetzone_id,vetzone_meta_key,vetzone_meta_value";
                    $values = ":vetzone_id,:vetzone_meta_key,:vetzone_meta_value";
                    $exe = array(":vetzone_id"=>$vetzone_id,":vetzone_meta_key"=>$vetzone_meta_key,":vetzone_meta_value"=>$vetzone_meta_value);
                    $savevetzonemeta = save("vetzone_meta",$fields,$values,$exe);
            }

            if($savevetzonemeta)
            {
                if($roll=="9")
                {
                    $send_form_id = "5"; //finance manager id
                    $send_to_id =  "9";  // voe id
                    $notify_text = "New VetZone Registration for Approval , Approved by Finance Manager";
                    notify($send_form_id,$send_to_id,$notify_text);
                }
                if($roll=="7")
                {
                    // Mail to Send for ID and Passowrd...

                    $getemail = find("first","vetzone","*","where vetzone_id='$vetzone_id' and is_registered='Y'",array());
                    $email = $getemail["email"];
                    $name = $getemail["name"];


                    $url = "https://vscm.vetrinahealthcare.com/PHPMailer/send_mail.php";
                    $data = array(
                            "mailto" => $email,
                            "subject" => "VetZone Registration at VetrinaHealthcare" ,
                            "fullname" => "VetZone Establishment Form",
                            "fromname" => "Vetrina Healthcare",
                            "message" => "Dear ".$name.",<br>
                                    <center><b>We Welcome you in<br>
                                    Vetrina Family</b></center>
                                    Kindly check your login credentials as follows,<br>
                                    Email ID- ".$email."<br>
                                    Password: 123456 <br>
                                    To Place your first order please Visit our VetZone Panel on <a href='https://vscm.vetrinahealthcare.com/update_password.php?u_id=$vetzone_id&type=vetzone'>VetZone Login</a>."
                    );

                    $curl = curl_init($url);
                    curl_setopt($curl, CURLOPT_POST, true);
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                    $res = curl_exec($curl);
                    curl_close($curl);

                }
            }    

            redirectfn("vetzone_approvals.php");
        }
        
        $findvetzone_details = find("first",$table,"*","where v.vetzone_id='$vetzone_id'",array());
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
                <div class="container-fluid">
                    <div class="row">
                        
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header bg-info shadow">
                                    <label for="" class="card-title text-white"> <?=$findvetzone_details["name"]?></label>
                                </div>
                            
                                <div class="card-body">
                                    <div class="row">
                                        <!-- <div class="col-3" style="height:120px; width:120px;">
                                                <img src="kyc_documents/<?php //$findcustomer["document"][7]?>" alt="Not Availabel" height="120px" width="120px"/>
                                        </div> -->
                                        <div class="col-9">
                                            <table class="table table-bordered">
                                                <tbody>
                                                <tr>
                                                    <td><label for="">VetZone Id </label></td>
                                                    <td> : <?=$vetzone_id?></td>
                                                </tr>
                                                
                                                <tr>
                                                    <td><label for="">Type </label></td>
                                                    <td> : <?=$findvetzone_details["v_type_name"]?></td>
                                                </tr>
                                                <tr>
                                                    <td><label for="">Headquarter </label></td>
                                                    <td> : <?=$findvetzone_details["hq_name"]?></td>
                                                </tr>
                                                <tr>
                                                    <td> <label for="">Division </label></td>
                                                    <td> : <?=$findvetzone_details["division_name"]?></td>
                                                </tr>
                                                <tr>
                                                    <td><label for="">Status </label></td>
                                                    <td> : <?php 
                                                        if($findvetzone_details["approval_status"]=="F")
                                                             { ?>
                                                                <label class="btn btn-info btn-xs shadow">Approved By Finance</label> 
                                                            <?php } 
                                                             else if($findvetzone_details["approval_status"]=="Y") 
                                                             { ?>
                                                                <label class="btn btn-success btn-xs shadow">Approved</label>
                                                             <?php }
                                                        else { ?><label class="btn btn-danger btn-xs shadow">Pending</label> <?php } ?>
                                                    </td>
                                                </tr>
                                               </tbody> 
                                            </table>    

                                        </div>

                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                         <div class="col-3">
                            <span class="btn btn-info btn-md shadow" onclick="getcustomerDetails('<?=$vetzone_id?>')">View All Details</span>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            
                            <div class="row">
                                <div class="col-12" id="vetzone_details">
                                   
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
        </div>
       
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
        <script>
            function getcustomerDetails(vetzone_id) {
                $.ajax({
                    url:"ajax/vetzone_details_form.php",
                    method:"POST",
                    data :{vetzone_id:vetzone_id}
                }).done(function(response){
                    $("#vetzone_details").html(response);
                });             
            }

            function getmanagers(division)
            {
                var hq = $("#hq").val();
                $.ajax({
                        
                        url:"ajax/get_hq_vise_admin.php",
                        method:"POST",
                        data:{division:division,hq:hq}

                }).done(function(response){
                    $("#manager").html(response);
                });
            }
        </script>
</body>
</html>
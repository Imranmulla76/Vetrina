<?php 
    include("init.php");

    // $user_id = $_SESSION["user_id"];

    $getvetzones = find("all","vetzone","*","where 1",array());

    if(isset($_POST["get_report"]))
    {
        $user_id = $_POST["vetzone"];
        $table = "vetzone_instock as i inner join product as p on i.product_id=p.product_id";
        $inventory = find("all",$table,"*,sum(quantity) as qnty","where created_by='$user_id' group by i.product_id",array());
        $vetzone = find("first", "vetzone", "name", "where vetzone_id = $user_id", array());
        $vetzoneName = $vetzone["name"];
    }

   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
     <link rel="stylesheet" href="./vendor/select2/css/select2.min.css">
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-2">
                                            <form method="POST" action="">
                                            <label for="">Select vetZone</label>
                                            <select name="vetzone" id="single-select" class="form-control">
                                                <option value="">Select VetZone</option>
                                                <?php foreach($getvetzones as $key=>$val) { ?>
                                                    <option value="<?=$val["vetzone_id"]?>"><?=$val["name"]?></option>
                                                <?php } ?>
                                            </select>
                                            <input type="submit" class="btn btn-md mt-2 btn-info" name="get_report" value="GET INVENTORY">
                                        </form>
                                    </div>
                                </div>
                                <br>
                                <br>
                                <div class="table-responsive">
                                    <?php echo $vetzoneName; ?>
                                    <table id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Product Name</th>
                                                <th>SKU</th>                                               
                                                <th>Product Code</th>
                                                <th>Purchase Quantity</th>
                                                <th>Sale Quantity</th>
                                                <th>Available Quantity</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; foreach($inventory as $key=>$val) { $i++; 
                                               
                                               $getactualstock = find("first","customer_order_table_product","* , sum(quantity) as qnt","where product_id=".$val['product_id']." and batch='".$val['batch']."' and seller_user_id= ".$user_id." and seller_user_role ='VetZone'",array());
                                                //echo "where product_id=".$val['product_id']." and batch='".$val['batch']."' and seller_user_id=".$user_id;
                                                $soldquantity = $getactualstock["qnt"];

                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["product_name"]?></td>
                                                <td><?=$val["sku"]?></td>                        
                                                <td><?=$val["product_code"]?></td>
                                                <td><?=$val["qnty"]?></td>
                                                <td><?=$getactualstock["qnt"]?></td>
                                                <td><?=$val["qnty"]-$soldquantity?></td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>        
                            </div>
                        </div>            
                    </div>            
                </div>            
            </div>            
        </div>            
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
        <script src="./vendor/select2/js/select2.full.min.js"></script>
        
        <script>
            $("#single-select").select2();
        </script>
    
    </body>
</html>
<?php include("init.php");
    require_once('import-xlsx/vendor/php-excel-reader/excel_reader2.php');
    require_once('import-xlsx/vendor/SpreadsheetReader.php');



function savetargetmeta($productname, $sku, $pts, $ypm, $month , $qnty , $val , $savetarget , $year)
{

    $fields = "target_id,product_id,sku,pts,ypm,quantity,value,month,year";
    $values = ":target_id,:product_id,:sku,:pts,:ypm,:quantity,:value,:month,:year";
    $sku = $sku;
 
    $findproduct_id = find("first","product","*","where  sku='$sku' and product_name= '$productname'",array());
    $product_id = $findproduct_id["product_id"];
    $month = $month;
    $quantity =$qnty; 
    $value =$val; 
    $exe = array(
        ":target_id"=> $savetarget,
        ":product_id"=>$product_id,
        ":sku"=>$sku,
        ":pts"=>$pts,
        ":ypm"=>$ypm,
        ":quantity"=>$quantity,
        ":value"=>$value,
        ":month"=>$month,
        ":year"=>$year
    );
    $savetarget_meta = save("target_meta",$fields,$values,$exe);
}

        if(isset($_POST["set_target"]))
        {
            $user_name = $_POST["user_name"];
            $user_id = $_POST["user_id"];
            $designation = $_POST["designation"];
            $headquarter = $_POST["headquarter"];
            $filename = $_FILES['file']['name'];

            $fields="user_id,hq_id,desig_id,file";
            $values = ":user_id,:hq_id,:desig_id, :file";
            $exe = array(":user_id"=>$user_id,
                        ":hq_id"=>$headquarter,
                        ":desig_id"=>$designation,
                        ":file"=>$filename
                    );
            $savetarget = save("target_table",$fields,$values,$exe);

            if($savetarget){

                $allowedFileType = array('application/vnd.ms-excel', 'text/xls', 'text/xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

                if (in_array($_FILES["file"]["type"], $allowedFileType))
                {
                    $targetPath = 'import-xlsx/uploads/' . $_FILES['file']['name'];
                    move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);
                    $Reader = new SpreadsheetReader($targetPath);
                    $sheetCount = count($Reader->sheets());

                    for ($i = 0; $i < $sheetCount; $i++)
                    {
                        $Reader->ChangeSheet($i);
                        if ($i==0)
                        {
                            $k = 0;
                            foreach ($Reader as $Row)
                            {
                                if($k > 3)
                                {
                                    $productname= $Row[1];
                                    $sku = $Row[2];
                                    $pts = $Row[3];
                                    $ypm = $Row[4];
                                    $year = date("Y");

                                    /****Q1 */
                                    $month = "04";
                                    $qnty =$Row[8]; // APR
                                    $val =$Row[9]; // APR
                                    savetargetmeta($productname ,$sku ,$pts , $ypm , $month , $qnty , $val, $savetarget ,$year);

                                    $month = "05";
                                    $qnty =$Row[10];//MAY
                                    $val =$Row[11];
                                    savetargetmeta($productname ,$sku ,$pts , $ypm , $month , $qnty , $val, $savetarget ,$year);


                                    $month = "06";
                                    $qnty =$Row[12];//JUNE
                                    $val =$Row[13];
                                    savetargetmeta($productname ,$sku ,$pts , $ypm , $month , $qnty , $val, $savetarget ,$year);

                                    
                                    /**Q2 */
                                    $month = "07";
                                    $qnty =$Row[16];//JUL
                                    $val =$Row[17];
                                    savetargetmeta($productname ,$sku ,$pts , $ypm , $month , $qnty , $val, $savetarget ,$year);

                                    $month = "08";
                                    $qnty =$Row[18];//AUG
                                    $val =$Row[19];
                                    savetargetmeta($productname ,$sku ,$pts , $ypm , $month , $qnty , $val, $savetarget ,$year);

                                    $month = "09";
                                    $qnty =$Row[20];//SEPT
                                    $val =$Row[21];
                                    savetargetmeta($productname ,$sku ,$pts , $ypm , $month , $qnty , $val, $savetarget ,$year);



                                    /**Q3 */
                                    $month = "10";
                                    $qnty =$Row[24];//JUL
                                    $val =$Row[25];

                                    savetargetmeta($productname ,$sku ,$pts , $ypm , $month , $qnty , $val, $savetarget ,$year);

                                    $month = "11";
                                    $qnty =$Row[26];//AUG
                                    $val =$Row[27];

                                    savetargetmeta($productname ,$sku ,$pts , $ypm , $month , $qnty , $val, $savetarget ,$year);

                                    $month = "12";
                                    $qnty =$Row[28];//SEPT
                                    $val =$Row[29];

                                    savetargetmeta($productname ,$sku ,$pts , $ypm , $month , $qnty , $val, $savetarget ,$year);


                                    $year = (date("Y") +1 );
                                     /**Q4 */
                                     $month = "01";
                                     $qnty =$Row[32];//JUL
                                     $val =$Row[33];

                                     savetargetmeta($productname ,$sku ,$pts , $ypm , $month , $qnty , $val, $savetarget ,$year);
 
                                     $month = "02";
                                     $qnty =$Row[34];//AUG
                                     $val =$Row[35];

                                     savetargetmeta($productname ,$sku ,$pts , $ypm , $month , $qnty , $val, $savetarget ,$year);
 
                                     $month = "03";
                                     $qnty =$Row[36];//SEPT
                                     $val =$Row[37];

                                     savetargetmeta($productname ,$sku ,$pts , $ypm , $month , $qnty , $val, $savetarget ,$year);
                            }
                            $k++;
                            }
                        }
                    }
                }
                echo "<script>alert('Target set now'); window.location.href='create_target.php';</script>";
                
            }
    
        }

        $finddesignations = find("all","designations","*","where 1",array());
        $finddivision = find("all","divisions","*","where 1",array());
        $findheadquarter = find("all","headquarters","*","where 1",array());
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Set Target</h4>
                            </div>
                        
                            <div class="card-body">

                            <form action="" method="POST" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-6">
                                        <label for="">Select User</label>
                                        <!-- <select name="designation" id="designation" onchange="getusersbydesig(this.value)" class="form-control"> -->
                                        <select name="designation" id="designation" class="form-control">
                                            <option value="">Select Designation</option>
                                            <option value="2">GM (General Manager)</option>
                                            <option value="3">NSM (National Sales Manager)</option>
                                            <option value="4">ZSM (Zonal Sales Manager)</option>
                                            <option value="5">ASM (Area Sales Manager)</option>
                                            <option value="6">VSO (Veterinary Sales Officer)</option>
                                        </select>
                                    </div>
                                    <div class="col-6">
                                        <label for="">Select Headquarters</label>
                                        <select name="headquarter" class="form-control"  id="hq">
                                            <option value="">Select Headquarter</option>
                                            <?php foreach($findheadquarter as $k=>$v){?>
                                                <option value="<?=$v["hq_id"]?>"><?=$v["hq_name"]?> - (<?=$v["base_town"]?>)</option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-6">
                                    <label for="">Select Divisions</label>
                                        <select name="division" class="form-control" onchange="getusers(this.value)" id="div">
                                            <option value="">Select Divisions</option>
                                            <?php foreach($finddivision as $k=>$v){?>
                                                <option value="<?=$v['division_id']?>"><?=$v["division_name"]?></option>
                                            <?php } ?>
                                        </select>
                                    </div>

                                    <div class="col-6">
                                        <label for="">Excel Sheet</label>
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Upload</span>
                                            </div>
                                            <div class="custom-file">
                                                <input type="file" name="file" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" class="custom-file-input">
                                                <label class="custom-file-label">Choose file</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-6" id="user">
                                        
                                    </div>
                                </div>

                                <br>

                                <div class="row">
                                    <div class="col-3">
                                        <button class="btn btn-sm btn-success shadow" type="submit" name="set_target">Upload & Calculate Target</button>
                                    </div>
                                </div>
                            </form>
                                
                               
                            </div>
                        </div>

                    </div>        
                </div>      
            </div>  
        </div>  
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
            <script>
                function getusers(div_id) {
                    var desig_id = $("#designation").val();
                    var hq_id = $("#hq").val();
                    $.ajax({
                        url: "ajax/getUsers.php",
                        method: "POST",
                        data: {
                            desig_id:desig_id , hq_id:hq_id , div_id:div_id
                        },
                        success: function( result ) {
                            $("#user").html(result);
                        }
                        });
                }

                function getusersbydesig(desig_id) {
                    var hq_id = $("#hq").val();
                    var div_id = $("#div").val();

                    $.ajax({
                        url: "ajax/getUsers.php",
                        method: "POST",
                        data: {
                            desig_id:desig_id , hq_id:hq_id , div_id:div_id
                        },
                        success: function( result ) {
                            $("#user").html(result);
                        }
                        });
                }

                function calpercent(percent,Quarter)
                {
                    var yearlyAmount = $("#amount").val();
                    
                    if(Quarter == "1")
                    {
                        var amount1 =  Math.round(yearlyAmount *  (percent / 100) );
                        $("#amount1").val(amount1);
                    }

                    if(Quarter == "2")
                    {
                        var amount2 =  Math.round(yearlyAmount * (percent / 100));
                        $("#amount2").val(amount2);
                    }

                    if(Quarter == "3")
                    {
                        var amount3 =  Math.round(yearlyAmount * (percent / 100));
                        $("#amount3").val(amount3);
                    }

                    if(Quarter == "4")
                    {
                        var amount4 =  Math.round(yearlyAmount * (percent / 100));
                        $("#amount4").val(amount4);
                    }
                    
                }

                function calculateMonthly()
                {
                   var quarter1 = $("#amount1").val();
                   var quarter2 = $("#amount2").val();
                   var quarter3 = $("#amount3").val();
                   var quarter4 = $("#amount4").val();

                   var janTomar = Math.round(quarter1/3);
                   var aprlTojune = Math.round(quarter2/3);
                   var julyTosep = Math.round(quarter3/3);
                   var octTodec = Math.round(quarter4/3);

                   $(".monthly").append('<span class="badge light badge-danger">January - '+janTomar+'</span> &nbsp;&nbsp;&nbsp;&nbsp;  <span class="badge light badge-danger">February - '+janTomar+'</span> &nbsp;&nbsp;&nbsp;&nbsp;  <span class="badge light badge-danger">March - '+janTomar+'</span><br>');
                   $(".monthly").append('<br><span class="badge light badge-danger">April - '+aprlTojune+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">May - '+aprlTojune+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">June - '+aprlTojune+'</span><br>');
                   $(".monthly").append('<br><span class="badge light badge-danger">July - '+julyTosep+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">August - '+julyTosep+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">September - '+julyTosep+'</span><br>');
                   $(".monthly").append('<br><span class="badge light badge-danger">October - '+octTodec+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">November - '+octTodec+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">December - '+octTodec+'</span><br>');
                }
            </script>
</body>
</html>
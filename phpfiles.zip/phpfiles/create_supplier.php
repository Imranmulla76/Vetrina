<?php include("init.php");
        //check_login();

    if(isset($_POST["save_supplier"]))
    {
        $name = $_POST["name"];
        $email = $_POST["email"];
        $address = $_POST["address"];
        $state=$_POST['state'];
        $city=$_POST['city'];
        $pincode=$_POST['pincode'];
        $phone = $_POST["phone"];
        $category = $_POST["category"];
        $gst = $_POST["gst"];
        $pan = $_POST["pan"];
        $contact_person=$_POST['contactperson'];
        $contact_number=$_POST['contactpersonnumber'];



        $fields = "sup_name,sup_email,address,state,city,pincode,category,phone,gst,pan,contact_person,contact_person_number";
        $values = ":sup_name,:sup_email,:address,:state,:city,:pincode,:category,:phone,:gst,:pan,:contact_person,:contact_person_number";
        $exe = array(":sup_name"=>$name,":sup_email"=> $email,":address"=>$address,":state"=>$state,":city"=>$city,":pincode"=>$pincode,":category"=>$category,":phone"=>$phone,":gst"=>$gst,":pan"=>$pan,":contact_person"=>$contactperson,":contact_person_number"=>$contact_number);
        $savesupplier = save("suppliers",$fields,$values,$exe);
    }

    if(isset($_POST["update_supplier"]))
    {
        $supplier_id = $_POST["sup_id"];
        $name = $_POST["name"];
        $email = $_POST["email"];
        $address = $_POST["address"];
        $phone = $_POST["phone"];
        $category = $_POST["category"];
        $gst = $_POST["gst"];
        $pan = $_POST["pan"];

        $fields = "sup_name=:sup_name,sup_email=:sup_email,address=:address,category=:category,phone=:phone,gst=:gst,pan=:pan";
        $wh = "where supplier_id='$supplier_id'";
        $exe = array(":sup_name"=>$name,":sup_email"=> $email,":address"=>$address,":category"=>$category,":phone"=>$phone,":gst"=>$gst,":pan"=>$pan);
        $update_supplier = update("suppliers",$fields,$wh,$exe);
    }


    $category = find("all","product_category","*","where 1",array());
    $findsupplier = find("all","suppliers as s inner join product_category as pc on s.category=pc.category_id ","*","where 1",array());

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
   <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
                    <button class="btn btn-primary" data-target=".bd-example-modal-sm" data-toggle="modal">+ Add Supplier</button>
				</div>

                <div class="row mt-3">
                    <div class="col-12">
                      <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Suppliers</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example3" class="display min-w850">
                                <thead>
                                    <tr>
                                        <th>SR.No.</th>
                                        <th>Supplier Name</th>
                                        <th>Email</th>
                                        <th>Category</th>
                                        <th>Address</th>
                                        <th>Phone</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php //print_r($finddesignations); ?>
                                    <?php $i=0; foreach($findsupplier as $k=>$v) { $i++;?>
                                    <tr>
                                        <td><?=$i;?></td>
                                        <td><?=$v["sup_name"]?></td>
                                        <td><?=$v["sup_email"]?></td>
                                        <td><?=$v["category_name"]?></td>
                                        <td><?=$v["address"]?></td>
                                        <td><?=$v["phone"]?></td>
                                        <td>
                                            <div class="d-flex">
                                                <span onclick="updateSupplier(<?=$v['supplier_id']?>)" class="btn btn-primary shadow btn-xs sharp mr-1"><i class="fa fa-pencil"></i></span>
                                                <a href="#" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
											</div>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                                </table>
                            
                            </div>
                           
                        </div>
                    </div>
                    </div>
                </div>

            </div>
        </div>
        !-------main content end----->
        <?php include("footer.php"); ?>
    </div>


    <!-- Create Modal -->
 <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Supplier</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <form action="" method="POST">
            <div class="modal-body">
                
                   <div class="row">
                       <div class="col-6">
                            <label for="">Supplier</label>
                            <input type="text" name="name" id="" class="form-control">
                       </div>
                       <div class="col-6">
                            <label for="">Email</label>
                            <input type="email" name="email" id="" class="form-control">
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-6">
                            <label for="">Phone No.</label>
                            <input type="number" name="phone" id="" class="form-control">
                       </div>
                       <div class="col-6">
                            <label for="">Product Category</label>
                            <select name="category" id="" class="form-control">
                                <option value="">Select Category</option>
                                    <?php foreach($category as $k=>$v) { ?>
                                        <option value="<?=$v["category_id"]?>"><?=$v["category_name"]?></option>
                                    <?php } ?>
                                    <option onclick="addCategory(this.value);" value="other">Other</option>
                            </select>
                       </div>
                   </div>

                   <div class="row">
                       <div class="col-12">
                           <label for="">Address</label>
                           <textarea name="address" id="" cols="15" class="form-control"></textarea>
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-12">
                           <label for="">State</label>
                           <input type="text" name="state" id="" cols="15" class="form-control"></text>
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-12">
                           <label for="">City</label>
                           <input type="text" name="city" id="" cols="15" class="form-control"></text>
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-12">
                           <label for="">Pincode</label>
                           <input type="text" name="pincode" id="" cols="15" class="form-control" required></text>
                       </div>
                   </div>

                   <div class="row">
                       <div class="col-6">
                           <label for="">GST No.</label>
                           <input type="text" name="gst" id="" class="form-control">
                       </div>
                       <div class="col-6">
                           <label for="">PAN No.</label>
                           <input type="text" name="pan" id="" class="form-control">
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-6">
                           <label for="">Contact Person</label>
                           <input type="text" name="contactperson" id="" class="form-control">
                       </div>
                       <div class="col-6">
                           <label for="">Contact Person Number</label>
                           <input type="text" name="contactpersonnumber" id="" class="form-control">
                       </div>
                   </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" name="save_supplier">Save Supplier</button>
            </div>
            </form>
        </div>
    </div>
</div>

 <!-- Create Modal -->

  <!-- Update Modal -->
 <div class="modal fade bd-example-modal-sm1" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Supplier</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <form action="" method="POST">
            <div class="modal-body" id="supply_form">
                
                                   
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" name="update_supplier">Update Supplier</button>
            </div>
            </form>
        </div>
    </div>
</div>

 <!-- Update Modal -->


        <?php include("jslink.php"); ?>

        <script>
            $(document).ready(function(){
                <?php if($savesupplier) { ?>
                    swal("Supplier Added","New Supplier Created","success");    
                <?php } ?>
            });

            function updateSupplier(supplier_id)
            {
                $(".bd-example-modal-sm1").modal("show");

                $.ajax({
                    url:"ajax/update_supplier.php",
                    method:"POST",
                    data:{supplier_id:supplier_id}
                }).done(function(response){
                    $("#supply_form").html(response);
                });
            }
        </script>

</body>
</html>
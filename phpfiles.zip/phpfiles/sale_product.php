<?php 
    include("init.php");

    $user_id = $_SESSION["user_id"];
    $table = "customer_instock as i inner join product as p on i.product_id=p.product_id ";
    
    $inventory = find("all",$table,"*,sum(quantity) as qnty","where created_by='$user_id' group by i.product_id",array());

    $getheadquarter = find("all","headquarters","*","where 1",array());
    $getdivision = find("all","divisions","*","where 1",array());

    if(isset($_POST["savecust"]))
    {
        $cust_name = $_POST["cust_name"];
        $mob_no = $_POST["mob_no"];
        $farm_name = $_POST["farm_name"];
        $email = $_POST["email"];
        $address = $_POST["address"];
        $taluka = $_POST["taluka"];
        $District = $_POST["District"];
        $State = $_POST["State"];
        $Pin_code = $_POST["Pin_code"];
        $gst_no = $_POST["gst_no"];
        $hq = $_POST["hq"];
        $division = $_POST["division"];

        $craeted_by = $user_id;
        $create_by_role = $_SESSION["roll"];
        
        $fields = "created_by_user_id,created_by_user_role,name,mobile,email,farm_name,address,taluka,District,State,Pin_code,gst_no,hq,division";
        $values = ":created_by_user_id,:created_by_user_role,:name,:mobile,:email,:farm_name,:address,:taluka,:District,:State,:Pin_code,:gst_no,:hq,:division";
        $exe = array(
                ":created_by_user_id"=>$craeted_by,
                ":created_by_user_role"=>$create_by_role,
                ":name"=>$cust_name,
                ":farm_name"=>$farm_name,
                ":mobile"=>$mob_no,
                ":email"=>$email,
                ":address"=>$address,
                ":taluka"=>$taluka,
                ":District"=>$District,
                ":State"=>$State,
                ":Pin_code"=>$Pin_code,
                ":gst_no"=>$gst_no,
                ":hq"=>$hq,
                ":division"=>$division
            );
        
        $savecustomer =  save("end_customer",$fields,$values,$exe);

        if($savecustomer)
        {
            redirectfn("sale_product.php");
        }
    }

    if(isset($_POST["saveorder"]))
    {
        $order_id = $_POST["order_id"];
        $where = "where customer_order_id='$order_id'";
        $setval = "status=:status,is_invoiced=:is_invoiced,is_placed_order=:is_placed_order";
        $exe = array(":status"=>"Y",":is_invoiced"=>"Y",":is_placed_order"=>"Y");
        $update = update("customer_placeorder",$setval,$where,$exe);

        if($update)
        {
            unset($_SESSION["order_id"]);
        }
    }

    $findcustomer = find("all","end_customer","*","where created_by_user_id='$user_id'",array());
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    <link rel="stylesheet" href="./vendor/select2/css/select2.min.css">

</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">

                                <div class="row">
                                    <strong class="text-danger">*Note : Please select customer before placeorder.</strong>
                                    <br>
                                    <div class="col-3">
                                            <label for="">Select Customer</label>
                                            <select name="to" class="form-control" id="single-select">
                                                <option value="">Select Customer</option>
                                                <?php 
                                                foreach($findcustomer as $k=>$v){ ?>
                                                    <option value="<?=$v["end_customer_id"]?>"><?=$v["name"]?> - <?=$v["mobile"]?></option>
                                                <?php } ?>
                                            </select>

                                    </div>
                                    <div class="col-1">
                                        <span class="btn btn-sm btn-success mt-4" onclick="showform()">+</span>
                                    </div>
                                </div>
                                <br>
                                <br>
                                <div class="row" id="formcust" style="display:none;">
                                    <div class="col-12">
                                        <form action="" method="POST">
                                        <div class="row mt-4">
                                            <strong> <u>Basic Details</u> </strong>
                                        </div>
                                                <div class="row mt-4">
                                                    <div class="col-3">
                                                        <label for="">Name </label>
                                                        <input type="text" name="cust_name" class="form-control" id="" required>
                                                    </div>

                                                    <div class="col-4">
                                                        <label for="">Mobile Number/What’s app Number</label>
                                                        <input type="number" name="mob_no" id="" class="form-control" pattern="[0-9]{10}">
                                                    </div>
                                                    
                                                    <div class="col-3">
                                                        <label for="">Name of Farm</label>
                                                        <input type="text" name="farm_name" class="form-control" id="">
                                                    </div>
                                                
                                                </div>

                                                <div class="row mt-4">

                                                    <div class="col-4">
                                                        <label for="">Email ID</label>
                                                        <input type="email" name="email" id="" class="form-control" required>
                                                    </div>

                                                </div>
                                                
                                                <div class="row mt-4">
                                                    <strong><u>Address Details</u> </strong>
                                                </div>
                                                <div class="row mt-4">
                                                    <div class="col-6">
                                                        <label for="">Address</label>
                                                        <textarea name="address" id="" class="form-control"></textarea>
                                                    </div>
                                                    <div class="col-3">
                                                        <label for="">Taluka</label>
                                                        <input type="text" name="taluka" class="form-control" id="">
                                                    </div>
                                                    <div class="col-3">
                                                        <label for="">District</label>
                                                        <input type="text" name="District" class="form-control" id="">
                                                    </div>
                                                </div>
                                                <div class="row mt-4">
                                                
                                                    <div class="col-3">
                                                        <label for="">State </label>
                                                        <input type="text" name="State" class="form-control" id="">
                                                    </div>
                                                    <div class="col-3">
                                                        <label for="">Pin code</label>
                                                        <input type="number" name="Pin_code" class="form-control" id="">
                                                    </div>

                                                    <div class="col-3">
                                                        <label for="">GSTN No.</label>
                                                        <input type="text" name="gst_no" class="form-control" id="">
                                                    </div>
                                                </div>

                                                <div class="row mt-4">
                                                    <div class="col-3">
                                                        <label for="">Select Headqaurter</label>
                                                        <select name="hq" class="form-control" id="">
                                                            <option value="">Select Headquarter</option>
                                                            <?php foreach($getheadquarter as $k=>$v) { ?>
                                                                <option value="<?=$v["hq_id"]?>"><?=$v["hq_name"]?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>

                                                    <div class="col-3">
                                                        <label for="">Select Division</label>
                                                        <select name="division" class="form-control" id="">
                                                            <option value="">Select Division</option>
                                                            <?php foreach($getdivision as $k=>$v) { ?>
                                                                <option value="<?=$v["division_id"]?>"><?=$v["division_name"]?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            
                                                <div class="row mt-4">
                                                    <button type="submit" name="savecust" class="btn btn-info">Add Customer</button>
                                                </div>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Product Name</th>
                                                <th>SKU</th>
                                                <th>Unit</th>
                                                <th>Product Code</th>
                                                <th>Available Quantity</th>
                                                <th>Add to Cart</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; foreach($inventory as $key=>$val) { $i++;
                                                
                                                $getactualstock = find("first","customer_order_table_product","* , sum(quantity) as qnt","where product_id=".$val['product_id']." and batch='".$val['batch']."' and seller_user_id=".$user_id,array());
                                                
                                                //echo "where product_id=".$val['product_id']." and batch='".$val['batch']."' and seller_user_id=".$user_id;

                                                $soldquantity = $getactualstock["qnt"];
                                                echo $soldquantity;
                                                
                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["product_name"]?></td>
                                                <td><?=$val["sku"]?></td>
                                                <td><?=$val["unit"]?></td>
                                                <td><?=$val["product_code"]?></td>
                                                <td><?=$val["qnty"]-$soldquantity;?></td>
                                                <td><button class="btn btn-md btn-warning" onclick="addtocart('<?=$val['product_id']?>')">+</button></td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>        
                            </div>
                        </div>            
                    </div>
                    
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                Invoice Details
                            </div>
                            <div class="card-body" id="invoice">
                                
                            </div>
                        </div>
                    </div>

                </div>            
            </div>            
        </div>            
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

         <script src="./vendor/select2/js/select2.full.min.js"></script>
        
        <script>
            $("#single-select").select2();

            function showform()
            {
                $("#formcust").show("toggle");
            }

             function addtocart(product_id)
            {
                $("#productdetails").modal("show");
                $.ajax({
					method: "POST",
					url: "ajax/customerorderrequestform.php",
					data: {
						product_id: product_id
					}
				})
				.done(function(response) {
					$("#showdetails").html(response);
				});
            }

            function productaddtocart()
            { 
                $("#addtocartresponse").html("<div class='loader-text-animation' align='center'>We are validating your product! Kindly wait.</div>");
                var product_id = $("#product_id").val();
                var order_qnty = $("#order_qnty").val();
                var customer_id = $("#single-select").val();
                var customer_type = "end_customer";
                var batch = $("#batch").val();

                $.ajax({
					method: "POST",
					url: "ajax/customeraddtocart.php",
					data: {
						product_id: product_id,
                        order_qnty: order_qnty,
                        customer_id:customer_id,
                        customer_type:customer_type,
                        batch:batch
					}
				})
				.done(function(response) {
                    var data =JSON.parse(response);
                    if(data["status"]=="success")
                    {
                        var msg = data["msg"];
                        $("#addtocartresponse").html("<div class='text-success' align='center'>"+msg+"</div>");

                    } 
                    if(data["status"]=="error")
                    {
                        var msg = data["msg"];
                        $("#addtocartresponse").html("<div class='text-danger' align='center'>"+msg+"</div>");

                    } 
					$("#productdetails").modal("hide");
					// cartsummery();
				});
                invoicesummary();
                viewCustomerInvoice();
            }

            function getbatchquantity(batch,product_id)
            {
                $.ajax({
                    url:"ajax/get_batch_quantity.php",
                    method:"POST",
                    data:{batch:batch,product_id:product_id}

                }).done(function(response){
                        $("#batchQuantity").html(response);
                });
            }

            function validate()
            {
                // alert("hello");
                var oqnty =  $("#order_qnty").val();
                var bqnty = parseInt($("#batchQuantity").html());

                // console.log(oqnty+" , "+bqnty);

                if(oqnty > bqnty)
                {
                    $("#validation").html("<p class='text-danger'>Order Quantity Should less than batch quantity.<p>");
                    $("#addtocartbutton").attr("disabled", true);
                }
                else if(oqnty == "")
                {
                    $("#validation").html("<p class='text-warning'>Please enter Quantity.<p>");
                    $("#addtocartbutton").attr("disabled", true);
                }
                
                else
                {
                    $("#validation").html("<p class='text-success'>Good To go <p>");
                    $("#addtocartbutton").removeAttr("disabled");
                }
            }

        </script>
    
    </body>
</html>
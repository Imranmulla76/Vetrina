<?php 
    include("init.php");

    // $table = "order_table_product as otp inner join placeorder as p otp.order_id=p.stockiest_order_id";
    $user_id = $_SESSION["user_id"]; 
    $role = $_SESSION["roll"]; 
   
    //$table = "customer_placeorder as cp inner join vetzone as c on cp.user_id=c.vetzone_id inner join customer_order_table_product as cotp on cp.customer_order_id=cotp.order_id inner join vetzone_end_customer as vec on cotp.customer_id=vec.end_customer_id";
   $table = "credit_note_table as vcnt inner join customer as v on vcnt.user_id=v.customer_id";
   $payments = find("all",$table,"*, sum(amount) as due","where payment_status in('P','N') group by vcnt.user_id",array());

   if(isset($_POST["action"]))
   {
       $payment_id = $_POST["payment_id"];
       $customer_id = $_POST["customer_id"];
       $comment = $_POST["comment"];
       $date = date("Y-m-d");
        $setval = "payment_status=:payment_status,comment=:comment,payment_date=:payment_date";
        $wh = "where user_id='$customer_id' and payment_status='P'";
       
       if($_POST["action"]=="approve")
        {
            $exe = array(":payment_status"=>"Y",":payment_date"=>$date,":comment"=>$comment);
            $updatepaymentstatusApprove = update("credit_note_table",$setval,$wh,$exe);

            if($updatepaymentstatusApprove)
            {
                $setval = "placeorder=:placeorder";
                $wh = "where customer_id='$customer_id'";
                $exe = array(":placeorder"=>'Y');
                $updateorderstatus = update("customer",$setval,$wh,$exe);

                if($updateorderstatus)
                {
                    $send_form_id = "1";
                    $send_to_id = $customer_id;
                    $notify_text = "<a href='customer_payments.php'>Congratulations,Your Order have been Unblocked by Admin , Thank you.'</a>";
                        
                    cust_notify($send_form_id,$send_to_id,$notify_text);
                }
            }

        }
        else {
            $exe = array(":payment_status"=>"D",":payment_date"=>$date,":comment"=>$comment);
            $updatepaymentstatusDecline = update("credit_note_table",$setval,$wh,$exe);
        }

   }
 ?>
<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table bordered id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Name of Party</th>
                                                <th>PI No.</th>
                                                <th>PI Amount</th>
                                                <th>Invoice Number</th>
                                                <th>Invoice Amount</th>
                                                <th>Payment Mode</th>
                                                <th>Payment Amount</th>
                                                <th>Due Date</th>
                                                <th>Reference Number</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                $i=0; foreach($payments as $key=>$val) { $i++;
                                                $invoice_date = date("d M Y",strtotime($val["invoice_date"]));
                                                $due_date = date("d M Y",strtotime($val["credit_end_date"]));
                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["name"]?></td>
                                                <td></td>
                                                <td></td>
                                                <td><?=$val["order_id"]?></td>
                                                <td><?=$val["due"]?></td>
                                                <td></td>
                                                <td></td>
                                                <td><STRONG class="text-danger"> <?=$due_date?> </STRONG> </td>
                                                <td></td>
                                                <td>
                                                <?php
                                                      if($val["payment_status"]=="N")
                                                    {
                                                        echo "<label class='label label-warning'>Pending</label>";
                                                    }
                                                    else if($val["payment_status"]=="P")
                                                    {
                                                        echo "<label class='label label-info'>Pending for Approval</label>";
                                                    }
                                                     else if($val["payment_status"]=="Y")
                                                    {
                                                        echo "<label class='label label-success'>Completed</label>";
                                                    }
                                                     else
                                                    {
                                                        echo "<label class='label label-danger'>Declined</label>";
                                                    }
                                                    ?>
                                                </td> 
                                                <td>
                                                     <div class="d-flex">
                                                        <?php if($val["payment_status"]=="P") { ?>
                                                            <span onclick="view_payment_details('<?=$val['customer_id']?>')"  class="btn btn-info shadow btn-xs sharp"><i class="fa fa-eye"></i></span>
                                                        <?php } else if($val["payment_status"]=="Y"){ ?>
                                                           <button disabled class="btn btn-sm btn-success shadow mr-2">Verified</button>
                                                        <?php } else if($val["payment_status"]=="D"){ ?>
                                                           <button disabled class="btn btn-sm btn-danger shadow mr-2">Declined</button>
                                                        <?php } ?>
                                                    </div>
                                                </td>
                                                
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>        
                            </div>
                        </div>            
                    </div>            
                </div>            
            </div>            
        </div>            
        <!-------main content end----->
        

         <!-- Payment Modal -->
    <div class="modal fade paymentdetails" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header header-primary">
                    <h5 class="modal-title">Payment Details</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="modal-body" id="payment_details">
                           
                    </div>
                    <div class="modal-footer">

                        <select name="action" class="form-control" required id="">
                            <option value="">Select Action</option>
                            <option value="approve">Approve</option>
                            <option value="decline">Decline</option>
                        </select>
                        <button type="submit" class="btn btn-primary" name="apply">Apply</button>
                        <!-- <button type="submit" class="btn btn-primary" name="approve">Save & Approve Order</button> -->
                        <!-- <button type="submit" class="btn btn-danger" name="decline">Decline Order</button> -->
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->


        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

        <script>

            $(function(){

                <?php if($updatepaymentstatusApprove) { ?>
                    swal("Payment Approved","vetzone payment approved","success");
                <?php } ?>

                <?php if($updatepaymentstatusDecline) { ?>
                    swal("Payment Declined","vetzone payment declined","danger");
                <?php } ?>
            });

           function view_payment_details(customer_id)
           {
                $(".paymentdetails").modal("show");

                $.ajax({
                    url:"ajax/customer_payment_details.php",
                    method:"POST",
                    data:{customer_id:customer_id}
                }).done(function(response) {
                    $("#payment_details").html(response);
                });
               
           }

        </script>
    </body>
</html>
<?php 
    include("init.php");

    if(isset($_POST["saverequisition"]))
    {

        $requisition_id = $_POST["requisition_id"];
        $product_id = $_POST["product_id"];
        $stock_quantity = $_POST["stock_quantity"];
        $batch_size = $_POST["batch_size"];
        $required_qnty = $_POST["required_quantity"];
        $expected_date = $_POST["expected_date"];

        foreach($stock_quantity as $key=>$val)
        {
            $product = $product_id[$key];
            $stock = $stock_quantity[$key];   
            $batch = $batch_size[$key];   
            $required = $required_qnty[$key];   
            $date = date("Y-m-d", strtotime($expected_date[$key]));  
            $req_id= $requisition_id[$key];
            
            $setval ="batch_size=:batch_size,stock_quantity=:stock_quantity,required_quantity=:required_quantity,expected_date=:expected_date,status=:status";
            $where = "where requisition_id='$req_id' and product_id='$product'";

            $exe = array(":batch_size"=>$batch,":stock_quantity"=>$stock,":required_quantity"=>$required,":expected_date"=>$date,":status"=>"I");
            
            $update_requisition = update("requisition_details",$setval,$where,$exe);

        }
        
    }

   

    $table = "instock as i inner join product as p on i.product_id=p.product_id";
    $inventory = find("all",$table,"*,sum(quantity) as qnty","where 1 group by i.product_id",array());
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Product Name</th>
                                                <th>SKU</th>
                                                <th>Available Quantity</th>
                                                <th>Min Inventory Quantity</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; foreach($inventory as $key=>$val) { $i++; 

                                                $getactualstock = find("first","order_table_product","* , sum(quantity) as qnt","where product_id='".$val["product_id"]."'",array());
                                                
                                                //echo "where product_id='".$val["product_id"]."' and batch='".$val["batch"]."' "; 
                                                $soldquantity = $getactualstock["qnt"];
                                                $quantity = $val["qnty"]-$soldquantity;
                                               // echo $soldquantity."<br>";
                                               if($quantity <= $val["min_inventory_qnty"])
                                               { ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["product_name"]?></td>
                                                <td><?=$val["sku"]?></td>
                                                <td><?=$quantity?></td>
                                                <td><?=$val["min_inventory_qnty"]?></td>
                                                <td>
                                                    <span class="btn btn-info btn-sm" onclick="viewProductDetails(<?=$val['product_id']?>)"><i class="fa fa-eye"></i></span>
                                                    <!-- <span title="add to requisition" class="btn btn-success btn-sm" onclick="addToRequisition()"><i class="fa fa-plus"></i></span> -->
                                                </td>
                                            </tr>
                                            <?php } } ?>
                                        </tbody>
                                    </table>
                                </div>        
                            </div>
                        </div>            
                    </div>  
                </div> 
                
                <div class="row">
                 <div class="col-12">
                        <div class="card">
                            <form action="" method="POST">
                                <div class="card-body" id="requisitionform">
                                    
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>            
        </div>
        
        <!-- Modal Product Details -->

        <div class="modal fade bd-example-modal" id="productdetails" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Product Details</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="bactchquantity">
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" onclick="addToRequisition()">Add to Requisition</button>
                </div>
            </div>
        </div>
    </div>

        

        <!-------main content end----->

        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

        <script>
            
            $(function(){
                <?php if($update_requisition_status) { ?>
                    swal("Requisition Accepted","requisition sent to Production","success");
                <?php } ?>
            });

            function viewProductDetails(product_id)
            {
                $("#productdetails").modal("show");

                $.ajax({
                    url :"ajax/viewrequisition_product.php",
                    method :"POST",
                    data : { product_id:product_id , }
                
                    }).done(function(response) {
                        $("#bactchquantity").html(response);
                });
            }

            function viewrequisition(requisition_id)
            {
                $.ajax({
                    url :"ajax/viewrequisitionform.php",
                    method :"POST",
                    data : {requisition_id:requisition_id}
                
                    }).done(function(response) {
                    $("#requisitionform").html(response);
                });
            }


            function addToRequisition()
            {
                var product_id = $("#product_id").val();
                var stock_quantity = $("#stock_quantity").val();
                var batch_size = $("#batch_size").val();
                var required_qnty = $("#required_qnty").val();
                var expected_date = $("#expected_date").val();

                 $.ajax({

                    url :"ajax/addtorequisition.php",
                    method :"POST",
                    data : { product_id:product_id , stock_quantity:stock_quantity , batch_size:batch_size , required_qnty:required_qnty , expected_date:expected_date }
                
                    }).done(function(response) {
                        // var data = JSON.parse(response);
                        // var requisition_id = data["requisition_id"];
                        // alert(requisition_id);
                        
                        // $("#requisitionform").html(response);
                    });
                viewrequisition();
            }

        </script>
    
</body>
</html> 
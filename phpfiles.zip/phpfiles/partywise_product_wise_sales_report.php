<?php 
    include("init.php");
    
    $admin_id = $_SESSION["user_id"];

    $get_admin_hq_div = find("first","admin_hq_div","*","where admin_id='$admin_id'",array());

    $admin_hq = $get_admin_hq_div["hq_id"];
    $admin_div = $get_admin_hq_div["div_id"];

    $table_customer = "customer as c inner join customer_hq_div as chd on c.customer_id=chd.customer_id";
    $get_all_customer = find("all",$table_customer,"*","where chd.hq_id='$admin_hq' and chd.div_id='$admin_div'",array());

    // print_r($get_all_vetzone);

    $table_vetzone = "vetzone as v inner join vetzone_hq_div as vhd on v.vetzone_id=vhd.vetzone_id";
    $get_all_vetzone = find("all",$table_vetzone,"*","where vhd.hq_id='$admin_hq' and vhd.div_id='$admin_div'",array());

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
       <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <b class="card-title">Party wise Product wise Sales</b>
                            </div>
                            <div class="card-body">

                                <div class="row"> 
                                    <div class="col-4">
                                        <label for="">Select Party</label>
                                        <select name="party_name" id="" onchange="getcustomerorders(this.value)" class="form-control">
                                            <option value="">Select Party</option> 
                                            <?php foreach($get_all_customer as $k=>$v) { ?>
                                                <option value="<?=$v["customer_id"]?>"><?=$v["name"]?></option>
                                            <?php } ?>
                                           
                                        </select>
                                    </div>

                                    <div class="col-4">
                                        <label for="">Select VetZone</label>
                                        <select name="party_name" id="" onchange="getvetzoneorders(this.value)" class="form-control">
                                         <option value="">Select Vetzone</option>
                                            <?php foreach($get_all_vetzone as $k=>$v) { ?>
                                                <option value="<?=$v["vetzone_id"]?>"> <?=$v["name"]?> </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <br> 
                                <br>

                                <div class="table-responsive">
                                    <table id="reporttable" class="display min-w850 result">
                                        
                                       
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
        <script>

             $(function(){
                    $("#reporttable").DataTable({
						responsive: true,
						dom: 'lBfrtip',
                    	buttons: [
                        'excelHtml5',
                        'csvHtml5',
                        'pdfHtml5',
                        'colvis'
                    ]

					});
            });
           
                function getcustomerorders(customer_id)
                {
                    var type = "customer";
                    $.ajax({
                        url:"ajax/get_customer_order_report.php",
                        method:"POST",
                        data:{customer_id:customer_id,type:type}
                    }).done(function(response){
                        $(".result").html(response);
                    });
                }

                function getvetzoneorders(vetzone_id)
                {
                    var type = "vetzone";

                    $.ajax({
                        url:"ajax/get_customer_order_report.php",
                        method:"POST",
                        data:{vetzone_id:vetzone_id,type:type}
                    }).done(function(response){
                        $(".result").html(response);
                    });
                }
            
        </script>

</body>
</html>
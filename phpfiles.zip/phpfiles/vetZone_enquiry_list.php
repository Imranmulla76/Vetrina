<?php include("init.php");

if(date("m") > 3)
{
    $fyear = date("Y").'/04/01  - '.(date("Y")+1).'/03/31';
    $from_dt = date("Y").'-04-01';
    $to_dt = (date("Y")+1).'-03-31';
}
else
{
    $from_dt = (date("Y")-1).'-04-01';
    $to_dt = date("Y").'-03-31';
}


    //    print_r($_SESSION);exit;
       $roll = $_SESSION["roll"];

       if(isset($_POST["delete"]))
       {
            $vetzone_id = $_POST["vetzone_id"];
            $where ="where vetzone_id='$vetzone_id'";
            $exe = array();
            $deletevetzone = delete("vetzone",$where,$exe);

           if($deletevetzone)
           {
                $where ="where vetzone_id='$vetzone_id'";
                $exe = array();
                $deletevetzone_meta = delete("vetzone_meta",$where,$exe);
           }
       }
       
      
        $tbladmin = "admin as a inner join admin_hq_div as ahd on ahd.admin_id=a.admin_id";
        $admin_id = $_SESSION["user_id"];

        /* select * 
        from vetzone as v inner join vetzone_type as vt on v.type=vt.v_type_id inner join vetzone_meta vm on vm.vetzone_id = v.vetzone_id
        where is_registered='N'
        and vetzone_meta_key = 'cust_name'; */

        $table = "vetzone as v inner join vetzone_type as vt on v.type=vt.v_type_id inner join vetzone_meta vm on vm.vetzone_id = v.vetzone_id";

        if($roll == "7")
        {
            $findcustomers = find("all",$table,"*","where is_registered='N' and vetzone_meta_key = 'cust_name' order by v.vetzone_id desc",array());
        }
        else {
            $findcustomers = find("all",$table,"*","where v.approval_status = 'N' and is_registered='Y' and vetzone_meta_key = 'cust_name' order by v.vetzone_id desc",array());
        }

        $newEnquiry = find("first", "vetzone", "count(*) count", "where is_registered = 'N'", array());

        $approvedEnq = find("first", "vetzone", "count(*) count", "where approval_status = 'N'", array());

        $pending = find("first", "vetzone", "count(*) count", "where establishment_status = 'N'", array());

        $establised = find("first", "vetzone", "count(*) count", "where establishment_status = 'Y'", array());

       
       
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
                    <div class="col-12">

                        <div class="row">                            
                            <div class="col-sm-6">
                                <div class="card avtivity-card">
                                    <div class="card-body">
                                        <div class="media align-items-center">
                                            
                                            <div class="media-body">
                                                <p class="fs-14 mb-2">New Enquiry Requests</p>
                                                <span class="title text-black font-w600"><?=$newEnquiry['count'];?></span>
                                            </div>
                                        </div>
                                        <div class="progress" style="height:5px;">
                                            <div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
                                                <span class="sr-only"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="effect bg-success"></div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="card avtivity-card">
                                    <div class="card-body">
                                        <div class="media align-items-center">
                                            
                                            <div class="media-body">
                                                <p class="fs-14 mb-2">Approved Requests</p>
                                                <span class="title text-black font-w600"><?=$approvedEnq['count'];?></span>
                                            </div>
                                        </div>
                                        <div class="progress" style="height:5px;">
                                            <div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
                                                <span class="sr-only"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="effect bg-success"></div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="card avtivity-card">
                                    <div class="card-body">
                                        <div class="media align-items-center">
                                            
                                            <div class="media-body">
                                                <p class="fs-14 mb-2">Pending Establishments</p>
                                                <span class="title text-black font-w600"><?=$pending['count'];?></span>
                                            </div>
                                        </div>
                                        <div class="progress" style="height:5px;">
                                            <div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
                                                <span class="sr-only"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="effect bg-success"></div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="card avtivity-card">
                                    <div class="card-body">
                                        <div class="media align-items-center">
                                            
                                            <div class="media-body">
                                                <p class="fs-14 mb-2">Established</p>
                                                <span class="title text-black font-w600"><?=$establised['count'];?></span>
                                            </div>
                                        </div>
                                        <div class="progress" style="height:5px;">
                                            <div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
                                                <span class="sr-only"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="effect bg-success"></div>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">VetZone Registration Applications</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.no</th>
                                                <th>Owner Name</th>>
                                                <th>Place</th>
                                                <th>Mobile No.</th>
                                                <th>Approval status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; foreach($findcustomers as $key=>$val) { $i++;  
                                                $vetzone_id = $val['vetzone_id'];
                                                 $vetzone_meta = find("first","vetzone_meta","vetzone_meta_value","where vetzone_id='$vetzone_id' and vetzone_meta_key = 'District'",array());   
                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["owner_name"]?></td>
                                                <td><?=$vetzone_meta['vetzone_meta_value']?></td>
                                                <td><?=$val["mobile_number"]?></td>
                                                <td>
                                                    <?php if($val["approval_status"]=="Y")
                                                        { 
                                                            echo "<label class='label label-success'>Approved</label>"; 
                                                        }
                                                        else if($val["approval_status"]=="F")
                                                        {
                                                            echo "<label class='label label-info'>Approved by finance</label>";
                                                        }
                                                        else 
                                                        {
                                                            echo "<label class='label label-warning'>Pending</label>";
                                                        }
                                                    ?>
                                                </td>
                                                <td>
                                                    <div class="d-flex" >
                                                        <a href="vetzone_details.php?vetzone_id=<?php echo $val["vetzone_id"];?>" class="btn btn-info shadow btn-xs sharp mr-1"><i class="fa fa-eye"></i></a>
                                                        <form action="" method="POST">
                                                            <input type="text" name="vetzone_id" value="<?=$val["vetzone_id"]?>" hidden id="">
                                                            <button name="delete" type="submit" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>        
                </div>
            </div>
        </div>

        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
        <script>
            <?php if($deletevetzone_meta) { ?>
                swal("VetZone Enquiry Deleted","customer enquiry has been permanatly removed from system","success");
            <?php } ?>
        </script>
</body>
</html>
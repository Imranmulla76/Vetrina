<?php 

$user_id = $_SESSION['user_id'];

?>

<div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-info">
                                <h4 class="card-title">Party Orders</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-3">
                                        <label for="">From</label>
                                        <input type="date" name="from" id="from_date" class="form-control">
                                    </div>
                                    <div class="col-3">
                                        <label for="">To</label>
                                        <input type="date" name="to" id="to_date" class="form-control">
                                    </div>
                                    <div class="col-2">
                                        <button type="submit" class="btn btn-info btn-md mt-4" name="getorders" onclick="getreport()">Get Orders</button>
                                    </div>
                                </div>
                                <br>
                                <br>
                                 <div class="table-responsive">
                                    <table bordered id="orders" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Month</th>
                                                <th>Total Invoice</th>
                                                <th>Primary Purchase</th>
                                                <th>Pending Orders</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										    <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td><p class="clickable"></p></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>				
            </div>
        </div>

<script>

var from_dt;
var to_dt;
today = new Date().toISOString().split('T')[0];

$(function() {
	console.log( "ready!" );
});


function getreport()
{
    from_dt = $('#from_date').val(); //YYYY-MM-DD
    to_dt = $('#to_date').val();    

    console.log("from date : "+from_dt);
    console.log("to date : "+to_dt);
    console.log("today : "+today);

    if(from_dt > today || to_dt > today)
    {
        //alert("Invalid Date is Selected");
        swal("Wrong!","Invalid Date is Selected","error"); 
    }
    else{
        $.ajax({ 
            url: "ajax/get_petshop_dashboard.php",
            type: "POST",
            data: {
                action : 'getOrders',
                from_dt : from_dt,
                to_dt : to_dt,
            },
        }).done(function(response){
            // alert('success');
			$("#orders").html(response);
        });
    } 
	
	$("#orders").DataTable({
		dom: 'Blfrtip',
		buttons: [
        'copyHtml5', 'excelHtml5', 'pdfHtml5'
    ],
	});

}//End of getreport function


function Open(user_id) {

$.ajax ({
    url: "ajax/get_petshop_dashboard.php",
    method: "POST",
    data: {
        action : 'orderDetails',
        user_id : user_id,
        }
}).done(function(response){
    console.log(response);
    $("#orderDetails").html(response);
});
// $(window).scrollTop($('#newOrders').offset().top-600);
// $('#newOrders').scrollTop( 800 );
$("#orderDetails").DataTable({
   dom: 'lfrtip',
});

}

</script>

<style>
    .clickable {
        color: #1a0dab;
    }

    .clickable:hover {
        /* background-color: yellow; */
        cursor: pointer;
    }
</style>

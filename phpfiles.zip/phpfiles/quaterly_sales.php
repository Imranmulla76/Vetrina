<?php 
    include("init.php");

    function getmonth($month)
    {
        if($month=="04")
        {
            echo "Apr";
        }
        if($month=="05")
        {
            echo "May";
        }
        if($month=="06")
        {
            echo "Jun";
        }
        if($month=="07")
        {
            echo "Jul";
        }
        if($month=="08")
        {
            echo "Aug";
        }
        if($month=="09")
        {
            echo "Sep";
        }
        if($month=="10")
        {
            echo "Oct";
        }
        if($month=="11")
        {
            echo "Nov";
        }
        if($month=="12")
        {
            echo "Dec";
        }
        if($month=="01")
        {
            echo "Jan";
        }
        if($month=="02")
        {
            echo "Feb";
        }
        if($month=="03")
        {
            echo "Mar";
        }
    }

    $user_id = $_SESSION["user_id"];
    
    $table = "target_table as t inner join target_meta as tm on t.target_id=tm.target_id";

    $gettarget = find("all",$table,"*","where t.user_id='$user_id'",array());
    $target = $gettarget["tar_qnty"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
       <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <b class="card-title">Quaterly Sales</b>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Month</th>
                                                <th>Target</th>
                                                <th>Sale</th>
                                                <th>% Achievement</th>
                                                <th>Cumulative Achievement</th>
                                                <th>Cumulative Balance</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0;
                                                  $commulative_sale = 0;
                                                  $commulative_target = 0;
                                                
                                                  $qur_target = 0;
                                                  $qur_sale = 0;
                                                  $qur_comm_achievement = 0;
                                                  $qur_comm_balance = 0;

                                                foreach($gettarget as $key=>$val)
                                                { $i++; 
                                                
                                                ?>
                                                <tr>
                                                <td><?=$i?></td>
                                                <td><?php getmonth($val["month"]);?> - <?=$val["year"]?></td>
                                                <td><?=$val["value"]?></td>
                                                
                                                <!-- jugad -->
                                                <?php  
                                                    $target = $val["value"];  
                                                    $month = $val["month"];
                                                    $year = $val["year"];

                                                    $qur_target = $qur_target + $target;

                                                    $getuserhq_div = find("all","admin_hq_div","*","where admin_id='$user_id'",array());

                                                    
                                                    $vet_sale = 0;
                                                    $cust_sale = 0;

                                                    foreach($getuserhq_div as $k=>$v)
                                                    {

                                                        $hq_id = $v["hq_id"];
                                                        $div_id = $v["div_id"];

                                                    $get_vetzone_ids = find("all","vetzone_hq_div","*","where hq_id='$hq_id' and div_id='$div_id'",array());
                                                    
                                                    $get_customer_ids = find("all","customer_hq_div","*","where hq_id='$hq_id' and div_id='$div_id'",array());
                                                    
                                                   
                                                    foreach($get_vetzone_ids as $key=>$val)
                                                    {
                                                        $vetzone_id = $val["vetzone_id"];

                                                        $get_vetzone_sale = find("first","order_table_product","sum(quantity * rate) as sale_amount","where user_id='$vetzone_id' and user_role='VetZone' and month(created_at) = '$month' and year(created_at) = '$year'",array());

                                                        $vet_sale = $vet_sale + $get_vetzone_sale["sale_amount"];
                                                    }

                                                   
                                                    foreach($get_customer_ids as $key=>$val)
                                                    {
                                                        $customer_id = $val["customer_id"];

                                                        $get_cust_sale = find("first","order_table_product","sum(quantity * rate) as sale_amount","where user_id='$customer_id' and user_role !='VetZone' and month(created_at) = '$month' and year(created_at) = '$year'",array());

                                                        $cust_sale = $cust_sale + $get_cust_sale["sale_amount"];
                                                    }
                                                
                                                }
                                                    $total_hq_sale = $vet_sale + $cust_sale;
                                                    
                                                    $qur_sale = $qur_sale + $total_hq_sale;

                                            ?>
                                            
                                        <!-- Jugad -->

                                                <td><?=$total_hq_sale?></td>
                                                <td><?php 
                                                        $percent = ($total_hq_sale/$target)*100;
                                                        echo number_format($percent)."%";
                                                    ?>
                                                </td>
                                                <td><?=$commulative_sale;?></td>
                                                <td><?php 
                                                    $balance = $commulative_target - $commulative_sale;  
                                                    if($balance < 0) { echo "-"; } else { echo  $balance; } 
                                                    ?> 
                                                </td>
                                            </tr>
                                        <?php 
                                            $commulative_sale = $commulative_sale + $total_hq_sale;
                                            $commulative_target = $commulative_target + $target;


                                             if($i%3 == 0) { 
                                            
                                                $qur_comm_achievement = $qur_comm_achievement + ($qur_sale);
                                               
                                                $qur_comm_balance = $qur_comm_balance + ($qur_target - $qur_sale) ;
                                            ?>
                                                <tr>
                                                    <td colspan="2"> <b> Total</b></td>
                                                    <td><b><?=$qur_target?></b></td>
                                                    <td><b><?=$qur_sale?></b></td>
                                                    <td><b><?php echo number_format(($qur_sale/$qur_target)*100);?> % </b></td>
                                                    <td><b><?=$qur_comm_achievement?></b></td>
                                                    <td><b><?php if($qur_comm_balance < 0) { echo "-"; } else { echo  $balance; } 
                                                    ?> </b> </td>
                                                </tr>
                                           
                                            <?php 
                                            $qur_target = 0;
                                            $qur_sale =0;
                                            }
                                        } 
                                    ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
</body>
</html>
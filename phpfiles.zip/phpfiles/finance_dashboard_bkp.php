<?php 

    $divisons = find("all", "divisions", "*", "where 1", array());

	
	if(date("m") > 3)
	{
		$fyear = date("Y").'/04/01  - '.(date("Y")+1).'/03/31';
		$from_dt = date("Y").'-04-01';
		$to_dt = (date("Y")+1).'-03-31';
	}
	else
	{
		$from_dt = (date("Y")-1).'-04-01';
		$to_dt = date("Y").'-03-31';
	}

	
	// SELECT order_product_id, product_id, sum(rate * quantity)sale , created_at, month(created_at) month
	// FROM `order_table_product`
	// where created_at between '$from_dt' and '$to_dt'
	// group by year(created_at), month(created_at);
	$value = "order_product_id, product_id, sum(rate * quantity)sale , created_at, month(created_at) month";
	$where = "where created_at between '$from_dt' and '$to_dt' group by year(created_at), month(created_at)";
	$result = find("first", "order_table_product", $value, $where, array());

	$start_year = 1992;
	$end_year = date("Y");
	$selected = $from_dt."-".$to_dt;	
	

?>

<div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
					<div class="col-3">
						<select name="fyear" class="form-control" id="fyear" onchange="getyear();">
							<option value="">Select</option>
							<?php for($i = $start_year; $i <= $end_year; $i++) { ?>
							<option value="<?=$i."-".$i+1?>" selected="<?=$selected?>"><?=$i."-".$i+1?></option>
							<?php } ?>
						</select>
					</div>
				</div>
				<div class="row">
					<div class="col-xl-12 col-xxl-12">
						<div class="row">
							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">											
											<div class="media-body">
												<p class="fs-14 mb-2">Total Trade Sale</p>
												<span class="title text-black font-w600">Rs.<?=$result['sale'];?>/-</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-primary" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-primary"></div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">											
											<div class="media-body">
												<p class="fs-14 mb-2">Total VetZone Sale</p>
												<span class="title text-black font-w600">Rs.<?=$result['sale'];?>/-</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-primary" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-primary"></div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<div class="media-body">
												<p class="fs-14 mb-2">Total Sale</p>
												<span class="title text-black font-w600">Rs.<?=$result['sale'];?>/-</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-primary" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-primary"></div>
								</div>
							</div>
							
							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<div class="media-body">
												<p class="fs-14 mb-2">Total Trade collection</p>
												<span class="title text-black font-w600">Rs.0/-</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-success"></div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<div class="media-body">
												<p class="fs-14 mb-2">Total VetZone collection</p>
												<span class="title text-black font-w600">Rs.0/-</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-success"></div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<div class="media-body">
												<p class="fs-14 mb-2">Total collection</p>
												<span class="title text-black font-w600">Rs.0/-</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-success"></div>
								</div>
							</div>

							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<div class="media-body">
												<p class="fs-14 mb-2"> Trade Due collection</p>
												<span class="title text-black font-w600">Rs.0/-</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-danger"></div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<div class="media-body">
												<p class="fs-14 mb-2">VetZone Due collection</p>
												<span class="title text-black font-w600">Rs.0/-</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-danger"></div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<div class="media-body">
												<p class="fs-14 mb-2">Total Due collection</p>
												<span class="title text-black font-w600">Rs.0/-</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-danger"></div>
								</div>
							</div>
							
						</div>
					</div>
				</div>

                <!-- Tables -->

				<div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Sale Report</h4>
                            </div>
                            <div class="card-body">
                                    
                                    <div class="row">
                                        <div class="col-3">
                                            <label for="">Search By</label>
                                            <select name="division" class="form-control" id="division">
                                                <option value="">All</option>
                                                <?php foreach($divisons as $k=>$v) {
													 ?>
                                                <option value="<?=$v["division_id"]?>"><?=$v["division_name"]?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="col-2">
                                            <button type="submit" class="btn btn-md btn-info mt-4" id = "search" onclick="getreport()">Search</button>
                                        </div>
                                    </div>
                                    
                                <br>
                                <br>

									<?php

											/* if($livestock){
												$display = 'none';
											}
											if($cannic){
												$display = 'none';
											}
											if($livestock){
												$display = 'none';
											} */

									
									
									?>

                                    <div class="table-responsive" id="fm" >
                                        <table bordered id="fmdashboard" class="display min-w850">
                                            <thead>
                                                <tr>
                                                    <th>Sr.No.</th>
                                                    <th>Month</th>
													<th>Mon</th>
													<th>Year</th>
                                                    <th>Sale</th>
                                                    <th>Credit Note</th>
                                                    <th>Cumulative Sale</th>
                                                    <th>Collection</th>
                                                    <th>Cumulative Collection</th>
                                                    <th>Balance</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td></td>
													<td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
													<td></td>
                                                    <td></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

									<div class="table-responsive" id="party">
                                        <table bordered id="partydashboard" class="display min-w850">
                                            <thead>
                                                <tr>
                                                    <th>Sr.No.</th>
                                                    <th>HQ</th>
													<th>Party</th>
													<th>Invoice Number</th>
                                                    <th>Invoice date</th>
                                                    <th>Basic Amount</th>
                                                    <th>GST %</th>
                                                    <th>GST Amount</th>
                                                    <th>Invoice Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td></td>
													<td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
													<td></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

									<div class="table-responsive" id="creditnote">
                                        <table bordered id="creditnotedashboard" class="display min-w850">
                                            <thead>
                                                <tr>                                                    
													<th>Sr.No.</th>
                                                    <th>HQ</th>
													<th>Party</th>
													<th>Product</th>
													<th>Credit Note Number</th>
                                                    <th>Crdit date</th>
                                                    <th>NetRate</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td></td>
													<td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
</div>

<script>

$(function() {
	console.log( "ready!" );
});

function getreport()
{
	div_id = $("#division").val();
	// alert("div id  : "+div_id);

	/* $.ajax({ 
        url: "ajax/get_finance_dashboard.php",
        type: "POST",
        data: { 
            action : 'getSaleDetails',
            div_id : div_id,
        },
        success: function(data) {
            alert(data);            
            }
    }); */
	$('#fmdashboard').DataTable({
        dom: 'Bfrtip',  

		"ajax":
			{
			'url' : 'ajax/get_finance_dashboard.php',
			'type': 'POST',
			'data': {
						action : 'getreport',
						div_id : div_id,
					},
			
			},

			columnDefs: [
            {
                render: function (data, type, row) {
                    return '<a class = "clickable" onclick = "partywisedashboard(\'' +row+ '\' );" id = "show">'+data+'</a>';
                },
                targets: 4,
            },
			{
                render: function (data, type, row) {
                    return '<a class = "clickable" onclick = "creditnotedashboard(\'' +row+ '\' );" id = "show">'+data+'</a>';
                },
                targets: 5,
            },
			{ 
                visible: false, 
                targets: [2] 
            },
			{ 
                visible: false, 
                targets: [3] 
            },
		],

		destroy : true,
	});
}


function partywisedashboard(rowdata)
{
	div_id = $("#division").val();
	rowdata = rowdata.split(',');	
	// alert(rowdata[2]);
	month = rowdata[2];
	year = rowdata[3];

	$("#partydashboard").show();
	$('#partydashboard').DataTable({
        dom: 'Bfrtip',  

		"ajax":
			{
			'url' : 'ajax/get_finance_dashboard.php',
			'type': 'POST',
			'data': {
						action : 'getSaleDetails',
						div_id : div_id,
						month : month,
						year : year
					},
			
			},			

		destroy : true,
	});
}

function creditnotedashboard(rowdata)
{
	rowdata = rowdata.split(',');	
	// alert(rowdata);
	month = rowdata[2];
	year = rowdata[3];

	$('#creditnotedashboard').DataTable({
        dom: 'Bfrtip',  

		"ajax":
			{
			'url' : 'ajax/get_finance_dashboard.php',
			'type': 'POST',
			'data': {
						action : 'getcreditreport',
						month : month,
						year : year
					},
			
			},			

		destroy : true,
	});
}


function getyear()
{
	fyear = $("#fyear").val();
	// alert(fyear);
	$.ajax({
        url: "ajax/get_finance_dashboard.php",
        type: "POST",
        data: {
			action : "getfyearsale",
            fyear : fyear,
        },
        success: function(response) {
            // alert("success year : "+JSON.stringify(response));           
        }
    });
}

</script>


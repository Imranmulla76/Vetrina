<?php include("registrationinit.php");
        //check_login();
    if($_SESSION["user_id"]!="")
    {
        redirectfn("template.php");
        exit;
    }    

    if(isset($_POST["submit"]))
    {
        
        $name = $_POST["cust_name"];
        $mobile = $_POST["mob_no"];
        $email = $_POST["email"];
        $password = "123456";
       

        $role = $_POST["cust_role"];

        $fields = "name,mobile_number,email,password,type,role";
        $values = ":name,:mobile_number,:email,:password,:type,:role";

        //  Saving Customer as vetZone

        if($role=="10")
        {
            $type = $_POST["vetzone_type"];

             $exe = array(
                    ":name"=>$name,
                    ":mobile_number"=>$mobile,
                    ":email"=> $email,
                    ":password"=>$password,
                    ":type"=>$type,
                    ":role"=>$role
                );
            $savevetzone = save("vetzone",$fields,$values,$exe);

            $send_form_id = "0";
            $send_to_id = "9";
            $notify_text = "New VetZone Registration Request for Approval";
            notify($send_form_id,$send_to_id,$notify_text);

            if($savevetzone)
            {
                  $data = $_POST;

                foreach($data as $key=>$val)
                {
                    $vetzone_id = $savevetzone;
                    $vetzone_meta_key	= $key;
                    $vetzone_meta_value = $val;

                    $fields = "vetzone_id,vetzone_meta_key,vetzone_meta_value";
                    $values = ":vetzone_id,:vetzone_meta_key,:vetzone_meta_value";
                    $exe = array(":vetzone_id"=>$vetzone_id,":vetzone_meta_key"=>$vetzone_meta_key,":vetzone_meta_value"=>$vetzone_meta_value);
                    $savevetzonemeta = save("vetzone_meta",$fields,$values,$exe);
                }
            }
           
        }
        else 
        {
            if($_POST["stockiest_type"])
            {
                $type = $_POST["stockiest_type"];
            }
            else
            {
                $type = 6;
            }

            // Saving Customers Without Approvals

            if($role == "4" || $role == "5" || $role == "6" || $role == "9")
            {
                $fields = "name,mobile_number,email,password,type,role,kyc_status,approval_status";
                $values = ":name,:mobile_number,:email,:password,:type,:role,:kyc_status,:approval_status";

                $exe = array(
                        ":name"=>$name,
                        ":mobile_number"=>$mobile,
                        ":email"=> $email,
                        ":password"=>$password,
                        ":type"=>$type,
                        ":role"=>$role,
                        ":kyc_status"=>"Y",
                        ":approval_status"=>"Y"
                    );
            
                $savecust = save("customer",$fields,$values,$exe);

                if($savecust)
                {

                    $division = $_POST["division"];
                    $hq = $_POST["hq"];

                    $fi = "customer_id,hq_id,div_id,approval_admin_id";
                    $va = ":customer_id,:hq_id,:div_id,:approval_admin_id";
                    $ex = array(
                                ":customer_id"=>$savecust,
                                ":hq_id"=>$hq,
                                ":div_id"=>$division,
                                ":approval_admin_id"=>"1"
                            );

                    $savecusthqdiv = save("customer_hq_div",$fi,$va,$ex);
                   
                    
                    $data = $_POST;

                    foreach($data as $key=>$val)
                    {
                        $customer_id = $savecust;
                        $customer_meta_key	= $key;
                        $customer_meta_value = $val;

                        $fields = "customer_id,customer_meta_key,customer_meta_value";
                        $values = ":customer_id,:customer_meta_key,:customer_meta_value";
                        $exe = array(":customer_id"=>$customer_id,":customer_meta_key"=>$customer_meta_key,":customer_meta_value"=>$customer_meta_value);
                        $savecustmeta = save("customer_meta",$fields,$values,$exe);
                    }

                    $url = "https://tdtl.world/vscm/PHPMailer/send_mail.php";
                    $data = array(
                            "mailto" => $email,
                            "subject" => "Customer Registration at VetrinaHealthcare" ,
                            "fullname" => "Customer Registration",
                            "fromname" => "Vetrina Healthcare",
                            "message" => "Dear ".$name.",<br>
                            <center><b>We Welcome you in<br>
                            Vetrina Family</b></center>
                            Kindly check your login credentials as follows,<br>
                            Email ID- ".$email."<br>
                            Password: 123456 <br>
                            To Place your first order please Visit our customer Panel on <a href='https://tdtl.world/vscm/customer_login.php'>Customer Login</a>."
                    );

                    $curl = curl_init($url);
                    curl_setopt($curl, CURLOPT_POST, true);
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                    $res = curl_exec($curl);
                    curl_close($curl);

                }
            }
            else 
            {
                $exe = array(
                            ":name"=>$name,
                            ":mobile_number"=>$mobile,
                            ":email"=> $email,
                            ":password"=>$password,
                            ":type"=>$type,
                            ":role"=>$role
                        );

                $savecust = save("customer",$fields,$values,$exe);
                $data = array("cust_id"=>$savecust,"action"=>"approve");
                registrationProcess($data);

                if($savecust)
                {
                    $filename =  $_FILES['file']['name'];
                    $filetempname =  $_FILES['file']['tmp_name'];

                    // print_r($filename);
                    // exit;
                    $i=0;
                    foreach ($filename as $key) {

                        $fname = $filename[$i];
                        $ftname = $filetempname[$i];
                        
                        // $filenames = $name."_".$fname;
                        
                        $i++;
                        move_uploaded_file($ftname, "kyc_documents/" . $fname);

                        $fields = "customer_id,document";
                        $values = ":customer_id,:document";
                        $exe = array(":customer_id" => $savecust,
                                    ":document" => $fname
                                );
                        $savekyc = save("customer_kyc_document",$fields,$values,$exe);
                        
                    }
            

                    $data = $_POST;

                    foreach($data as $key=>$val)
                    {
                        $customer_id = $savecust;
                        $customer_meta_key	= $key;
                        $customer_meta_value = $val;

                        $fields = "customer_id,customer_meta_key,customer_meta_value";
                        $values = ":customer_id,:customer_meta_key,:customer_meta_value";
                        $exe = array(":customer_id"=>$customer_id,":customer_meta_key"=>$customer_meta_key,":customer_meta_value"=>$customer_meta_value);
                        $savecustmeta = save("customer_meta",$fields,$values,$exe);
                    }

                        $url = "https://tdtl.world/vscm/PHPMailer/send_mail.php";
                        $data = array(
                                "mailto" => $email,
                                "subject" => "Customer Registration at VetrinaHealthcare" ,
                                "fullname" => "Customer Registration",
                                "fromname" => "Vetrina Healthcare",
                                "message" => "Dear ".$name.",<br>
                                            Thank you so much for showing interest. You are our valued customer. We will come back to you soon with your Login credentials  
                                            Cheers !<br>
                                            For more information please contact  <a href='tel:8600844450'>8600844450.</a>"
                        );

                        $curl = curl_init($url);
                        curl_setopt($curl, CURLOPT_POST, true);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                        $res = curl_exec($curl);
                        curl_close($curl);

                        $send_form_id = "0";
                        $send_to_id = "1";
                        $notify_text = "New Customer Registration Request for Approval";
                        notify($send_form_id,$send_to_id,$notify_text);
                }
            }
        }
    }

    $customer_roles = find("all","customer_roles","*","where 1",array());
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("registration_header.php"); ?>
        <!-----maincontent start----->
            <div class="content-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <form action="" method="POST" enctype="multipart/form-data">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-3">
                                            <label for="">Who Are you?</label>
                                            <select name="cust_role" id="cust_role" onchange="getcustomerform(this.value)" class="form-control">
                                                <option value="">Select Role</option>
                                                <?php foreach($customer_roles as $k=>$v) { ?>
                                                    <option value="<?=$v["cust_role_id"]?>"><?=$v["role_name"]?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div id="customer_form">

                                    </div>
                                </div>
                                <div class="card-footer" hidden>
                                    <div class="row mt-3">
                                        <input type="checkbox" name="" onclick="acceptTerms()" id="terms"> &nbsp;&nbsp; I Accept all terms and conditions. <br>
                                    </div>
                                    <div class="row mt-3">
                                        <button type="submit" id="submitbtn" disabled name="submit" class="btn btn-success btn-lg shadow">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        </div>        
                    </div>
                </div> 
            </div>       
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

        <script>
           
           $(function(){
               $(".hamburger").click();
           });

            function getcustomerform(cust_role)
            {
                $.ajax({
                    url:"ajax/get_customer_form.php",
                    method:"POST",
                    data : {cust_role:cust_role}
                }).done(function(response){
                    $("#customer_form").html(response);
                    $('.card-footer').removeAttr('hidden'); 
                    
                });

            }

            function getfarmertype(type)
            {
                $.ajax({
                    url:"ajax/getfarmertype.php",
                    method:"POST",
                    data:{type:type}
                }).done(function(response){
                    $("#farmertype").append(response);
                });
            }

            function acceptTerms()
            {
                if($("#terms:checked")){
                    $('#submitbtn').removeAttr('disabled'); 
                    $('#submitbtn').css('backgroundcolor','#2bc155');
                }
                else
                {
                    $('#submitbtn').attr('disabled','true'); 
                }
               
            }
            
            
        </script>
    
</body>
</html>
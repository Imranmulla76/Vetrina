<?php 

include("init.php");

$user_id = $_SESSION['user_id'];
$type = $_SESSION['type'];

/* select ad.admin_id, ad.username, ad.line_manager,
am.mob_number_company, d.division_name
from admin ad, admin_meta am, admin_hq_div ahd, divisions d
where ad.admin_id= (select admin_id from admin_hq_div where hq_id = (select hq_id from vetzone_hq_div where vetzone_id = 4))
and ad.admin_id = am.admin_id
and ad.admin_id = ahd.admin_id
and ahd.div_id = d.division_id; */
$table = "admin ad, admin_meta am, admin_hq_div ahd, divisions d";
$value = "ad.admin_id, ad.username, ad.line_manager, am.mob_number_company, d.division_name";

if($type == 'vetzone')
{
    $where = "where ad.admin_id= (select admin_id from admin_hq_div where hq_id = (select hq_id from vetzone_hq_div where vetzone_id = $user_id)) and ad.admin_id = am.admin_id and ad.admin_id = ahd.admin_id and ahd.div_id = d.division_id";
}
else if($type == 'customer')
{
    $where = "where ad.admin_id= (select admin_id from admin_hq_div where hq_id = (select hq_id from customer_hq_div where customer_id = $user_id)) and ad.admin_id = am.admin_id and ad.admin_id = ahd.admin_id and ahd.div_id = d.division_id";
}

$vsoQry = find("first", $table, $value, $where, array());
// print_r($vsoQry);
// echo "Name : ".$vsoQry['username']."<br/> Contact : ".$vsoQry['mob_number_company']."<br/> Division : ".$vsoQry['division_name'];
$line_manager = $vsoQry['line_manager'];
$where = "where ad.admin_id = $line_manager and ad.admin_id = am.admin_id and ad.admin_id = ahd.admin_id
and ahd.div_id = d.division_id";
$asmQry = find("first", $table, $value, $where, array());

$line_manager = $asmQry['line_manager'];;
$where = "where ad.admin_id = $line_manager and ad.admin_id = am.admin_id and ad.admin_id = ahd.admin_id
and ahd.div_id = d.division_id";
$zsmQry = find("first", $table, $value, $where, array());

$line_manager = $zsmQry['line_manager'];;
$where = "where ad.admin_id = $line_manager and ad.admin_id = am.admin_id and ad.admin_id = ahd.admin_id
and ahd.div_id = d.division_id";
$nsmQry = find("first", $table, $value, $where, array());

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    
</head>
<body>
   <?php include("preloader.php"); ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        
        <div class="content-body">
            <!-- row -->
            <div class="container-fluid">        
                <div class="row">
                    <div class="col-xl-12 col-xxl-12">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="card avtivity-card">
                                    <div class="card-body">
                                        <div class="media align-items-center">
                                            
                                            <div class="media-body">
                                                <p class="fs-14 mb-2">Supplier</p>
                                                <span class="title text-black font-w600">Vetrina Healthcare Pvt Ltd</span><br>
                                                <span>GAT No 1192, Milkat No 27,42 ,<br>
                                                    Opp. Maharashtra Car Care,A/p : Wadki<br>
                                                    Tal-Haveli, Pune-412308.<br>
                                                    PHONE : 7410027596</span>
                                            </div>
                                        </div>
                                        <div class="progress" style="height:5px;">
                                            <div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
                                                <span class="sr-only"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="effect bg-success"></div>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="card avtivity-card">
                                    <div class="card-body">
                                        <div class="media align-items-center">
                                            
                                            <div class="media-body">
                                                <p class="fs-14 mb-2">VSO</p>
                                                <span class="title text-black font-w300"><?="Name : ".$vsoQry['username']."<br/> Contact : ".$vsoQry['mob_number_company']."<br/> Division : ".$vsoQry['division_name'];?></span>
                                            </div>
                                        </div>
                                        <div class="progress" style="height:5px;">
                                            <div class="progress-bar bg-secondary" style="width: 100%; height:5px;" role="progressbar">
                                                <span class="sr-only"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="effect bg-secondary"></div>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="card avtivity-card">
                                    <div class="card-body">
                                        <div class="media align-items-center">
                                            
                                            <div class="media-body">
                                                <p class="fs-14 mb-2">ASM</p>
                                                <span class="title text-black font-w300"><?="Name : ".$asmQry['username']."<br/> Contact : ".$asmQry['mob_number_company']."<br/> Division : ".$asmQry['division_name'];?></span>
                                            </div>
                                        </div>
                                        <div class="progress" style="height:5px;">
                                            <div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
                                                <span class="sr-only"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="effect bg-danger"></div>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="card avtivity-card">
                                    <div class="card-body">
                                        <div class="media align-items-center">
                                            
                                            <div class="media-body">
                                                <p class="fs-14 mb-2">ZSM</p>
                                                <span class="title text-black font-w300"><?="Name : ".$zsmQry['username']."<br/> Contact : ".$zsmQry['mob_number_company']."<br/> Division : ".$zsmQry['division_name'];?></span>
                                            </div>
                                        </div>
                                        <div class="progress" style="height:5px;">
                                            <div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
                                                <span class="sr-only"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="effect bg-danger"></div>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="card avtivity-card">
                                    <div class="card-body">
                                        <div class="media align-items-center">
                                            
                                            <div class="media-body">
                                                <p class="fs-14 mb-2">NSM</p>
                                                <span class="title text-black font-w300"><?="Name : ".$nsmQry['username']."<br/> Contact : ".$nsmQry['mob_number_company']."<br/> Division : ".$nsmQry['division_name'];?></span>
                                            </div>
                                        </div>
                                        <div class="progress" style="height:5px;">
                                            <div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
                                                <span class="sr-only"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="effect bg-danger"></div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
</body>
</html> 


<script>

</script>
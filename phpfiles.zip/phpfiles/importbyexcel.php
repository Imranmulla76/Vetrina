<?php 
    include('init.php');


    // include('header.php');

    require_once('import-xlsx/vendor/php-excel-reader/excel_reader2.php');
    require_once('import-xlsx/vendor/SpreadsheetReader.php');

    if (isset($_POST["import"]))
    {
        
        $defaultpass = $_POST['pass'];
        $allowedFileType = array('application/vnd.ms-excel', 'text/xls', 'text/xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

        if (in_array($_FILES["file"]["type"], $allowedFileType))
        {
            $targetPath = 'import-xlsx/uploads/' . $_FILES['file']['name'];
            move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);
            $Reader = new SpreadsheetReader($targetPath);
            $sheetCount = count($Reader->sheets());

            for ($i = 0; $i < $sheetCount; $i++)
            {
                $Reader->ChangeSheet($i);
                if ($i == 0)
                {
                    $k = 0;
                    foreach ($Reader as $Row)
                    {
                        if ($k > 0)
                        {
                            $srno = (isset($Row[0])) ? $Row[0] : "";
                            $state_name = (isset($Row[1])) ? $Row[1] : "";
                            $alpha_code = (isset($Row[2])) ? $Row[2] : "";
                            $gst_state_code = (isset($Row[3])) ? $Row[3] : "";
                            //$holidaytype = (isset($Row[4])) ? $Row[4] : "";
                            
                            
                            // if($holidaytype == "Closed"){ $htype = "1"; }
                            // if($holidaytype == "NA"){ $htype = "1"; }
                            // if($holidaytype == "Restricted"){ $htype = "0"; }
                            
                            // $startdate = date("Y-m-d",strtotime($date));
                            // $enddate = date("Y-m-d",strtotime($date));
                            
                            // $company_id = "2";
                            // $description = $holidaytitle;
                            // $created_at = date("Y-m-d H:i:s");
                            
                            // print_r($htype." ".$holidaytype."<br>");
                            
                            //$fileds = "company_id,event_name,description,start_date,end_date,is_publish,created_at";
                            $fileds = "state_name,alpha_code,gst_state_code";
                            $values = ":state_name,:alpha_code,:gst_state_code";

                            $exe = array(
                                ":state_name" => $state_name,
                                ":alpha_code" => $alpha_code,
                                ":gst_state_code" => $gst_state_code,
                            );

                            //$values = ":company_id,:event_name,:description,:start_date,:end_date,:is_publish,:created_at";
                            // $exe = array(
                            //     "company_id"=> $company_id,
                            //     "event_name"=> $holidaytitle,
                            //     "description"=> $description,
                            //     "start_date"=> $startdate,
                            //     "end_date"=> $enddate,
                            //     "is_publish"=> $htype,
                            //     "created_at"=> $created_at
                            //     );
                            // print_r($exe);
                            $savestate = save("state_gst_code",$fileds,$values,$exe);
                            
                            print_r($saveholiday);
                            
                        }
                        $k++;
                    }
                }
            }
        }
        else
        {
            $type = "error";
            $message = "Invalid File Type. Upload Excel File.";
        }
    }
?>

<body>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <form action="" method="POST" name="frmExcelImport" id="frmExcelImport" enctype="multipart/form-data">
                    <div class="col-sm-12 mt-4">
                        <label>Choose CSV File</label>
                        <div class="input-group">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" name="file" id="file" accept=".xls,.xlsx">
                                <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 mt-2">
                        <button type="submit" id="submit" name="import" class="btn btn-primary">Import</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>


<!-- <?php //include('footer.php'); ?> -->

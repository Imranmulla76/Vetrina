<?php 
    include("init.php");

    $admin_id = $_SESSION["user_id"];

    $get_admin_hq_div = find("first","admin_hq_div","*","where admin_id='$admin_id'",array());

    $admin_hq = $get_admin_hq_div["hq_id"];
    $admin_div = $get_admin_hq_div["div_id"];

    $table_customer = "customer as c inner join customer_hq_div as chd on c.customer_id=chd.customer_id";
    $get_all_customer = find("all",$table_customer,"*","where chd.hq_id='$admin_hq' and chd.div_id='$admin_div'",array());

    // print_r($get_all_vetzone);

    $table_vetzone = "vetzone as v inner join vetzone_hq_div as vhd on v.vetzone_id=vhd.vetzone_id";
    $get_all_vetzone = find("all",$table_vetzone,"*","where vhd.hq_id='$admin_hq' and vhd.div_id='$admin_div'",array());

    // print_r($get_all_vetzone);
   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
       <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <b class="card-title">Party wise Invoice wise Sales</b>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="report" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>SR.No.</th>
                                                <th>Name Of Party</th>
                                                <th>Invoice Number</th>
                                                <th>Invoice Amount</th>
                                                <th>Party Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           
                                           <?php $i=0;
                                                  $cust_sale = 0;
                                                foreach($get_all_customer as $key=>$val)
                                                { 
                                                    $i++;
                                                    $customer_id = $val["customer_id"];
                                                    $get_cust_sale = find("all","order_table_product","*","where user_id='$customer_id' and user_role!='VetZone' group by order_id",array());
                                                    $rows = count($get_cust_sale);
                                                    if($rows==0)
                                                    {
                                                        $rows = 1;
                                                    }
                                            ?>      
                                            <tr>
                                                <td></td>
                                                <td><?=$val["name"]?></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>     
                                                <?php 
                                                    $total_amount = 0;
                                                    foreach($get_cust_sale as $k=>$v) 
                                                    { $i++;
                                                        $order_id = $v["order_id"];
                                                        $get_order_detail = find("first","order_table_product","sum(quantity*rate) as invoice_amount","where order_id='$order_id'",array());
                                                        $total_amount = $total_amount+ $get_order_detail["invoice_amount"];
                                                ?>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td><?= $order_id?></td>
                                                <td><?=$get_order_detail["invoice_amount"]?></td>
                                                <td></td>
                                            </tr>
                                            
                                           <?php } ?> 
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td><b>Total</b></td>
                                                <td><b><?=$total_amount ?></b> </td>
                                            </tr>
                                           <?php } $total_amount =0; ?>

                                           <?php $j=$i;
                                                 $vet_sale =0;
                                                 
                                                foreach($get_all_vetzone as $key=>$val)
                                                { 
                                                    $j++;
                                                    $vetzone_id = $val["vetzone_id"];
                                                    $get_vet_sale = find("all","order_table_product","*","where user_id='$vetzone_id' and user_role='VetZone' group by order_id",array());
                                                    $rows = count($get_vet_sale);
                                                    if($rows==0)
                                                    {
                                                        $rows = 1;
                                                    }
                                            ?>  

                                            <tr>
                                                <td></td>
                                                <td><?=$val["name"]?></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>    
                                                <?php 
                                                    $total_amount = 0;
                                                    foreach($get_vet_sale as $k=>$v) 
                                                    {
                                                        $order_id = $v["order_id"];
                                                        $get_order_detail = find("first","order_table_product","sum(quantity*rate) as invoice_amount","where order_id='$order_id'",array());
                                                        $total_amount = $total_amount+ $get_order_detail["invoice_amount"];
                                                ?>
                                            <tr>
                                                <td> </td>
                                                <td> </td>
                                                <td><?=$v["order_id"]?></td>
                                                <td><?=$get_order_detail["invoice_amount"]?></td>
                                                <td></td>
                                            </tr>
                                                <?php } ?> 
                                                <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td><b>Total</b></td>
                                                <td> <b><?=$total_amount ?></b> </td>
                                            </tr> 
                                            <?php } $total_amount=0;?>
                                        </tbody>
                                       
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
        
        <script>
            $(document).ready(function() {
            $('#report').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            } );
        });
        </script>
</body>
</html>
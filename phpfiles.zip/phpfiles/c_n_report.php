<?php

include("init.php");
// print_r($_SESSION);exit;
$roles = $_SESSION['role'];
$type = $_SESSION['type'];


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    <link rel="stylesheet" href="./vendor/select2/css/select2.min.css">

</head>
<body>

<?php include("preloader.php") ?>

<div id="main-wrapper">
    <?php include("navbar.php"); ?>
    <?php include("chatbox.php"); ?>
    <?php include("header.php"); ?>
    <?php include("sidebar.php"); ?>
    <!-----maincontent start----->
    <div class="content-body">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                        <div class="table-responsive">
                                <table id="cnreport" class="display min-w850">

                                    <thead>                                        
                                        <tr>
                                            <th>Sr.No</th>
                                            <th>Credit Note Number</th>
                                            <th>Date</th>
                                            <th>Value</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>                                   
                                        </tr>
                                        
                                    </tbody>

                                    <tfoot>
                                        <tr>                                            
                                        </tr>
                                    </tfoot>

                                </table>
                            </div>

                            <div class="table-responsive">
                                <table id="productreport" class="display min-w850">

                                    <thead>                                        
                                        <tr>
                                            <th>Sr.No</th>
                                            <th>Product</th>
                                            <th>SKU</th>
                                            <th>Batch</th>
                                            <th>Quantity</th>
                                            <th>Expiry Date</th>
                                            <th>PTV</th>
                                            <th>Value</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td> 
                                            <td></td>                                    
                                        </tr>
                                        
                                    </tbody>

                                    <tfoot>
                                        <tr>                                            
                                        </tr>
                                    </tfoot>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-------main content end----->
<?php include("footer.php"); ?>
</div> 
<?php include("jslink.php"); ?>


<script>

$(document).ready(function () {
    $("#productreport").hide();
    getcnreport();
    /* alert("function called");
    $.ajax({ 
        url: "ajax/get_customer_cn_report.php",
        type: "POST",
        data: { 
            action : 'getcnreport',
        },
        success: function(data) {
            alert(data);
            }
    }); */
});

function getcnreport()
{
    cnreporttable = $("#cnreport").DataTable({
        responsive: true,
        dom: 'lfrtip',

        "ajax":
			  {
			  	'url' : 'ajax/get_customer_cn_report.php',
				'type': 'POST',
				'data': {
						 action : 'getCN',
						},
				
			  },        

        columnDefs: [
            {
                render: function (data, type, row) {
                    return '<a class = "nav-danger clickable" onclick = "getValue('+data+');" id = "">' + data + '</a>';
                },
                targets: 1,
            },

            /* { 
                visible: false, 
                targets: [1,2,4] 
            }, */
        ],

        destroy : true,
        
    }); 
}

function getreport(returnid)
{  
    $("#productreport").show();
    productreporttable = $("#productreport").DataTable({
        responsive: true,
        dom: 'lfrtip',

        "ajax":
			  {
			  	'url' : 'ajax/get_customer_cn_report.php',
				'type': 'POST',
				'data': {
						 action : 'getProductDetails',
                         return_id : returnid
						},
				
			  },     

        destroy : true,
        
    });    
}


function getValue(returnid)
{
    getreport(returnid);
    /* alert("function called " + returnid + "value : " + act);
    $.ajax({ 
        url: "ajax/get_cnreport.php",
        type: "POST",
        data: { 
            action : 'approval',
            returnid : returnid,
            act : act,
        },
        success: function(data) {
            alert(data);
            }
    }); */
}

</script>

</body>
</html>
<?php include("init.php");
        //check_login();

    if(isset($_POST["save_category"]))
    {
        $category = $_POST["category"];
        $savecategory = save("product_category","category_name",":category_name",array(':category_name'=>$category));
    }

    if(isset($_POST["update_category"]))
    {
        $category = $_POST["category"];
        $category_id = $_POST["category_id"];

        $f = "category_name=:category_name";
        $where = "where category_id='$category_id'";
        $exe = array(":category_name"=>$category);
        $update = update("product_category",$f,$where,$exe);
    }

    $findcategory = find("all","product_category","*","where 1",array());

   

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
   <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
                    <button class="btn btn-primary" data-target=".bd-example-modal-sm" data-toggle="modal">+ Add Category</button>
				</div>

                <div class="row mt-3">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Categories</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table  id="example3" class="display min-w850">
                                <thead>
                                    <tr>
                                        <th>SR No.</th>
                                        <th>Category</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php //print_r($finddesignations); ?>
                                    <?php $i=0; foreach($findcategory as $k=>$v) { $i++;?>
                                    <tr>
                                        <td><?=$i;?></td>
                                        <td><?=$v["category_name"]?></td>
                                        <td>
                                            <div class="d-flex">
                                                    <button class="btn btn-primary shadow btn-xs sharp mr-1" onclick="updateCategory(<?=$v['category_id']?>)"><i class="fa fa-pencil"></i></button>
                                                <!-- <a href="#" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a> -->
											</div>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                                </table>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>


    <!-- Create Modal -->
 <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Create Category</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <form action="" method="POST">
            <div class="modal-body">
                
                    <label for="">Category</label>
                    <input type="text" class="form-control" name="category" id="">
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" name="save_category">Save Category</button>
            </div>
            </form>
        </div>
    </div>
</div>
 <!-- Create Modal -->

  <!-- Update Modal -->
 <div class="modal fade bd-example-modal-sm1" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update Category</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <form action="" method="POST">
            <div class="modal-body" id="category">
                
                                    
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" name="update_category">Update Category</button>
            </div>
            </form>
        </div>
    </div>
</div>
 <!-- Update Modal -->

 <?php include("jslink.php"); ?>

 <script>
      $(document).ready(function(){
                <?php if($savecategory) { ?>
                    swal("Category Added","New Category Created","success");    
                <?php } ?>
            });

        function updateCategory(category_id)
        {
             $(".bd-example-modal-sm1").modal("show");

                $.ajax({
                    url:"ajax/update_category.php",
                    method:"POST",
                    data:{category_id:category_id}
                }).done(function(response){
                    $("#category").html(response);
                });
        }    
 </script>
    
</body>
</html>
<?php include("init.php");
    
    $roll = $_SESSION["roll"];

    if($_SESSION["type"]=="customer")
    {
        $link = "customer_login.php";
    }
    else if($_SESSION["type"]=="user")
    {
        $link = "user_login.php";
    }
    else if($_SESSION["type"]=="vetzone")
    {
        $link = "vetzone_login.php";
    }
    else
    {
        $link = "index.php";
    }

 foreach($_SESSION as $key=>$val)
 {
     if(isset($_SESSION[$key]))
     {
        echo $_SESSION[$key]."<br>";
        unset($_SESSION[$key]);
     }
 }
 session_destroy();

redirectfn("$link");

?>


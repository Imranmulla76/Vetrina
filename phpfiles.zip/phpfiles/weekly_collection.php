<?php include("init.php");
        //check_login();
    $table = "placeorder as p inner join order_table_product as otp on p.stockiest_order_id=otp.order_id inner join customer as c on otp.user_id=c.customer_id inner join customer_hq_div as chd on c.customer_id=chd.customer_id inner join headquarters as hq on chd.hq_id=hq.hq_id";

    $month = date("m");
    $date = date("Y-m-"."01");
    // echo $date." ".$month;
    // exit;
    $customerorderdetails = find("all",$table,"*,sum(rate * quantity) amt , date(created_at + INTERVAL 45 DAY) duedate, WEEK('$date') firstweek,CONCAT(WEEK(created_at)) week, concat((WEEK(created_at) - WEEK('$date')) + 1) mothwiseweek"," where otp.user_role <> 'VetZone' and month(created_at) = '$month' group by otp.user_id order by mothwiseweek","where p.payment_method='Credit' and p.user_role!='vetZone' group by otp.user_id ",array());
    $totaldueamt = 0;
    
    
// SELECT *, sum(rate * quantity), date(created_at + INTERVAL 45 DAY) duedate, WEEK('2022-07-01') firstweek,
// CONCAT(WEEK(created_at)) week, concat((WEEK(created_at) - WEEK('2022-07-01')) + 1) mothwiseweek
// FROM `order_table_product`
// where user_role < 'VetZone'
// and month(created_at) = '07'
// group by user_id
// order by mothwiseweek;

    // foreach( $customerorderdetails as $k=>$v)
    // {
    //     $dueamt = $v["amount"];
    //     $totaldueamt = $totaldueamt+$dueamt;
    // }

    if(isset($_POST["search"]))
    {

        $month = $_POST["month"];
        //echo $month; 
        if($month="04"||$month="05"||$month="06"||$month="07"||$month="08"||$month="09"||$month="10"||$month="11"||$month="12")
        {
            $year = date("Y");
            $date =  date('Y-m-d', strtotime($year."-".$month."-01"));
            // echo $date;
            // exit;
        }
        else {
            $year = date("Y");
            $nextyear = $year+1;
            $date = date("Y-m-d",strtotime($nextyear."-".$month."-01"));
            // echo "year :".$year."Date :".$date;
            // exit;
        }
        
       
        $customerorderdetails = find("all",$table,"*,sum(rate * quantity), date(created_at + INTERVAL 45 DAY) duedate, WEEK('$date') firstweek,CONCAT(WEEK(created_at)) week, concat((WEEK(created_at) - WEEK('$date')) + 1) mothwiseweek"," where user_role <> 'VetZone' and month(created_at) = '$month' group by user_id order by mothwiseweek","where payment_method='Credit' and p.user_role!='vetZone' group by otp.user_id ",array());
        // $customerorderdetails = find("all",$table,"*,sum(tax) as amount","where payment_method='Credit' and p.user_role!='vetZone' group by otp.order_id and DATE(created_at) = '$date'",array());
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
   <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
                    <div class="col-2">
                        <form action="" method="POST">
                        <label for="">Month</label>
                        <select name="month" class='form-control' id="">
                            <option value="">Select Month</option>
                            <option value="04">April</option>
                            <option value="05">May</option>
                            <option value="06">June</option>
                            <option value="07">July</option>
                            <option value="08">Aug</option>
                            <option value="09">Sep</option>
                            <option value="10">Oct</option>
                            <option value="11">Nov</option>
                            <option value="12">Dec</option>
                            <option value="01">Jan</option>
                            <option value="02">Feb</option>
                            <option value="03">March</option>
                        </select>
                        <br><br>
                        <button type="submit" name="search" class="btn btn-sm btn-primary">Search</button>
                        </form>

                    </div>
                </div>

                <div class="row mt-3">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Weekly Collections</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table  id="example3" class="display min-w850">
                                <thead>
                                    <tr>
                                        <th>SR No.</th>
                                        <th>Party Name</th>
                                        <th>Week I</th>
                                        <th>Week II</th>
                                        <th>Week III</th>
                                        <th>Week IV</th>
                                        <th>Week V</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i=0; foreach($customerorderdetails as $key=>$val) { $i++;
                                        $invoicedate = date("d-M-Y",strtotime($v["created_at"]));
                                        $duedate = date("d-m-Y",strtotime($invoicedate.'+ 45 day'));
                                    
                                    ?>
                                    <tr>
                                        <td><?=$i?></td>
                                        <td><?=$val["name"]?></td>
                                        <td>
                                            <?php if($val["mothwiseweek"]==1) { 
                                                echo $val["amt"];
                                            }?>
                                        </td>
                                        <td>
                                             <?php if($val["mothwiseweek"]==2) { 
                                                echo $val["amt"];
                                             }?>
                                        </td>
                                        <td>
                                            <?php if($val["mothwiseweek"]==3) { 
                                                echo $val["amt"];
                                            }?>
                                        </td>
                                        <td>
                                            <?php if($val["mothwiseweek"]==4) { 
                                                echo $val["amt"];
                                            }?>
                                        </td>
                                        <td>
                                            <?php if($val["mothwiseweek"]==5) { 
                                                echo $val["amt"];
                                            }?>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                                </table>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
 <?php include("jslink.php"); ?>

</body>
</html>
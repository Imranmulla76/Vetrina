<?php 
    include("init.php");
   
    $order_id = $_GET["order_id"];

    
    $getcustomertype = find("first","placeorder","*","where stockiest_order_id='$order_id'",array());
    $customerrole = $getcustomertype["user_role"];

    if($customerrole=="VetZone")
    {
        $table = "order_table_product as otp inner join placeorder as p on otp.order_id=p.stockiest_order_id inner join product as pd on otp.product_id=pd.product_id inner join vetzone as c on p.user_id=c.vetzone_id";
        $order_detail = find("all",$table,"*","where otp.order_id='$order_id'",array());

        $getcustomer = find("first","placeorder as p inner join vetzone as c on p.user_id=c.vetzone_id","*","where stockiest_order_id='$order_id'",array());
        $customer_id = $getcustomer["vetzone_id"];
        $comment = $getcustomer["comment"];

         $customer_meta = find("all","vetzone_meta","*","where vetzone_id='$customer_id'",array());

        foreach($customer_meta as $key=>$val)
        {
            if($val["vetzone_meta_value"]!="")
            {
                define($val["vetzone_meta_key"],$val["vetzone_meta_value"]);
            }
            else
            {
                define($val["vetzone_meta_key"],"0");
            }
        }
    }
    else {
        $table = "order_table_product as otp inner join placeorder as p on otp.order_id=p.stockiest_order_id inner join product as pd on otp.product_id=pd.product_id inner join customer as c on p.user_id=c.customer_id";
        $order_detail = find("all",$table,"*","where otp.order_id='$order_id'",array());
    
        $getcustomer = find("first","placeorder as p inner join customer as c on p.user_id=c.customer_id","*","where stockiest_order_id='$order_id'",array());
        $customer_id = $getcustomer["customer_id"];
        $comment = $getcustomer["comment"];
        
        $customer_meta = find("all","customer_meta","*","where customer_id='$customer_id'",array());

        foreach($customer_meta as $key=>$val)
        {
            if($val["customer_meta_value"]!="")
            {
                define($val["customer_meta_key"],$val["customer_meta_value"]);
            }
            else
            {
                define($val["customer_meta_key"],"0");
            }
        }
    }

   

    if(isset($_POST["orderid"]))
    {
      
      $order_id = $_POST["orderid"];
      $filename = "supplyBill";

       $curl = curl_init("https://vetrinahealthcare.com/dms/html2pdf/pdfsupplybill.php");
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, "order_id=$order_id");
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($curl);
        curl_close($curl);

        $data =  "success";

      $mailcontent = "New Invoice created and attached with the mail.";
      $mailsubject = "New Invoice For Order";
      $to = $email; //"tushar.patil@tdtl.world";
      contractMailwithattach($to,$mailsubject,$mailcontent,$filename);

    }

    if(isset($_POST["netamount"]))
    {
        $netamount = $_POST["netamount"];
        $product_id = $_POST["product_id"];
        $dicountamount = $_POST["dicper"];
        $taxable = $_POST["taxable"];
        $order_id = $_POST["order_id"];
        

        $setval = "disc=:disc,tax=:tax";
        $where = "where order_id='$order_id' and product_id='$product_id'";

        $exe = array(":disc"=>$dicountamount,":tax"=>$taxable);
        $updatetable = update("order_table_product",$setval,$where,$exe);
        
        
        echo strtoupper(NumberToIndianCurrency($netamount))."+".$orderid;
        exit;
    }
     
        
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supply Bill</title>
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <style>
        table {
            width: 90%;
            margin: auto;
        }

        table,
        .tb-row
        td {
            border-collapse: collapse;
            border: 1px solid #000;
        }
        .tb2 td{
            border-right: 1px solid #000 !important;
        }
        .disclaimer
        {
            font-size:12px;
            font-weight: 500;
            margin-left:84px;
            margin-top:12px;
        }
       
    </style>


</head>

<body>
    <div class="supplyBill" id="temp-target">

        <h5 style="text-align: center;  margin-top: 30px;  margin-bottom: 0px;">DELIVERY CHALLAN</h5>
        <table>
            <tbody>
                <tr class="tb-row">
                    <td colspan="3" style="padding-left: 15px;font-weight: 500;"><strong>VETRINA HEALTHCARE PVT. LTD.</strong><br>
                        GAT No 1192, Milkat No 27,42 ,<br>
                        Opp. Maharashtra Car Care,A/p : Wadki<br>
                        Tal-Haveli, Pune-412308.<br>
                        PHONE : 7410027596</td>
                    <td colspan="5" style="padding-left: 15px;font-weight: 500;">State Code : 27 MAHARASHTRA<br>
                        GSTIN : 27AAECV1226C1ZR<br>
                        PAN No. : AAECV1226C<br>
                        D.L.No. : 20B-MH-PZ3-97796,<br>
                        21B-MH-PZ3-97797, 20D-MH-PZ3-97798</td>
                    <td colspan="3" style="padding-left: 15px;font-weight: 500;"><strong>Inv. No: <?=$getcustomer['stockiest_order_id']?><br>
                        Date : <?=date("d/m/Y",strtotime($getcustomer['created_date']))?></strong><br>
                        Due Dt : <?=date("d/m/Y",strtotime($getcustomer['created_date'].' + 45 days'))?><br>
                        Order No :  <?=$getcustomer['stockiest_order_id']?><br>
                        Order date : <?=date("d/m/Y",strtotime($getcustomer['created_date']))?></td>
                    <td colspan="7" style="padding-left: 15px;font-weight: 500;"><strong>To, <?=$getcustomer["name"]?></strong><br>
                        MOBILE : <?=$getcustomer["mobile_number"]?><br>
                        <?=$address?>, &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;State Code : 27<br>
                        SOUTH 24 PARGANAS-743347<br>
                        GSTIN : <?=gst_no?> PAN : <br>
                        D.L.No: 5240SW / 5231SBW</td>
                </tr>
                <tr class="tb-row" style="text-align: center; font-weight: bold;">
                    <td>Sr</td>
                    <td>HSN No</td>
                    <td>Product Description</td>
                    <td>Unit</td>
                    <td>Batch</td>
                    <td>Exp</td>
                    <td>Qty</td>
                    <td>Sch</td>
                    <td>M.R.P</td>
                    <td>P.T.S</td>
                    <td>P.T.R</td>
                    <td>Amount</td>
                    <td>Disc</td>
                    <td>Taxable</td>
                    <td colspan="2">% CGST Amt</td>
                    <td colspan="2">% SGST Amt</td>
                </tr>
                <?php $i=0; $total=0; $cgst=0; $sgst=0;
                
                    foreach($order_detail as $key => $value){ $i++;

                    $amount = $value['quantity']*$value["rate"];

                    $product_id = $value["product_id"];
                    $batch=$value['batch'];
                    $findbatch = find("first","instock","*","where product_id='$product_id' and batch='$batch' group by batch",array());
                    $expiry = date('m/y',strtotime($findbatch['expiry_date']));
                    
                    $findgst = find("first","product_gst","*","where product_id='$product_id'",array());
                    $cgstamt=($amount* $findgst["cgst"])/100;
                    $sgstamt=($amount* $findgst["sgst"])/100;
                ?>
                <tr class="tb2">
                    <td><?=$i?></td>
                    <td><?=$value["hsn_code"]?></td>
                    <td><?=$value['product_name']?><input hidden type="text" id="productid<?=$i?>" value="<?=$product_id?>"></td>
                    <td><?=$value['sku']?></td>
                    <td><?=$value['batch']?></td>
                    <td><?=$expiry?></td>
                    <td><?=$value['quantity']?></td>
                    <td><?=$value["scheme_name"]?></td>
                    <td><?=$value['mrp']?></td>
                    <td><?=$value['rate']?></td>
                    <td><?=$value['ptr']?></td>
                    <td id="amount<?=$i?>"><?=$amount?></td>
                    <td><input type="number" style="width:60px; padding:0px;" id="discount<?=$i?>" <?php if($value['disc'] > 0) { ?> value="<?=$value['disc']?>" readonly <?php } else { ?>onfocusout="caldisc(<?=$i?>)" <?php }?> name="discount" class="form-control" /></td>
                    <td id="tax<?=$i?>"></td>
                    <td id="cgst<?=$i?>"><?=$findgst["cgst"]?></td>
                    <td id="cgstamt<?=$i?>"><?=$cgstamt?></td>
                    <td id="sgst<?=$i?>"><?=$findgst["sgst"]?></td>
                    <td id="sgstamt<?=$i?>"><?=$sgstamt?></td>
                </tr>
                <?php 
                    $total = $total+$amount; 
                    $cgst = $cgst+$cgstamt;
                    $sgst = $sgst+$sgstamt;
                }
                $netamt = $total+$cgst+$sgst;
                ?>
                <tr class="tb-row mt-10" style="text-align: right; ">
                    <td colspan="11" style="text-align: left; padding-left: 10px;"><strong>Remark:</strong></td>
                    <td style="text-align: left;padding-left: 10px;"><?=$total?></td>
                    <td id="totaldiscamt">0.00</td>
                    <td id="totaltaxamt">0.00</td>
                    <td colspan="2" id="totalcgstamt" style="text-align: left;padding-left: 10px;"><?=$cgst?></td>
                    <td colspan="2" id="totalsgstamt" style="text-align: left;padding-left: 10px;"><?=$sgst?></td>
                </tr>
                <tr class="tb-row">
                    <td colspan="9" style="padding-left: 10px;"><strong> Rs. <span id="amountintext"><?=strtoupper(NumberToIndianCurrency($netamt))?></span> ONLY</strong></td>
                    <td rowspan="2" colspan="4" style="text-align: center;"><strong>For VETRINA HEALTHCARE PVT. LTD.</strong><br><br><br>Authorised Signatory</td>
                    <td rowspan="2" colspan="5">Bill Total <span id="billtotal" style="float:right;"><?=$total?></span><br>
                        LESS <span id="lessamt" style="float:right;">0.00</span><br>
                        GST ADD <span style="float:right;"><?=$cgst+$sgst?></span><br>
                        <p style="border-top: 1px solid #000;font-weight:bold;">NET AMT <span id="netamount" style="float:right;"><?=$netamt?></span></p>

                    </td>
                </tr>
                <tr class="tb-row">
                    <td colspan="5" style="padding-left: 10px; font-weight: 500;">BANK NAME :ICICI BANK BRANCH : KOTHRUD<br>
                        A/C NO. : 033805004644 IFSC CODE :ICIC0000338</td>
                        <td colspan="4" style="text-align: center;padding-top: 22px; font-weight: 500;">Receiver's signature</td>
                </tr>
            </tbody>
        </table>
        <p class="disclaimer">Any claim / dispute arise in respect of this invoice is subjected to jurisdiction of Pune court only.Any complaint with regards to quality & quantity must be made to us in writing within 8-days from the date of goods receipt, thereafter no complaint will be entertained</p>
    </div>
    <div class="row">
        <div class="col-md-12">
            <br><br>
           <center> <button onclick="converHTMLFileToPDF();" class="btn btn-primary"> <i class="fas fa-file-download"></i> Generate PDF</button></center>
           <!-- <form action="" method="POST">
             <input type="text" style="display:none;" name="orderid" value="<?php//$order_id?>" id="">
             <button type="submit" name="send" class="btn btn-warning"> <i class="fas fa-paper-plane"></i> Send Mail </span> </center> 
           </form> -->
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.3.1/jspdf.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.0/html2canvas.min.js" integrity="sha512-UcDEnmFoMh0dYHu0wGsf5SKB7z7i5j3GuXHCnb3i4s44hfctoLihr896bxM0zL7jGkcHQXXrJsFIL62ehtd6yQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>

        function converHTMLFileToPDF() 
        {
            const { jsPDF } = window.jspdf;
            var doc = new jsPDF('l', 'mm', [1800 , 1210]);

            var pdfjs = document.querySelector('#temp-target');

            // Convert HTML to PDF in JavaScript
            doc.html(pdfjs, {
                callback: function(doc) {
                    doc.save("Supply Bill.pdf");
                },
                x: 1,
                y: 2
            });
        }

        var totaldicountamount=0;
        var totaltaxableamount=0;
        var totalcgstamount=0;
        var totalsgstamount=0;
               
        function caldisc(rownum)
        {
            // alert(dicper);
            var dicper = $("#discount"+rownum).val();
            var amount = $("#amount"+rownum).text();
            var cgst = $("#cgst"+rownum).text();
            var sgst = $("#sgst"+rownum).text();

            var dicountamount = (amount*dicper)/100;

            var taxable = amount-dicountamount;

            var cgstamount = (taxable*cgst)/100;
            var sgstamount = (taxable*sgst)/100;
           
            totaldicountamount = totaldicountamount+dicountamount;

            totaltaxableamount = totaltaxableamount+taxable;

            totalcgstamount = totalcgstamount+cgstamount;
            totalsgstamount = totalsgstamount+sgstamount;


            $("#tax"+rownum).html(taxable);

            $("#cgstamt"+rownum).html(cgstamount);
            $("#sgstamt"+rownum).html(sgstamount);

            $("#totaldiscamt").html(totaldicountamount);
            $("#totaltaxamt").html(totaltaxableamount);

            $("#totalcgstamt").html(totalcgstamount);
            $("#totalsgstamt").html(totalsgstamount);

            $("#billtotal").html(totaltaxableamount);
            $("#lessamt").html(totaldicountamount);

            var netamount = totaltaxableamount + totalcgstamount + totalsgstamount;
            
            //  console.log(numberintext);

            $("#netamount").html(netamount.toFixed(2));

            // updating data in table Order_table_product
            var product_id = $("#productid"+rownum).val();
            var order_id = <?php echo $order_id; ?>
        

            $.ajax({
                url:"invoice.php",
                method:"POST",
                data:{
                    netamount:netamount,
                    product_id:product_id,
                    dicper:dicper,
                    taxable:taxable,
                    order_id:order_id
                }
           }).done(function(response){
            response = response.split("+");
               $("#amountintext").html(response[0]);
           });


        }

    
    </script>

</body>

</html>
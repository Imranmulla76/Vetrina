<?php 

	$getcustomers = find("all","customer","*","where 1",array());
	$totalcustomer = count($getcustomers);

	$getvetzone = find("all","vetzone","*","where 1",array());
	$totalvetzone = count($getvetzone);

	$getadmins = find("all","admin","*","where 1",array());
	$totalusers = count($getadmins);

	$getapprovals = find("all","customer","*","where approval_status='N'",array());
	$totalapprovals = count($getapprovals);

	$getstockiest = find("all","customer","*","where approval_status='Y' and role='2'",array());
	$totalstockiest = count($getstockiest);

	$getretailer = find("all","customer","*","where approval_status='Y' and role='4'",array());
	$totalretailer= count($getretailer);
	
	$getcf = find("all","customer","*","where approval_status='Y' and role='1'",array());
	$totalcf= count($getcf);
?>
<div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
					<div class="col-xl-12 col-xxl-12">
						<div class="row">
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-success mr-md-4 mr-3">
												<img src="images/target.png" alt="" width="40" height="40">
											</span>
											<div class="media-body">
												<p class="fs-14 mb-2">Total Customers</p>
												<span class="title text-black font-w600"><?=$totalcustomer?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-success"></div>
								</div>
							</div>
							
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-secondary  mr-md-4 mr-3">
												<img src="images/badge.png" alt="" width="40" height="40">
											</span>
											<div class="media-body">
												<p class="fs-14 mb-2">Total Users</p>
												<span class="title text-black font-w600"><?=$totalusers?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-secondary" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-secondary"></div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-danger mr-md-4 mr-3">
												<img src="images/commission.png" alt="" width="40" height="40">
											</span>
											<div class="media-body">
												<p class="fs-14 mb-2">Approvals</p>
												<span class="title text-black font-w600"><?=$totalapprovals?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-danger"></div>
								</div>
							</div>

							
						</div>
					</div>
				
				</div>

				<div class="row">
					<div class="col-6">
						<div class="card">
							<div class="card-header">
								<h4 class="card-title">Organization</h4>
							</div>
							<div class="card-body">
								Godown :<strong> </strong>
								<br>
								<br>
								 C & F :<strong> <?=$totalcf?></strong>
								<br>
								<br>
								 VetZone :<strong> <?=$totalvetzone?></strong>
							</div>
						</div>
					</div>

					<div class="col-6">
						<div class="card">
							<div class="card-header">
								<h4 class="card-title">Customers</h4>
							</div>
							<div class="card-body">
								Direct Customer :<strong>  </strong>
								<br>
								<br>
								Distributor: <strong> <?=$totalstockiest?></strong>
								<br>
								<br>
								Retailer : <strong> <?=$totalretailer?></strong>
							</div>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-6">
						<div class="card">
							<div class="card-header">
								<h4 class="card-title">Total Sale</h4>
							</div>
							<div class="card-body">
								Livestock :<strong> </strong>
								<br>
								<br>
								Canine:<strong></strong>
								<br>
								<br>
								Poultry :<strong></strong>
								<br>
								<br>
								Corporate :<strong> </strong>
							</div>
						</div>
					</div>

					<div class="col-6">
						<div class="card">
							<div class="card-header">
								<h4 class="card-title">Vouchers</h4>
							</div>
							<div class="card-body">
								Total Vouchers : <strong></strong>
								<br>
								<br>
								Purchase: <strong> </strong>
								<br>
								<br>
								Sale :<strong> </strong>
								<br>
								<br>
								LR : <strong> </strong>
								<br>
								<br>
								POD :<strong> </strong>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
<?php include("init.php");
       
       $roll = $_SESSION["roll"];

       if(isset($_POST["delete"]))
       {
           $cust_id = $_POST["cust_id"];

           $where ="where customer_id='$cust_id'";
           $exe = array();
           $deletecust = delete("customer",$where,$exe);

           if($deletecust)
           {
               $where ="where customer_id='$cust_id'";
               $exe = array();
               $deletecust_meta = delete("customer_meta",$where,$exe);
           }
       }

           $table = "customer as c inner join customer_roles as cr on c.role=cr.cust_role_id inner join distributor_type as dt on c.type=dt.distributor_type_id";
           $findcustomers = find("all",$table,"* ","where c.approval_status = 'Y' group by c.customer_id order by c.customer_id DESC ",array());
       
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Customers List</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.no</th>
                                                <th>Customer Name</th>
                                                <th>Role</th>
                                                <th>Type</th>
                                                <th>Email</th>
                                                <th>Mobile No.</th>
                                                <th>Registration Date</th>
                                                <th>Approal status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; foreach($findcustomers as $key=>$val) { $i++; 
                                              $created_date =$val['created_on'];
                                              $created_date = str_replace('-"', '/', $created_date);
                                              
                                              $newDate = date("y/m", strtotime($created_date));
                                              
                                             
                                                ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["name"]?></td>
                                                <td><?=$val["role_name"]?></td>
                                                <td><?=$val["distributor_type"]?></td>
                                                <td><?=$val["email"]?></td>
                                                <td><?=$val["mobile_number"]?></td>
                                                <td><?=$newDate?></td>
                                              
                                                <td>
                                                    <?php if($val["approval_status"]=="N")
                                                        { 
                                                            echo "<label class='label label-warning'>Pending</label>"; 
                                                        }
                                                        else {
                                                            echo "<label class='label label-success'>Approved</label>";
                                                        }
                                                        ?>
                                                </td>
                                                <td>
                                                    <div class="d-flex" >
                                                        <a href="customer_details.php?customer_id=<?php echo $val["customer_id"];?>" class="btn btn-info shadow btn-xs sharp mr-1"><i class="fa fa-eye"></i></a>
                                                        <form action="" method="POST">
                                                            <input type="text" name="cust_id" value="<?=$val["customer_id"]?>" hidden id="">
                                                            <button name="delete" type="submit" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>        
                </div>
            </div>
        </div>

        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
</body>
</html>
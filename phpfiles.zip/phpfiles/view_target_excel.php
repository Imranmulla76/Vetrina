<?php include("init.php");
        //check_login();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>

</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">

                <div class="row mt-3">
                    <div class="col-12">
                      <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Target Details</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example3" class="display min-w850">
                                <thead>
                                    <tr>
                                        <th>SR.No.</th>
                                        <th>Product Name</th>
                                        <th>Quantity</th>
                                        <th>SKU</th>
                                        <th>PTS</th>
                                        <th>Year</th>
                                        <th>Value</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php //print_r($finddesignations); ?>
                                    <?php $i=0; foreach($finduser as $k=>$v) { $i++;?>
                                    <tr>
                                        <td><?=$i;?></td>
                                        <td><?=$v["username"]?></td>
                                        <td><?=$v["admin_email"]?></td>
                                        <td><?=$v["mob_number_personal"]?></td>
                                        <td><?=$v["desig_name"]?></td>
                                        <td>   
                                            <?php if($v["status"]=="Y")  
                                            { ?><label class="btn btn-success btn-xs shadow">Active</label> <?php } 
                                            else { ?><label class="btn btn-danger btn-xs shadow">Inactive</label> <?php } ?>
                                        </td>
                                        <td>
                                            <div class="d-flex">
                                                <form action="" method='POST'>
                                                    <input type="text" hidden name="admin_id" value="<?=$v["admin_id"]?>" id="">
                                                    <button type="submit" name="delete" class="btn btn-danger shadow btn-xs sharp mr-1"><i class="fa fa-trash"></i></button>
                                                </form>
                                                <a href="profile.php?admin_id=<?php echo $v["admin_id"];?>" class="btn btn-info shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
											</div>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                                </table>
                            
                            </div>
                           
                        </div>
                    </div>
                    </div>
                </div>

            </div>
        </div>
        !-------main content end----->
        <?php include("footer.php"); ?>
    </div>

        <?php include("jslink.php"); ?>
</body>
</html>
<div class="header">
    <div class="header-content">
        <nav class="navbar navbar-expand">
            <div class="collapse navbar-collapse justify-content-between">
                <div class="header-left">
                    <div class="dashboard_bar">
                        <?php $pagename =  basename($_SERVER['PHP_SELF']); 
                                                                
                            $name = str_replace('.php'," ",$pagename);
                            $name = str_replace('_'," ",$name);
                            echo $name;
                        ?>
                    </div>
                </div>
            </div>
        </nav>
    </div>
</div>
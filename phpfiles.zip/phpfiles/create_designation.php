<?php include("init.php");
        //check_login();

    if(isset($_POST["save_desig"]))
    {
        $desig = $_POST["designation"];
        $savedesig = save("designations","desig_name",":desig_name",array(':desig_name'=>$desig));
    }

    if(isset($_POST["update_desig"]))
    {
        $desig = $_POST["designation"];
        $desig_id = $_POST["desig_id"];

        $f = "desig_name=:desig_name";
        $where = "where desig_id='$desig_id'";
        $exe = array(":desig_name"=>$desig);
        $update = update("designations",$f,$where,$exe);
    }

    $finddesignations = find("all","designations","*","where 1",array());

   

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
   <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
                    <button class="btn btn-primary" data-target=".bd-example-modal-sm" data-toggle="modal">+ Add Designation</button>
				</div>

                <div class="row mt-3">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Designations</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table  id="example3" class="display min-w850">
                                <thead>
                                    <tr>
                                        <th>SR No.</th>
                                        <th>Designation</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php //print_r($finddesignations); ?>
                                    <?php $i=0; foreach($finddesignations as $k=>$v) { $i++;?>
                                    <tr>
                                        <td><?=$i;?></td>
                                        <td><?=$v["desig_name"]?></td>
                                        <td>
                                            <div class="d-flex">
                                                    <button class="btn btn-primary shadow btn-xs sharp mr-1" onclick="updateDesignation(<?=$v['desig_id']?>)"><i class="fa fa-pencil"></i></button>
                                                <!-- <a href="#" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a> -->
											</div>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                                </table>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>


    <!-- Create Modal -->
 <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Create Designation</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <form action="" method="POST">
            <div class="modal-body">
                
                    <label for="">Designation</label>
                    <input type="text" class="form-control" name="designation" id="">
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" name="save_desig">Save Designation</button>
            </div>
            </form>
        </div>
    </div>
</div>
 <!-- Create Modal -->

  <!-- Update Modal -->
 <div class="modal fade bd-example-modal-sm1" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update Designation</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <form action="" method="POST">
            <div class="modal-body" id="desig">
                
                                    
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" name="update_desig">Update Designation</button>
            </div>
            </form>
        </div>
    </div>
</div>
 <!-- Update Modal -->

 <?php include("jslink.php"); ?>

 <script>
      $(document).ready(function(){
                <?php if($savedesig) { ?>
                    swal("Designation Added","New Designation Created","success");    
                <?php } ?>
            });

        function updateDesignation(desig_id)
        {
             $(".bd-example-modal-sm1").modal("show");

                $.ajax({
                    url:"ajax/update_desig.php",
                    method:"POST",
                    data:{desig_id:desig_id}
                }).done(function(response){
                    $("#desig").html(response);
                });
        }    
 </script>
    
</body>
</html>
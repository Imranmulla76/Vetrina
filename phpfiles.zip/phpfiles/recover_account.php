<?php 
 include("registrationinit.php");
$response= "";
$response_status = "none";
$type=$_GET["type"];

 if(isset($_POST["sendmail"]))
 {
    $email = $_POST["email"];
    $response= "This Email not found";
    $response_status = "error";

    if($type=='admin' || $type=='user')
    {
        $find= find("first","admin","*"," where admin_email='$email' and status='Y'",array());
        

         if($find)
        {
            $name=$find["username"];
            $id=$find["admin_id"];

            $url = "https://vscm.vetrinahealthcare.com/PHPMailer/send_mail.php";
            $data = array(
                    "mailto" => $email,
                    "subject" => "Reset Password at VetrinaHealthcare" ,
                    "fullname" => $name,
                    "fromname" => "Vetrina Healthcare",
                    "message" => "Dear ".$name.",<br>
                                Please Click on following link to reset your password.<br>
                                <a href='https://vscm.vetrinahealthcare.com/reset_password.php?id=$id&&type=$type'>Click here to reset your password</a><br>
                                For more information please contact  <a href='tel:8600844450'>8600844450.</a>"
            );

            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $res = curl_exec($curl);
            curl_close($curl);

            $response= "Email sent successfully ,please Check Your Email ";
            $response_status = "success";

        }
    
    }
    else if($type=='customer')
    {
       
        $find= find("first","customer","*"," where email='$email'",array());

        // echo $email;
        // print_r($find);
        // exit;

         if($find)
        {
            $name=$find["name"];
            $id=$find["customer_id"];
          
            $url = "https://vscm.vetrinahealthcare.com/PHPMailer/send_mail.php";
            $data = array(
                    "mailto" => $email,
                    "subject" => "Reset Password at VetrinaHealthcare" ,
                    "fullname" => $name,
                    "fromname" => "Vetrina Healthcare",
                    "message" => "Dear ".$name.",<br>
                                Please Click on following link to reset your password.<br>
                                <a href='https://vscm.vetrinahealthcare.com/reset_password.php?id=$id&&type=$type'>Click here to reset your password</a>
                                For more information please contact  <a href='tel:8600844450'>8600844450.</a>"
            );

            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $res = curl_exec($curl);
            curl_close($curl);

            $response= "Email sent successfully,please Check Your Email ";
            $response_status = "success";
        }

    }
    else if($type=='vetzone')
    {
        $find= find("first","vetzone","*"," where email='$email'",array());

        // print_r($find);
        // exit;

        if($find)
        {
            $name=$find["name"];
            $id=$find["vetzone_id"];

            $url = "https://vscm.vetrinahealthcare.com/PHPMailer/send_mail.php";
            $data = array(
                    "mailto" => $email,
                    "subject" => "Reset Password at VetrinaHealthcare" ,
                    "fullname" => $name,
                    "fromname" => "Vetrina Healthcare",
                    "message" => "Dear ".$name.",<br>
                                Please Click on following link to reset your password.<br>
                                <a href='https://vscm.vetrinahealthcare.com/reset_password.php?id=$id&&type=$type'>Click here to reset your password</a>
                                For more information please contact  <a href='tel:8600844450'>8600844450.</a>"
            );

            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $res = curl_exec($curl);
            curl_close($curl);
        
             $response= "Email sent successfully ,please Check Your Email ";
            $response_status = "success";

        }
    }
        else
        {
            $response= " This Email not found";
            $response_status = "error";
        }
}
?>
<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Recover Account</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <style>
        body
        {
            background-image : url("images/login_bg.jpg");
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
									<div class="text-center mb-3 bg-white p-2" style="border-radius: 20px;">
										<a href="index.html"><img src="images/logo-text.png" style="width:50%" alt=""></a>
									</div>
                                    <h4 class="text-center mb-4 text-white">Recover My Account</h4>
                                    <form action="" method="POST">
                                    <?php if(isset($response_status)){ 
                                            
                                        if($response_status!="none") { 
                                            if($response_status=="error") {
                                            ?>
                                            <div class="form-group bg-danger text-white p-1">  
                                                <?= $response?>
                                            </div>
                                        <?php 
                                            }
                                            if($response_status=="success") {
                                                ?>
                                                <div class="form-group bg-success text-white p-1">  
                                                <?= $response?>
                                                </div>
                                            <?php 
                                                }
                                    
                                        } } ?>
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Email</strong></label>
                                            <input type="email" name="email" class="form-control"  placeholder="example@gmail.com" value="">
                                        </div>
                                       
                                        <div class="text-center">
                                            <input  type="submit" name="sendmail" class="btn bg-white text-primary btn-block" value="Send Email" />
                                        </div>
                                    </form>
                                    <?php if($type=="admin"){ ?>

                                        <div class="form-row d-flex justify-content-between mt-4">
                                            <div class="form-group">
                                                <a href="index.php" class="text-white">Switch to Admin Login</a>
                                            </div>
                                        </div>

                                        <?php } else if($type=="user") {?>

                                             <div class="form-row d-flex justify-content-between mt-4">
                                            <div class="form-group">
                                                <a href="user_login.php" class="text-white">Switch to User Login</a>
                                            </div>
                                        </div>

                                        <?php } else if($type=="customer") { ?>

                                             <div class="form-row d-flex justify-content-between mt-4">
                                            <div class="form-group">
                                                <a href="customer_login.php" class="text-white">Switch to Customer Login</a>
                                            </div>
                                        </div>

                                        <?php } else { ?>

                                             <div class="form-row d-flex justify-content-between mt-4">
                                            <div class="form-group">
                                                <a href="vetzone_login.php" class="text-white">Switch to VetZone Login</a>
                                            </div>
                                        </div>
                                                
                                        <?php }?>
                                       
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="./js/custom.min.js"></script>
    <script src="./js/deznav-init.js"></script>

</body>

</html>
<?php 
    include("init.php");

    $user_id = $_SESSION["user_id"];
    $type = $_SESSION["type"];

    if($type=="vetzone")
    {
        $table = "vetzone_instock as i inner join product as p on i.product_id=p.product_id";
    }
    else
    {
        $table = "customer_instock as i inner join product as p on i.product_id=p.product_id";
    }
    $inventory = find("all",$table,"i.*, p.product_name, p.product_code, sum(quantity) as qnty","where created_by='$user_id' group by i.product_id",array());
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Product Name</th>
                                                <th>SKU</th>>
                                                <th>Product Code</th>
                                                <th>Available Quantity</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; foreach($inventory as $key=>$val) { $i++; 
                                               
                                                $product_id = $val["product_id"];
                                                $table2 = "customer_order_table_product as cotp inner join customer_placeorder as cp on cp.customer_order_id=cotp.order_id";
                                                $getactualstock = find("first",$table2,"* , sum(quantity) as qnt","where cp.status='Y' and cp.is_placed_order='Y' and cotp.product_id='$product_id' and cotp.seller_user_id= '$user_id' and cotp.seller_user_role ='VetZone' ",array());
                                                
                                                //echo "where product_id=".$val['product_id']." and batch='".$val['batch']."' and seller_user_id=".$user_id;

                                                $soldquantity = $getactualstock["qnt"];
                                                $availablestock = $val["qnty"]-$getactualstock["qnt"];
                                                //echo $soldquantity;
                                                $name = $val["product_name"];
                                                $sku = $val["sku"];
                                                // $data = $product_id.",'".$name."','".$sku."'";

                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><span class="clickable" onclick="getBatch(<?=$product_id?>,'<?=$name?>','<?=$sku?>');"><?=$val["product_name"]?><span></td>
                                                <td><?=$val["sku"]?></td>
                                                <td><?=$val["product_code"]?></td>
                                                <td><?=$availablestock?></td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>      
                            </div>
                        </div>            
                    </div>            
                </div>   
                
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                            <B><div id = "stockItem"></div></B> 
                            <br>
                                <div class="table-responsive">
                                    <table id="batchTable" class="display min-w850">
                                        <thead>                                        
                                            <tr>
                                                <th>Batch</th>
                                                <th>Quantity</th>
                                                <th>PTV</th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>                                   
                                            </tr>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-------batchwise table end----->

            </div>            
        </div>            
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
    </body>
</html>


<script>

$(document).ready(function () {

$("#batchTable").hide();

});

function getBatch(pid, pname, sku)
{
    // alert("product id is : "+pid+pname+sku);

    $("#batchTable").show();
    $("#stockItem").html("Product : "+ pname + "<br/>sku : " + sku);

    batchTable = $("#batchTable").DataTable({
        responsive: true,
        dom: 'lBfrtip',

        "ajax":
			  {
			  	'url' : 'ajax/get_batchwise_inventory.php',
				'type': 'POST',
				'data': {
						 action : 'getbatch',
                         pid : pid,
						},
				
			  },        

        destroy : true,
        
    });   
    
    /* $.ajax({ 
        url: "ajax/get_batchwise_inventory.php",
        type: "POST",
        data: { 
            action : 'getbatch',
            pid : pid,
        },
        success: function(data) {
            alert(data);
            }
    }); */

}

</script>
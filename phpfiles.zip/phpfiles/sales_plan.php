<?php
include("init.php");

$_SESSION["sales_plan"] = 1;
$user_id = $_SESSION["user_id"];
$role = $_SESSION["roll"];

if(isset($_POST["create_sales_plan"])) 
{
    $customer_type = $_POST["type"];
    $customer_id = $_POST["party_name"];
    $last_month_sale = $_POST["last_month_sale"];
    $sales_plan = $_POST["sales_plan"];

    $plan_amount = 0;

    foreach ($sales_plan as $k=>$v) 
    {
        $plan_amount = $plan_amount + $sales_plan[$k];
    }

    $fields = "plan_amount,created_by,created_by_role";
    $values = ":plan_amount,:created_by,:created_by_role";
    $exe = array(":plan_amount"=>$plan_amount,":created_by"=>$user_id,":created_by_role"=>$role);
    $save_plan = save("sales_plan", $fields, $values, $exe);

    if ($save_plan) 
    {
        $sales_plan_id = $save_plan;

        foreach ($customer_id as $k=>$v) 
        {
            $cust_id = $customer_id[$k];
            $last_sale = $last_month_sale[$k];
            $customer_role = $customer_type[$k];
            $plan_value = $sales_plan[$k];

            $fld = "sales_plan_id,customer_id,customer_role,plan_value";
            $val = ":sales_plan_id,:customer_id,:customer_role,:plan_value";
            $exe = array(":sales_plan_id" => $sales_plan_id, ":customer_id" => $cust_id, ":customer_role" => $customer_role,":plan_value"=>$plan_value);
            $save_plan_meta = save("sales_plan_meta", $fld, $val, $exe);
        }
    }

}

$tab = "sales_plan as sp inner join admin as a on sp.created_by=a.admin_id inner join designations as d on sp.created_by_role=d.desig_id";

if($role=="6")
{
    $sales_plans = find("all", $tab, "*", "where sp.created_by='$user_id'", array());
}
else if($role=="5") 
{
    $a = array();
    $getvso = find("all","admin","admin_id","where line_manager='$user_id'",array());
    foreach($getvso as $k=>$v)
    {
        array_push($a,$v["admin_id"]);
    }
    $vso = implode(",", $a);

    $sales_plans = find("all", $tab, "*", "where sp.created_by IN ($vso)", array());
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    <style>
        .form-control {
            width: auto;
        }
    </style>
</head>

<body>
    <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <b class="card-title">Create Sales Plan</b>
                            </div>
                            <form action="" method="POST">
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered"">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Customer Type</th>
                                                <th>Name Of Party</th>
                                                <th>Last Month Sale</th>
                                                <th>Sales Plan</th>
                                                <th>Add</th>
                                            </tr>
                                        </thead>
                                        <tbody id="salesplan">
                                            <tr>
                                                <td>1</td>
                                                <td>
                                                    <select name="type[]" class="form-control"
                                                        onchange="getcustomersbytype(this.value,'1')" id="type1">
                                                        <option value="">Select Type</option>
                                                        <option value="Customer">Customer</option>
                                                        <option value="VetZone">VetZone</option>
                                                    </select>
                                                </td>
                                                <td id="party1">

                                                </td>
                                                <td><input type="text" name="last_month_sale[]" class="form-control"
                                                        id="last_month_sale1"></td>
                                                <td><input type="number" name="sales_plan[]" class="form-control"
                                                        id="sales_plan1"></td>
                                                
                                                <td><span class="btn btn-xs sharp btn-info shadow" onclick="additeminlist()">+</span></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <br><br>
                                    <div class="row">
                                        <button type="submit" name="create_sales_plan"
                                            class="btn btn-sm btn-info">Create Sales Plan</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <p class="card-title">Sales Plan</p>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display">
                                        <thead>
                                            <tr>
                                                <th>Sr No</th>
                                                <th>Plan Amount</th>
                                                <th>Created By</th>
                                                <th>Created On</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i = 0;
                                            foreach ($sales_plans as $key => $val) {
                                                $i++;
                                                $created_date =$val['created_on'];
                                                $created_date = str_replace('-"', '/', $created_date);
                                                                                             
                                               $newDate = date("y/m", strtotime($created_date));
                                                ?>
                                                <tr>
                                                    <td>
                                                        <?=$i ?>
                                                    </td>
                                                    <td>
                                                        <?=$val["plan_amount"] ?>
                                                    </td>
                                                    <td>
                                                        <?=$val["username"] ?>-<?= $val["desig_name"] ?>
                                                    </td>
                                                    <td>
                                                        <?= $newDate?>
                                                    </td>
                                                    <td>
                                                    <a href="sales_plan_view.php?plan_id=<?php echo $val['sale_plan_id']?>"> <span class="btn btn-info shadow btn-xs sharp"><i class="fa fa-eye"></i></span></a>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
    <?php include("jslink.php"); ?>
    <script>

        function additeminlist()
        {
            $.ajax({
                method: "POST", 
                url: "ajax/addsalesrow.php",
                data: {}
            }).done(function (msg) {
                $("#salesplan").append(msg);
            });
        } 
        
        function removeiteminlist(row)
        {
            $("#newrow"+row).remove();
        }
        
        function getcustomersbytype(type, num)
        {
            $.ajax({
                url: "ajax/getcustomerbytype.php",
                method: "POST",
                data: { type: type }
            }).done(function (response) {
                 $("#party" + num).html(response); 
            });
        } 

        function getlastmonthsale(cust_id, num) 
        { } 
    </script>
</body>

</html>
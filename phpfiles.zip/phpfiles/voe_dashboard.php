<?php 
if(date("m") > 3)
{
    $fyear = date("Y").'/04/01  - '.(date("Y")+1).'/03/31';
    $from_dt = date("Y").'-04-01';
    $to_dt = (date("Y")+1).'-03-31';
}
else
{
    $from_dt = (date("Y")-1).'-04-01';
    $to_dt = date("Y").'-03-31';
}

$user_id = $_SESSION['user_id'];
/* SELECT p.user_id, DATE_FORMAT(p.created_date,'%Y-%m-%d') created_date, p.status,
otp.order_id, otp.product_id, otp.rate, otp.quantity, otp.user_id,
sum(otp.rate * otp.quantity) amount,
v.name, vhd.hq_id, hq.hq_name
FROM order_table_product otp, placeorder p, vetzone v, vetzone_hq_div vhd, headquarters hq
where p.status = 'P'
and p.user_role = 'VetZone'
and p.created_date between '2023-04-01' and '2024-03-31'
and p.user_id = otp.user_id
and v.vetzone_id = otp.user_id
and v.vetzone_id = vhd.vetzone_id
and hq.hq_id = vhd.hq_id
group by p.stockiest_order_id; */

$table = "order_table_product otp, placeorder p, vetzone v, vetzone_hq_div vhd, headquarters hq";
$values = "p.user_id, DATE_FORMAT(p.created_date,'%Y-%m-%d') created_date, p.status, otp.order_id, otp.product_id, otp.rate, otp.quantity, otp.user_id, sum(otp.rate * otp.quantity) amount, v.name, vhd.hq_id, hq.hq_name";
$where = "where p.status = 'P' and p.user_role = 'VetZone' and p.created_date between '$from_dt' and '$to_dt' and p.user_id = otp.user_id and v.vetzone_id = otp.user_id and v.vetzone_id = vhd.vetzone_id and hq.hq_id = vhd.hq_id
group by p.stockiest_order_id";
$getDataResult = find("all", $table, $values, $where, array());
// print_r($getDataResult);


// New Orders
// $allOrders = find("first", "placeorder", "count(*) count", "where user_role = 'VetZone'", array());

// Pending Orders
$pendingOrders = find("first", "placeorder", "count(*) count", "where user_role = 'VetZone' and status = 'P' and created_date between '$from_dt' and '$to_dt'", array());

// Orders on Hold
$holdOrders = find("first", "placeorder", "count(*) count", "where user_role = 'VetZone' and status = '' and created_date between '$from_dt' and '$to_dt'", array());

// Orders Dispatched
$dispatchedOrders = find("first", "placeorder", "count(*) count", "where user_role = 'VetZone' and status = 'Y' and created_date between '$from_dt' and '$to_dt'", array());

// Orders in Transit
$transitOrders = find("first", "placeorder", "count(*) count", "where user_role = 'VetZone' and status = 'I' and created_date between '$from_dt' and '$to_dt'", array());

// Orders Delivered
$deliveredOrders = find("first", "placeorder", "count(*) count", "where user_role = 'VetZone' and status = 'D' and created_date between '$from_dt' and '$to_dt'", array());

	
?>
<div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				
                <div class="row">
					<div class="col-xl-12 col-xxl-12">
						<div class="row">
							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<!-- <span class="activity-icon bgl-success mr-md-4 mr-3">
												<img src="images/target.png" alt="" width="40" height="40">
											</span> -->
											<div class="media-body">
												<p class="fs-20 mb-2">New Orders</p>
												<span class="title text-black font-w600"><?=$pendingOrders['count'];?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-success"></div>
								</div>
							</div>

                            <div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<!-- <span class="activity-icon bgl-warning  mr-md-4 mr-3">
												<img src="images/salary.png" alt="" width="40" height="40">
											</span> -->
											<div class="media-body">
												<p class="fs-20 mb-2">Pending Orders</p>
												<span class="title text-black font-w600"><?=$pendingOrders['count'];?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-warning" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-warning"></div>
								</div>
							</div>

							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<!-- <span class="activity-icon bgl-success mr-md-4 mr-3">
												<img src="images/target.png" alt="" width="40" height="40">
											</span> -->
											<div class="media-body">
												<p class="fs-20 mb-2">Orders on Hold </p>
												<span class="title text-black font-w600"><?=$holdOrders['count'];?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-secondary" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-secondary"></div>
								</div>
							</div>
							
							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<!-- <span class="activity-icon bgl-secondary  mr-md-4 mr-3">
												<img src="images/badge.png" alt="" width="40" height="40">
											</span> -->
											<div class="media-body">
												<p class="fs-20 mb-2">order dispatched</p>
												<span class="title text-black font-w600"><?=$dispatchedOrders['count'];?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-secondary" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-secondary"></div>
								</div>
							</div>

							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<!-- <span class="activity-icon bgl-danger mr-md-4 mr-3">
												<img src="images/commission.png" alt="" width="40" height="40">
											</span> -->
											<div class="media-body">
												<p class="fs-20 mb-2">Order in transit</p>
												<span class="title text-black font-w600"><?=$transitOrders['count'];?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-danger"></div>
								</div>
							</div>

                            <div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<!-- <span class="activity-icon bgl-danger mr-md-4 mr-3">
												<img src="images/commission.png" alt="" width="40" height="40">
											</span> -->
											<div class="media-body">
												<p class="fs-20 mb-2">Order delivered</p>
												<span class="title text-black font-w600"><?=$deliveredOrders['count'];?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-success"></div>
								</div>
							</div>
							
						</div>
					</div>
				
				</div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">VetZone New Orders</h4>
                            </div>
                            <div class="card-body">
                                 <div class="table-responsive">
                                    <table bordered id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>VetZone Name</th>
                                                <th>Head Quarter</th>
                                                <th>Order Date</th>
                                                <th>Order Amount</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php
										$i = 1;
										foreach($getDataResult as $item)
										{
										?>
                                            <tr>
                                                <td><?=$i ?></td>
												<td><p onclick="Open('<?=$item['vetzone_id']?>')"; style = "color: #1a0dab"><?=$item['name']?></p></td>
                                                <td><?=$item['hq_name'] ?></td>
                                                <td><?=$item['created_date'] ?></td>
                                                <td><?=$item['amount'] ?></td>
                                                
												<?php if($item["status"]=="P") {
                                                        echo "<td class='table-warning'>Pending</td>";
                                                    }
                                                    else if($item["status"]=="N")
                                                    {
                                                        echo "<td class='table-warning'>Pending</td>";
                                                    }
                                                    else if($item["status"]=="Y")
                                                    {
                                                        echo "<td class='table-success'>Dispatched</td>";
                                                    }
                                                    else if($item["status"]=="I")
                                                    {
                                                        echo "<td class='table-info'>In Process</td>";
                                                    }
                                                    else if($item["status"]=="D")
                                                    {
                                                        echo "<td class='table-success'>Delivered</td>";
                                                    }
                                                    ?>
												
                                            </tr>
										<?php 
												$i++;
											} //End of foreach
										?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
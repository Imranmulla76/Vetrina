<?php include("init.php");
        //check_login();
         if(isset($_POST["add_product"]))
    {
        $p_name = $_POST["p_name"];
        $p_category = $_POST["p_category"];
        $p_code = $_POST["p_code"];
        $number = $_POST["number"];
        $sku = $number." ".$_POST["unit"];
        $unit = $_POST["unit1"];
        $manufacturer = $_POST["manufacturer"];
        $gst = $_POST["gst"];
        $igst = $_POST["igst"];
        $cgst = $_POST["cgst"];
        $sgst = $_POST["sgst"];
        $p_group = $_POST["p_group"];
        $p_division = $_POST["division"];
        $barcode = $_POST["barcode"];
        $shipper_size = $_POST["shipper_size"];
        $hsn = $_POST["hsn"];
        $ic_code = $_POST["ic_code"];
        $schedule = $_POST["schedule"];
        $inventory_days = $_POST["inventory_days"];
        // $nrv = $_POST["nrv"];
        // $pts = $_POST["pts"];
        // $ptr = $_POST["ptr"];
        // $ptc = $_POST["ptc"];
        // $ptv = $_POST["ptv"];
        // $ptk = $_POST["ptk"];
        // $mrp = $_POST["mrp"]; 
        $lot1_invoice_qnty = $_POST["lot1_invoice_qnty"]; 
        $lot1_free_qnty = $_POST["lot1_free_qnty"]; 
        $lot2_invoice_qnty = $_POST["lot2_invoice_qnty"]; 
        $lot2_free_qnty = $_POST["lot2_free_qnty"]; 
        $min_inv_qnty = $_POST["min_inv_qnty"]; 

        $fields = "product_name,sku,product_code,unit,product_division,category_id,manufacturer,barcode,shipper_size,hsn_code,ic_code,inventory_days,sheme_lot_one_invoice_qnty,sheme_lot_one_free_qnty,sheme_lot_two_invoice_qnty,sheme_lot_two_free_qnty,min_inventory_qnty";

        $values = ":product_name,:sku,:product_code,:unit,:product_division,:category_id,:manufacturer,:barcode,:shipper_size,:hsn_code,:ic_code,:inventory_days,:sheme_lot_one_invoice_qnty,:sheme_lot_one_free_qnty,:sheme_lot_two_invoice_qnty,:sheme_lot_two_free_qnty,:min_inventory_qnty";
        $exe = array(
            ":product_name"=>$p_name,
            ":sku"=>$sku,
            ":product_code"=>$p_code,
            ":unit"=>$unit,
            ":product_division"=>$p_division,
            ":category_id"=>$p_category,
            ":manufacturer"=>$manufacturer,
            ":barcode"=>$barcode,
            ":shipper_size"=>$shipper_size,
            ":hsn_code"=>$hsn,
            ":ic_code"=>$ic_code,
            ":inventory_days"=>$inventory_days,
            // ":nrv"=>$nrv,
            // ":pts"=>$pts,
            // ":ptr"=>$ptr,
            // ":ptc"=>$ptc,
            // ":ptv"=>$ptv,
            // ":ptk"=>$ptk,
            // ":mrp"=>$mrp,
            ":sheme_lot_one_invoice_qnty"=>$lot1_invoice_qnty,
            ":sheme_lot_one_free_qnty"=>$lot1_free_qnty,
            ":sheme_lot_two_invoice_qnty"=>$lot2_invoice_qnty,
            ":sheme_lot_two_free_qnty"=>$lot2_free_qnty,
            ":min_inventory_qnty"=>$min_inv_qnty
        );

        $saveproduct = save("product",$fields,$values,$exe);

        if($saveproduct)
        {
            $f = "product_id,gst,igst,cgst,sgst";
            $v = ":product_id,:gst,:igst,:cgst,:sgst";
            $exe = array(
                ":product_id"=>$saveproduct,
                ":gst"=>$gst,
                ":igst"=>$igst,
                ":cgst"=>$cgst,
                ":sgst"=>$sgst
            );
            
            $savegst = save("product_gst",$f,$v,$exe);
        }
    }

    $category = find("all","product_category","*","where 1",array());
    $group = find("all","product_group","*","where 1",array());
    $division = find("all","divisions","*","where 1",array());
    $tblproductdetails = "product as p inner join product_category as pc on p.category_id=pc.category_id inner join divisions as d on p.product_division=d.division_id";
    $findproduct = find("all",$tblproductdetails,"*","where 1",array());

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->

        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
                    <div class="col-12">    

                        <a href="create_product.php" class="text-primary"> <- Back To Product </a> <br><br>
                    
                    <form action="" method="POST">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Add Product</h4>
                            </div>
                            <div class="card-body">
                                
                                <div class="row">
                                    <div class="col-3">
                                            <label for="">Product Name</label>
                                            <input type="text" name="p_name" id="" class="form-control">
                                    </div>

                                    <div class="col-3">
                                        <label for="">Manufacturer</label>
                                        <!-- <input type="text" name="manufacturer" value="VetrinaHealthcare" id="" class="form-control"> -->
                                        <select name="manufacturer" id="" class="form-control">
                                                <option value="">Select Manufacturer</option>                                               
                                                    <option value="Vetrina Healthcare">Vetrina Healthcare</option>
                                                    <option value="Third Party">Third Party</option>                                            
                                        </select>
                                    </div>

                                    <div class="col-3">
                                            <label for="">Category</label>
                                            <select name="p_category" id="" class="form-control">
                                                <option value="">Select Category</option>
                                                <?php foreach($category as $k=>$v) { ?>
                                                    <option value="<?=$v["category_id"]?>"><?=$v["category_name"]?></option>
                                                <?php } ?>
                                                <option onclick="addCategory(this.value);" value="other">Other</option>
                                            </select>
                                    </div>

                                    <div class="col-3">
                                            <label for="">Product Code</label>
                                            <input type="text" name="p_code" id="" class="form-control">
                                        </div>
                                </div>
                
                                <br>

                                <div class="row">

                                        <div class="col-3">
                                            <label for="">HSN Code</label>
                                            <input type="text" name="hsn" id="" class="form-control">
                                        </div>

                                        <div class="col-3">
                                            <label for="">IC Code</label>
                                            <input type="text" name="ic_code" id="" class="form-control">
                                        </div>

                                        <div class="col-3">
                                            <label for="">Unit</label>
                                            <select name="unit1" class="form-control" id="">
                                                <option value="ML">ML</option>
                                                <option value="KG">KG</option>
                                                <option value="NOS">NOS</option>
                                                <option value="GM">GM</option>
                                                <option value="LTR">LTR</option>
                                            </select>
                                        </div>

                                        <div class="col-3">
                                        <label for="">SKU</label>
                                        <div class="row">
                                            <div class="col-6">
                                                <input type="text" name="number" id="" class="form-control">
                                            </div>
                                            <!-- <div class="col-6">
                                                    <select name="unit" class="form-control" id="">
                                                    <option value="ml">ml</option>
                                                    <option value="Kg">Kg</option>
                                                    <option value="No">No</option>
                                                    <option value="g">g</option>
                                                    <option value="ltr">ltr</option>
                                                </select>
                                            </div> -->
                                        </div>
                                    </div>
                                </div>
                                
                                <br>    
                                    
                                <div class="row">
                                    
                                    
                                    <div class="col-3">
                                        <label for="">GST</label>
                                        <input type="text" name="gst" id="" class="form-control">
                                    </div>

                                     <div class="col-3">
                                        <label for="">IGST</label>
                                        <input type="text" name="igst" id="" class="form-control">
                                    </div>
                                    
                                    <div class="col-3">
                                        <label for="">CGST</label>
                                        <input type="text" name="cgst" id="location" class="form-control">
                                    </div>

                                    <div class="col-3">
                                        <label for="">SGST</label>
                                        <input type="text" name="sgst" id="location" class="form-control">
                                    </div>
                                </div>
                            
                                <br>
                                    
                                <div class="row">
                                    <div class="col-3">
                                        <label for="">Division</label>
                                            <select name="division" id="" class="form-control">
                                                    <option value="">Select division</option>
                                                    <?php foreach($division as $k=>$v) { ?>
                                                        <option value="<?=$v["division_id"]?>"><?=$v["division_name"]?></option>
                                                    <?php } ?>
                                        </select>
                                    </div>

                                     <div class="col-3">
                                        <label for="">Barcode</label>
                                        <input type="text" name="barcode" id="" class="form-control">
                                    </div>

                                    <div class="col-3">
                                        <label for="">Shipper Size</label>
                                        <input type="text" name="shipper_size" id="" class="form-control">
                                    </div>

                                </div>


                                <!-- <div class="row">
                                    <div class="col-3">
                                        <label for="">NRV</label>
                                        <input type="number" name="nrv" class="form-control" id="">
                                    </div>
                                    <div class="col-3">
                                        <label for="">PTS</label>
                                        <input type="number" name="pts" class="form-control" id="">
                                    </div>
                                    <div class="col-3">
                                        <label for="">PTR</label>
                                        <input type="number" name="ptr" class="form-control" id="">
                                    </div>
                                    <div class="col-3">
                                        <label for="">PTC</label>
                                        <input type="number" name="ptc" class="form-control" id="">
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-3">
                                        <label for="">PTV</label>
                                        <input type="number" name="ptv" class="form-control" id="">
                                    </div>
                                    <div class="col-3">
                                        <label for="">PTK</label>
                                        <input type="number" name="ptk" class="form-control" id="">
                                    </div>
                                    <div class="col-3">
                                        <label for="">MRP</label>
                                        <input type="number" name="mrp" class="form-control" id="">
                                    </div>
                                    
                                </div> -->
                                   <br>
                                <div class="row">
                                    <div class="col-6">
                                        <label for=""><strong>Scheme LOT-I</strong></label>
                                        <div class="row">
                                            <div class="col-6">
                                                <label for="">Invoice Quantity</label>
                                                <input type="number" name="lot1_invoice_qnty" class="form-control" id="">
                                            </div>
                                            <div class="col-6">
                                                <label for="">Free Quantity</label>
                                                <input type="number" name="lot1_free_qnty" class="form-control" id="">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <label for=""><strong>Scheme LOT-II</strong></label>
                                        <div class="row">
                                            <div class="col-6">
                                                <label for="">Invoice Quantity</label>
                                                <input type="number" name="lot2_invoice_qnty" class="form-control" id="">
                                            </div>
                                            <div class="col-6">
                                                <label for="">Free Quantity</label>
                                                <input type="number" name="lot2_free_qnty" class="form-control" id="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="row">

                                    <div class="col-3">
                                            <label for="">Inventory Days</label>
                                            <input type="number" name="inventory_days" id="" class="form-control">
                                    </div>

                                    <div class="col-3">
                                            <label for="">Minimum Inventory Quantity </label>
                                            <input type="number" name="min_inv_qnty" id="" class="form-control">
                                    </div>
                                </div>
                            </div>

          
                            <div class="card-footer">
                                <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary" name="add_product">Add Product</button>
                            </div>
            
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
</body>
</html>
<?php
include("init.php");

$findvetzone=find("all","vetzone","*","where approval_status='Y'",array());

// SELECT * FROM `customer_order_table_product`
// INNER join product on product.product_id=customer_order_table_product.product_id
// WHERE customer_order_table_product.seller_user_id=1 AND `seller_user_role`='VetZone'
if(isset($_POST["savecomission"]))
{
    $vetzone_id=$_POST["vetzone_id"];
    $product_id = $_POST["product_id"];
    $sku = $_POST["sku"];
    $sold = $_POST["sold"];
    $ptv = $_POST["ptv"];
    $totalamt = $_POST["totalamount"];
    $comissonper=$_POST["comission"];
    $comissionamt=$_POST["comsnamt"];
    $currentdate=date('Y-m-d H:i:s');

    $fields="vetzone_id,product_id,sku,sold_qty,ptv,total_sale_amt,comission_per,comission_amt,created_at";
    $value=":vetzone_id,:product_id,:sku,:sold_qty,:ptv,:total_sale_amt,:comission_per,:comission_amt,:created_at";
    $table="comission";

    foreach($product_id as $k=>$v)
    {
        $p_id = $product_id[$k];
        $sk = $sku[$k];
        $sol = $sold[$k];
        $ptvv = $ptv[$k];
        $total = $totalamt[$k];
        $comper = $comissonper[$k];
        $comamt = $comissionamt[$k];
        $todaydate=$currentdate[$k];
        $exe=array(":vetzone_id"=>$vetzone_id,":product_id"=>$p_id,":sku"=>$sk,":sold_qty"=>$sol,":ptv"=>$ptvv,":total_sale_amt"=>$total,":comission_per"=>$comper,":comission_amt"=>$comamt,":created_at"=>$currentdate);
        
        $savecomission=save($table,$fields,$value,$exe);
    
    }
   


}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <b class="card-title">VatZone Comission</b>
                            </div>
                           
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-2 d-flex align-items-center">
                                        <span>Select VetZone : </span>
                                    </div>
                                    <div class="col-sm-10">
                                        <select class="form-control" name="vetzone" id="vetzone">
                                            <option value="">Select VetZone</option>
                                            <?php foreach($findvetzone as $k=>$v){ ?>
                                                <option value="<?=$v['vetzone_id']?>"><?=$v['name']?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-5">
                                        <label for="">Month</label>
                                        <select id='Month' class="form-control" name="Month" >
                                                <option value=''>--Select Month--</option>
                                                <option value='1'>Janaury</option>
                                                <option value='2'>February</option>
                                                <option value='3'>March</option>
                                                <option value='4'>April</option>
                                                <option value='5'>May</option>
                                                <option value='6'>June</option>
                                                <option value='7'>July</option>
                                                <option value='8'>August</option>
                                                <option value='9'>September</option>
                                                <option value='10'>October</option>
                                                <option value='11'>November</option>
                                                <option value='12'>December</option>
                                        </select> 
                                    </div>
                                <div class="row mt-2">
                                    <button class="btn btn-md btn-info" onclick="comission();" >Click to Generate Report</button>
                                </div>
                                
                                <form action="" method="POST">
                                <div class="table-responsive">
                                     <table id="example3" class="display min-w850">
                                        
                                     </table>
                                  
        
                             </div>
                             <div class="row">
                                        <div class="col-2 mt-1">
                                            <button class="btn btn-success shadow" type="submit" name="savecomission">Save Comission</button>
                                        </div>
                                    </div>
                            </div>
                            </form>
                                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
        
    </div>
    <?php include("jslink.php"); ?>
<script>
       
       //today = new Date().toISOString().split('T')[0];

       function comission()
       {
        
           var vetzone=$('#vetzone').val();
           var fromdate=$('#Month').val();
        //   var todate=$('#to_date').val();
           console.log("from date:"+ fromdate);
          // console.log("to date:" + todate);
        //    console.log("vetzone :" +vetzone);
        //    if(fromdate > today || todate > today)
        //      {
        //         alert("Invalid Date is Selected");
        //        swal("Wrong!","Invalid Date is Selected","error"); 
        //     }
            $.ajax({
                    url:"/vscm/ajax/vetZone_comission.php",
                    type:"POST",
                    data:{
                       
                       action:'displayreport',
                       vetzone:vetzone,
                       fromdate:fromdate,
                    //    todate:todate,
                     
                   },
                }).done(function(response){
                    $("#example3").html(response);
                });
        }          

   function cal(rownum)
    {   
        var totalamt=$("#totalamount"+rownum).val();
        var txtVal = $("#comission"+rownum).val();
        var comissionamt=totalamt*(txtVal/100);
        // alert(comissionamt);
        $("#comsnamt"+rownum).val(comissionamt);
    
    }

   </script>

<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"> </script> -->

</body>
</html>
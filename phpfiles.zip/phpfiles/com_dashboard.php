<?php 

$user_id = $_SESSION['user_id'];
if(date("m") > 3)
{
    $fyear = date("Y").'/04/01  - '.(date("Y")+1).'/03/31';
    $from_dt = date("Y").'-04-01';
    $to_dt = (date("Y")+1).'-03-31';
}
else
{
    $from_dt = (date("Y")-1).'-04-01';
    $to_dt = date("Y").'-03-31';
}

/* select c.customer_id, c.name, c.mobile_number, c.role, chd.hq_id, hq.hq_name, cr.role_name,
(otp.rate * otp.quantity) amount, otp.created_at, p.status
from customer c, customer_hq_div chd, headquarters hq, customer_roles cr, order_table_product otp, placeorder p
where c.customer_id = chd.customer_id
and chd.hq_id = (select hq_id from admin_hq_div where admin_id = 13 )
and chd.hq_id = hq.hq_id
and c.role = cr.cust_role_id
and otp.user_role <> 'VetZone'
and otp.user_id = p.user_id
and otp.order_id = p.stockiest_order_id
and otp.user_id = c.customer_id
and p.user_id = c.customer_id; */

/* select p.stockiest_order_id, p.user_id, p.user_role, DATE_FORMAT(p.created_date,'%Y/%m') created_date, p.status, 
c.customer_id, c.name, c.mobile_number,
chd.hq_id, hq.hq_id, hq.hq_name,
otp.order_product_id, sum(otp.rate * otp.quantity) amount
from placeorder p, customer c, customer_hq_div chd, headquarters hq, order_table_product otp
where p.status = 'P'
and p.user_role in ('C&F', 'Stockiest', 'VetZone')
and p.user_id = c.customer_id
and chd.customer_id = c.customer_id
and chd.hq_id = hq.hq_id
and p.stockiest_order_id = otp.order_id
group by otp.order_id; */

$table = "placeorder p, customer c, customer_hq_div chd, headquarters hq, order_table_product otp";
$values = "p.stockiest_order_id, p.user_id, p.user_role, DATE_FORMAT(p.created_date,'%Y/%m') created_date, p.status, c.customer_id, c.name, c.mobile_number, chd.hq_id, hq.hq_id, hq.hq_name, otp.order_product_id, sum(otp.rate * otp.quantity) amount";
$where = "where p.status = 'P' and p.user_role in ('C&F', 'Stockiest', 'VetZone') and p.user_id = c.customer_id
and chd.customer_id = c.customer_id and chd.hq_id = hq.hq_id and p.stockiest_order_id = otp.order_id and created_date between '$from_dt' and '$to_dt' group by otp.order_id";
$getDataResult = find("all", $table, $values, $where, array());
// print_r($getDataResult);


// Pending Orders
$pendingOrders = find("first", "placeorder", "count(*) count", "where status = 'P' and created_date between '$from_dt' and '$to_dt'", array());

// Orders on Hold
$holdOrders = find("first", "placeorder", "count(*) count", "where status = '' and created_date between '$from_dt' and '$to_dt'", array());

// Orders Dispatched
$dispatchedOrders = find("first", "placeorder", "count(*) count", "where status = 'Y' and created_date between '$from_dt' and '$to_dt'", array());

// Orders in Transit
$transitOrders = find("first", "placeorder", "count(*) count", "where status = 'I' and created_date between '$from_dt' and '$to_dt'", array());

// Orders Delivered
$deliveredOrders = find("first", "placeorder", "count(*) count", "where status = 'D' and created_date between '$from_dt' and '$to_dt'", array());
?>

<div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				
                <div class="row">
					<div class="col-xl-12 col-xxl-12">
						<div class="row">
							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<!-- <span class="activity-icon bgl-success mr-md-4 mr-3">
												<img src="images/target.png" alt="" width="40" height="40">
											</span> -->
											<div class="media-body">
												<p class="fs-20 mb-2">New Orders</p>
												<span class="title text-black font-w600"><?=$pendingOrders['count'];?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-success"></div>
								</div>
							</div>

                            <div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<!-- <span class="activity-icon bgl-warning  mr-md-4 mr-3">
												<img src="images/salary.png" alt="" width="40" height="40">
											</span> -->
											<div class="media-body">
												<p class="fs-20 mb-2">Pending Orders</p>
												<span class="title text-black font-w600"><?=$pendingOrders['count'];?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-warning" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-warning"></div>
								</div>
							</div>

							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<!-- <span class="activity-icon bgl-success mr-md-4 mr-3">
												<img src="images/target.png" alt="" width="40" height="40">
											</span> -->
											<div class="media-body">
												<p class="fs-20 mb-2">Orders on Hold </p>
												<span class="title text-black font-w600"><?=$holdOrders['count'];?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-secondary" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-secondary"></div>
								</div>
							</div>
							
							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<!-- <span class="activity-icon bgl-secondary  mr-md-4 mr-3">
												<img src="images/badge.png" alt="" width="40" height="40">
											</span> -->
											<div class="media-body">
												<p class="fs-20 mb-2">order dispatched</p>
												<span class="title text-black font-w600"><?=$dispatchedOrders['count'];?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-secondary" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-secondary"></div>
								</div>
							</div>

							<div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<!-- <span class="activity-icon bgl-danger mr-md-4 mr-3">
												<img src="images/commission.png" alt="" width="40" height="40">
											</span> -->
											<div class="media-body">
												<p class="fs-20 mb-2">Order in transit</p>
												<span class="title text-black font-w600"><?=$transitOrders['count'];?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-danger"></div>
								</div>
							</div>

                            <div class="col-sm-4">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<!-- <span class="activity-icon bgl-danger mr-md-4 mr-3">
												<img src="images/commission.png" alt="" width="40" height="40">
											</span> -->
											<div class="media-body">
												<p class="fs-20 mb-2">Order delivered</p>
												<span class="title text-black font-w600"><?=$deliveredOrders['count'];?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-success"></div>
								</div>
							</div>
							
						</div>
					</div>
				
				</div>

				
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Party Orders</h4>
                            </div>
                            <div class="card-body">
                                 <div class="table-responsive">
                                    <table bordered id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Party Name</th>
                                                <th>Party Type</th>
                                                <th>Head Quarter</th>
                                                <th>Party Contact Number</th>
                                                <th>Order Date</th>
                                                <th>Order Amount</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php
										$i = 1;
										foreach($getDataResult as $item)
										{
										?>
                                            <tr>
                                                <td><?=$i ?></td>
												<td><p onclick="Open('<?=$item['customer_id']?>')"; class="clickable"><?=$item['name']?></p></td>
                                                <td><?=$item['role_name'] ?></td>
                                                <td><?=$item['hq_name'] ?></td>
                                                <td><?=$item['mobile_number'] ?></td>
                                                <td><?=$item['created_date'] ?></td>
                                                <td><?=$item['amount'] ?></td>
                                                
												<?php if($item["status"]=="P") {
                                                        echo "<td class='table-warning'>Pending</td>";
                                                    }
                                                    else if($item["status"]=="N")
                                                    {
                                                        echo "<td class='table-warning'>Pending</td>";
                                                    }
                                                    else if($item["status"]=="Y")
                                                    {
                                                        echo "<td class='table-success'>Dispatched</td>";
                                                    }
                                                    else if($item["status"]=="I")
                                                    {
                                                        echo "<td class='table-info'>In Process</td>";
                                                    }
                                                    else if($item["status"]=="D")
                                                    {
                                                        echo "<td class='table-success'>Delivered</td>";
                                                    }
                                                    ?>
												
                                            </tr>
										<?php 
												$i++;
											} //End of foreach
										?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-success">
                                <h4 class="card-title">Order Details</h4>
                            </div>
                            <div class="card-body">
                                 <div class="table-responsive" >
                                    <table bordered id="orderDetails" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Name of Product</th>
                                                <th>sku</th>
                                                <th>Quantity</th>
                                                <th>MRP</th>
												<th>Rate</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
												<td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<script>

$(function() {
	console.log( "ready!" );
	$("#example3").DataTable({
		dom: 'lfrtip',		
	});
});

function Open(cust_id) {
$.ajax ({
	url: "ajax/get_com_dashboard.php",
	method: "POST",
	data: {
		action : 'orderDetails',
		cust_id : cust_id,
		}
}).done(function(response){
	console.log(response);
	$("#orderDetails").html(response);
});
$("#orderDetails").DataTable({
   dom: 'lfrtip',
   bDestroy: true,
});

}
</script>
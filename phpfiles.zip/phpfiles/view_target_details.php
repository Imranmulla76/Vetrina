<?php include("init.php");
    
    $target_id=$_GET["target_id"];

    $table = "target_meta as tm inner join target_table as tt on tt.target_id=tm.target_id inner join admin as a on tt.user_id=a.admin_id inner join admin_roles as ar on a.admin_id=ar.admin_id inner join designations as d on ar.desig_id=d.desig_id";

    $findtargetdetails = find("first",$table,"*","where tt.target_id='$target_id'",array());

    $yealrytarget = 0;
    $quarter_1_amount = 0;
    $quarter_2_amount = 0;
    $quarter_3_amount = 0;
    $quarter_4_amount = 0;

    // $findtargetmeta = find("all","target_meta","where target_id='$target_id'",array());
    // foreach($findtargetmeta as $key=>$val)
    // {
       //$product_id = $val["product_id"];

        $quarter_1_quantity = find("first","target_meta","sum(value) as qnty","where  month in (04,05,06) and target_id='$target_id'",array());

        // echo $quarter_1_quantity["qnty"];
        // exit;
        //$quarter1 = $pts * $quarter_1_quantity["qnty"];
        $quarter_1_amount = $quarter_1_quantity["qnty"];
       // echo $quarter_1_amount."###<br>";

        $quarter_2_quantity = find("first","target_meta","sum(value) as qnty","where   month in (07,08,09) and target_id='$target_id' ",array());

        //$quarter2 = $pts * $quarter_2_quantity["qnty"];
        $quarter_2_amount = $quarter_2_quantity["qnty"];;

        $quarter_3_quantity = find("first","target_meta","sum(value) as qnty","where  month in (10,11,12) and target_id='$target_id' ",array());

        //$quarter3 = $pts * $quarter_3_quantity["qnty"];
        $quarter_3_amount = $quarter_3_quantity["qnty"];;


        // $quarter_4_quantity = find("first",$table,"sum(value) as qnty","where  month in (01,02,03) and tm.target_id='$target_id'  and tm.product_id='$product_id'",array());
        $quarter_4_quantity = find("first","target_meta","sum(value) as qnty","where  month in (01,02,03) and target_id='$target_id'",array());

        //$quarter4 = $pts * $quarter_4_quantity["qnty"];
        $quarter_4_amount = $quarter_4_quantity["qnty"];


    //}
    $yealrytarget = $quarter_1_amount+$quarter_2_amount+$quarter_3_amount+$quarter_4_amount;

    $finddesignations = find("all","designations","*","where 1",array());
    $finddivision = find("all","divisions","*","where 1",array());
    $findheadquarter = find("all","headquarters","*","where 1",array());
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                        <div class="col-3">
                            <a href="create_target.php" class="btn btn-sm btn-primary">Back to Targets</a>
                        </div>
                    </div>
                <div class="row">
                    <div class="col-12">

                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Target Details</h4>
                            </div>
                        
                            <div class="card-body">

                            <form action="" method="POST" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-6">
                                        <label for="">Select User</label>
                                        <select name="designation" id="designation" class="form-control">
                                            <option  value="">Select Designation</option>
                                            <option <?php if($findtargetdetails["desig_id"]=="2"){ echo "selected";} ?> value="2">GM (General Manager)</option>
                                            <option <?php if($findtargetdetails["desig_id"]=="3"){ echo "selected";} ?> value="3">NSM (National Sales Manager)</option>
                                            <option <?php if($findtargetdetails["desig_id"]=="4"){ echo "selected";} ?> value="4">ZSM (Zonal Sales Manager)</option>
                                            <option <?php if($findtargetdetails["desig_id"]=="5"){ echo "selected";} ?> value="5">ASM (Area Sales Manager)</option>
                                            <option <?php if($findtargetdetails["desig_id"]=="6"){ echo "selected";} ?> value="6">VSO (Veterinary Sales Officer)</option>
                                        </select>
                                    </div>
                                    <div class="col-6">
                                        <label for="">Select Headquarters</label>
                                        <select name="headquarter" class="form-control" id="hq">
                                            <option value="">Select Headquarter</option>
                                            <?php foreach($findheadquarter as $k=>$v){?>
                                                <option <?php if($findtargetdetails["hq_id"]==$v["hq_id"]){ echo "selected";} ?> value="<?=$v["hq_id"]?>"><?=$v["hq_name"]?> - (<?=$v["base_town"]?>)</option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-6">
                                        <div id="user">
                                            <input type="text" class="form-control" value="<?=$findtargetdetails["username"]?>" name="" id="">
                                        </div>
                                    </div>
                                </div>

                                <br>

                                <div class="row">
                                    <div class="col-3">
                                        <a href="view_target_excel.php?target_id=<?=$target_id?>" target="_blank" class="btn btn-sm btn-success shadow">view Target excel</a>
                                    </div>
                                </div>
                            </form>
                                <br>
                        
                                <div class="row">
                                    <div class="col-6">
                                        <label for="">Year</label>
                                        <input type="text" name="year" readonly value="2023-2024" class="form-control" id="" >
                                    </div>
                                    <div class="col-6">
                                        <label for="">Yearly Target Amount</label>
                                        <div class="row">
                                                <div class="col-sm-6">
                                                    <input type="number" name="amount" readonly id="amount" value="<?=$yealrytarget?>" class="form-control">
                                                </div>
                                                <!-- <div class="col-sm-6">
                                                    <select name="unit" id="" class="form-control">
                                                        <option value="">Select Unit</option>
                                                        <option value="">Thousand</option>
                                                        <option value="">lac</option>
                                                        <option value="">Cr</option>
                                                    </select>
                                                </div> -->
                                        </div>
                                    </div>
                                </div>

                                <br>
                                <div class="row">
                                    <div class="col-6">
                                        <label for="">Quarter 1 Amount</label>    
                                        <input type="number" readonly value="<?=$quarter_1_amount?>" class="form-control" name="amount1" id="amount1">

                                    </div>
                                </div>

                                <br>
                                <div class="row">
                                    <div class="col-6">
                                        <label for="">Quarter 2 Amount</label>    
                                        <input type="number" readonly value="<?=$quarter_2_amount?>" class="form-control" name="amount2" id="amount2">
                                        
                                    </div>
                                </div>

                                <br>
                                <div class="row">
                                    <div class="col-6">
                                        <label for="">Quarter 3 Amount</label>    
                                        <input type="number" value="<?=$quarter_3_amount?>" readonly class="form-control" name="amount3" id="amount3">
                                        
                                    </div>
                                </div>

                                <br>
                                <div class="row">
                                    <div class="col-6">
                                        <label for="">Quarter 4 Amount</label>    
                                        <input type="number" value="<?=$quarter_4_amount?>" readonly class="form-control" name="amount4" id="amount4">
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <span class="btn btn-info" onclick="calculateMonthly()">Show Monthly</span>
                                </div>
                                <div class="row">
                                    <div class="monthly">

                                    </div>                
                                </div>
                                <br>
                               
                            </div>
                        </div>

                    </div>        
                </div>      
            </div>  
        </div>  
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
            <script>
                function getusers(hq_id) {
                    var desig_id = $("#designation").val();

                    $.ajax({
                        url: "ajax/getUsers.php",
                        method: "POST",
                        data: {
                            desig_id:desig_id , hq_id:hq_id
                        },
                        success: function( result ) {
                            $("#user").html(result);
                        }
                        });
                }

                function getusersbydesig(desig_id) {
                    var hq_id = $("#hq").val();

                    $.ajax({
                        url: "ajax/getUsers.php",
                        method: "POST",
                        data: {
                            desig_id:desig_id , hq_id:hq_id
                        },
                        success: function( result ) {
                            $("#user").html(result);
                        }
                        });
                }

                function calpercent(percent,Quarter)
                {
                    var yearlyAmount = $("#amount").val();
                    
                    if(Quarter == "1")
                    {
                        var amount1 =  Math.round(yearlyAmount *  (percent / 100) );
                        $("#amount1").val(amount1);
                    }

                    if(Quarter == "2")
                    {
                        var amount2 =  Math.round(yearlyAmount * (percent / 100));
                        $("#amount2").val(amount2);
                    }

                    if(Quarter == "3")
                    {
                        var amount3 =  Math.round(yearlyAmount * (percent / 100));
                        $("#amount3").val(amount3);
                    }

                    if(Quarter == "4")
                    {
                        var amount4 =  Math.round(yearlyAmount * (percent / 100));
                        $("#amount4").val(amount4);
                    }
                    
                }

                function calculateMonthly()
                {
                   var quarter1 = $("#amount1").val();
                   var quarter2 = $("#amount2").val();
                   var quarter3 = $("#amount3").val();
                   var quarter4 = $("#amount4").val();

                   var janTomar = Math.round(quarter1/3);
                   var aprlTojune = Math.round(quarter2/3);
                   var julyTosep = Math.round(quarter3/3);
                   var octTodec = Math.round(quarter4/3);

                   $(".monthly").append('<span class="badge light badge-danger">January - '+janTomar+'</span> &nbsp;&nbsp;&nbsp;&nbsp;  <span class="badge light badge-danger">February - '+janTomar+'</span> &nbsp;&nbsp;&nbsp;&nbsp;  <span class="badge light badge-danger">March - '+janTomar+'</span><br>');
                   $(".monthly").append('<br><span class="badge light badge-danger">April - '+aprlTojune+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">May - '+aprlTojune+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">June - '+aprlTojune+'</span><br>');
                   $(".monthly").append('<br><span class="badge light badge-danger">July - '+julyTosep+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">August - '+julyTosep+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">September - '+julyTosep+'</span><br>');
                   $(".monthly").append('<br><span class="badge light badge-danger">October - '+octTodec+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">November - '+octTodec+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">December - '+octTodec+'</span><br>');
                }
            </script>
</body>
</html>
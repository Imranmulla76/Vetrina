<?php include("init.php");
      
      $amount = $_REQUEST["amount"];
      $user_id = $_SESSION["user_id"];
      $type = $_SESSION["type"];

    // $credits = array(); 
    // $totaldue = find("all","vetzone_credit_note_table","*","where user_id='$user_id' and payment_status='N'",array());
    // foreach($totaldue as $key=>$val)
    // {
    //     array_push($credits,$val["credit_note_id"]);
    // }
    // $ids = implode(",", $credits);

       if(isset($_POST["save_paymentdetails"]))
        {
        
            $payment_mode = $_POST["payment_mode"];
            $transaction_id = $_POST["transaction_id"];
            $amount = $_POST["payment_amount"];
            $filename = $_FILES['file']["name"];
            $filetempname = $_FILES['file']['tmp_name'];

        if($type=="vetzone")
        {
            $fields = "vetzone_id,amount,transcation_id,reciept,payment_mode";
            $values = ":vetzone_id,:amount,:transcation_id,:reciept,:payment_mode";
            $exe = array(
                ":vetzone_id"=>$user_id,
                ":amount"=>$amount,
                ":transcation_id"=>$transaction_id,
                ":reciept"=>$filename,
                ":payment_mode"=>$payment_mode
            );

                $save_vetzone_payments = save("vetzone_payment_details",$fields,$values,$exe);

                if($save_vetzone_payments)
                {
                    move_uploaded_file($filetempname, "vetzone_payments/" . $filename);

                    $setval = "payment_status=:payment_status";
                    $wh = "where user_id='$user_id' and payment_status='N'";
                    $exe = array(":payment_status"=>"P");
                    $update = update("vetzone_credit_note_table",$setval,$wh,$exe);
                } 

            redirect_fn("vetzone_payments.php");
        } 
        else 
        {

            $fields = "customer_id,amount,transcation_id,reciept,payment_mode";
            $values = ":customer_id,:amount,:transcation_id,:reciept,:payment_mode";
            $exe = array(
                ":customer_id"=>$user_id,
                ":amount"=>$amount,
                ":transcation_id"=>$transaction_id,
                ":reciept"=>$filename,
                ":payment_mode"=>$payment_mode
            );

            $save_customer_payments = save("payment_details",$fields,$values,$exe);
                 
            if($save_customer_payments)
                {
                    move_uploaded_file($filetempname, "customer_payments/" . $filename);

                    $setval = "payment_status=:payment_status";
                    $wh = "where user_id='$user_id' and payment_status='N'";
                    $exe = array(":payment_status"=>"P");
                    $update = update("credit_note_table",$setval,$wh,$exe);
                } 

            }
        
            redirect_fn("customer_payments.php");
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
         <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-6">
                        <?php if($type=="customer"){?>
                             <a href="customer_payments.php" class="btn btn-info btn-md">Go to Payments</a>
                        <?php } else { ?>
                            <a href="vetzone_payments.php" class="btn btn-info btn-md">Go to Payments</a>
                        <?php } ?>
                        <br><br>
                        <div class="card">
                            <div class="card-body">
                                    <form action="" method="POST" enctype="multipart/form-data">
                                        <label for="">Amount</label>
                                        <input type="text" name="payment_amount" readonly id="amount" value="<?=$amount?>" class="form-control">
                                         <br>
                                        <label for="">Payment Mode</label>
                                        <select name="payment_mode" class="form-control" id="">
                                            <option value="Net Banking">Net Banking</option>
                                            <option value="Cash">Cash</option>
                                            <option value="UPI">UPI</option>
                                        </select>
                                        <br>
                                        <label for="">Transaction Id</label>
                                        <input type="text" name="transaction_id" id="" class="form-control">
                                        <br>
                                        <label for="">Reciept <span class="text-danger">*</span></label>
                                        <input type="file" name="file" accept="image/*" class="form-control" id="" required>
                                        <br>
                                        <br>
                                        <button type="submit" class="btn btn-primary" name="save_paymentdetails">Submit</button>
                                    </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
</body>
</html>
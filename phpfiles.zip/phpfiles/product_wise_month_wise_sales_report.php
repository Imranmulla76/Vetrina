<?php 
    include("init.php");

   

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
       <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <b class="card-title">Product wise Monthly Sales</b>
                            </div>
                            <div class="card-body">

                             <strong>Duration</strong>
                              <div class="row"> 
                                    <div class="col-2">
                                        <label for="">From</label>
                                        <input type="date" name="from_date" id="from" class="form-control" id="">
                                    </div>
                                    
                                    <div class="col-2">
                                        <label for="">To</label>
                                        <input type="date" name="to_date" id="to" class="form-control" id="">
                                    </div>
                                    
                                    <div class="col-1">
                                        <button class="btn btn-md btn-info mt-4" onclick="getreport()">Get Report</button>
                                    </div>
                                </div>
                                <br>
                                <br>
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                       
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
        <script>

        $(function(){
            $('#tasklist').DataTable({
            "lengthMenu": [10, 100, 500, 1000, 10000],
			"responsive": true,
			"processing": true,
			"serverSide": true,
			"buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"],
			"bDestroy": true,
            });
        });

            function getreport()
            {
                var from = $("#from").val();
                var to = $("#to").val();

                $.ajax({
                    url:"ajax/product_wise_monthly_sale_report.php",
                    type:"POST",
                    data:{from:from,to:to},
                }).done(function(response){
                        $('#example3').html(response);
                    });
            }
        </script>
</body>
</html>
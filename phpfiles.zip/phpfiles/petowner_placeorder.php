<?php include("init.php");
        //check_login();
    $division = find("all","divisions","*","where 1",array());
    $customer_id = $_SESSION["user_id"];
    $getorderingstatus = find("first","customer","*","where placeorder='N' and customer_id='$customer_id'",array());
   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
            <div class="content-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    
                                <?php if($getorderingstatus) { ?>
                                        <div class="row">
                                            <div class="col-12">
                                                <h4 class="text-danger">Sorry, Dear Customer Your Order are blocked due to overdue of payments</h4>
                                                <br>
                                                <h5 class="text-warning">Kindly complete your payments <a class="btn btn-info btn-sm" href="vetzone_payments.php">Click Here to Pay</a></h5>
                                            </div>
                                        </div>

                                    <?php } else { ?>

                                    <div class="row">
                                        <div class="col-3">
                                            <label for="">Select Product Division</label>
                                            <select name="division" id="division" onchange="getproducts(this.value)" class="form-control">
                                                <option value="">Select Division</option>
                                                <?php foreach($division as $k=>$v) { ?>
                                                    <option value="<?=$v["division_id"]?>"><?=$v["division_name"]?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div id="products">

                                    </div>
                                    
                                    <?php } ?>

                                </div>
                            </div>
                        </div>        
                    </div>
                </div> 
            </div>       
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

        <script>
            $(function(){
                    $("#producttable").DataTable({
						responsive: true,
						dom: 'lBfrtip',
                    	buttons: [
                        'excelHtml5',
                        'csvHtml5',
                        'pdfHtml5',
                        'colvis'
                    ]

					});
            });

            function getproducts(div_id)
            {
                $("#products").html("<div class='loader-text-animation' align='center'>Be calm ! Breath In & Breath Out....</div>");
                $.ajax({
                    url:"ajax/getproductlist.php",
                    method:"POST",
                    data : {div_id:div_id}
                }).done(function(response){
                    $("#products").html(response);
                });
            }
            
            function addtocart(product_id)
            {
                $("#productdetails").modal("show");
                $.ajax({
					method: "POST",
					url: "ajax/orderrequestform.php",
					data: {
						product_id: product_id
					}
				})
				.done(function(response) {
					$("#showdetails").html(response);
				});
            }

            
            function productaddtocart()
            { 
                $("#addtocartresponse").html("<div class='loader-text-animation' align='center'>We are validating your product! Kindly wait.</div>");
                var product_id = $("#product_id").val();
                var order_qnty = $("#order_qnty").val();
                var free_qnty = $("#free_qnty").val();
               
                if($("#scheme1").is(":checked")) 
                {
                    var scheme = $("#scheme1").val();
                }
                else
                {
                    var scheme = $("#scheme2").val();
                }

                $.ajax({
					method: "POST",
					url: "ajax/addtocart.php",
					data: {
						product_id: product_id,
                        order_qnty: order_qnty,
                        scheme:scheme
                        free_qnty:free_qnty
					}
				})
				.done(function(response) {
                    var data =JSON.parse(response);
                    if(data["status"]=="success")
                    {
                        var msg = data["msg"];
                        $("#addtocartresponse").html("<div class='text-success' align='center'>"+msg+"</div>");

                    } 
                    if(data["status"]=="error")
                    {
                        var msg = data["msg"];
                        $("#addtocartresponse").html("<div class='text-danger' align='center'>"+msg+"</div>");

                    } 
				//	$("#productdetails").modal("hide");
					// cartsummery();
				});
                cartsummery();
            }

            function getschemedetails(scheme,p_id)
            {
                $.ajax({
                        url:"ajax/getschemedetails.php",
                        method:"POST",
                        data:{scheme:scheme,p_id:p_id}
                }).done(function(response){
                    $("#scheme").html(response);
                    var invqnty = $("#inv_qnty").val();
                    $("#order_qnty").val(invqnty);
                });
            }

        
        </script>
    
</body>
</html>
<?php 
    include("init.php");

    $admin_id = $_SESSION["user_id"];

    $get_admin_hq_div = find("first","admin_hq_div","*","where admin_id='$admin_id'",array());

    $admin_hq = $get_admin_hq_div["hq_id"];
    $admin_div = $get_admin_hq_div["div_id"];

    $table_customer = "customer as c inner join customer_hq_div as chd on c.customer_id=chd.customer_id";
    $get_all_customer = find("all",$table_customer,"*","where chd.hq_id='$admin_hq' and chd.div_id='$admin_div'",array());

    // print_r($get_all_vetzone);

    $table_vetzone = "vetzone as v inner join vetzone_hq_div as vhd on v.vetzone_id=vhd.vetzone_id";
    $get_all_vetzone = find("all",$table_vetzone,"*","where vhd.hq_id='$admin_hq' and vhd.div_id='$admin_div'",array());

    // print_r($get_all_vetzone);
   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
       <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <b class="card-title">Party wise Sales</b>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>SR.No.</th>
                                                <th>Name Of Party</th>
                                                <th>Sale Value</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0;
                                                  $cust_sale = 0;
                                                foreach($get_all_customer as $key=>$val)
                                                { 
                                                    $i++;
                                                    $customer_id = $val["customer_id"];
                                                    $get_cust_sale = find("first","order_table_product","sum(quantity * rate) as sale_amount","where user_id='$customer_id' and user_role !='VetZone'",array());
                                                    $cust_sale = $cust_sale + $get_cust_sale["sale_amount"];
                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["name"]?></td>
                                                <td><?=$get_cust_sale["sale_amount"]?></td>
                                            </tr>
                                           <?php } ?>
                                           <?php $i=0;
                                                  $vet_sale =0;
                                                foreach($get_all_vetzone as $key=>$val)
                                                { 
                                                    $i++;
                                                    $vetzone_id = $val["vetzone_id"];
                                                    $get_vet_sale = find("first","order_table_product","sum(quantity * rate) as sale_amount","where user_id='$vetzone_id' and user_role='VetZone'",array());
                                                    $vet_sale = $vet_sale+$get_vet_sale["sale_amount"];
                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["name"]?></td>
                                                <td><?=$get_vet_sale["sale_amount"]?></td>
                                            </tr>
                                           <?php } ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="2"><b>Total</b></td>
                                                <td><b><?=$cust_sale+$vet_sale;?></b></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
</body>
</html>
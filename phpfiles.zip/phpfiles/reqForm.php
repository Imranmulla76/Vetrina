<?php
include("init.php");
$order_id = $_GET["order_id"];

    // $tbl = "stockused as st inner join stockuseddetails as std on st.order_no = std.order_no inner join sku as s on s.sku_id = st.sku_id
    // inner join  items as i on i.id = s.product_id inner join users as u on std.user_id= u.user_id ";

    // $findstock= find("all",$tbl , "*, i.name as product_name , u.name as customername ", "where std.stock_details_id = '$order_id' " , array());
    

    //  $order_id=$_POST["order_id"];

    $table = "order_table_product as otp inner join placeorder as p on otp.order_id=p.stockiest_order_id inner join product as pd on otp.product_id=pd.product_id inner join customer as c on p.user_id=c.customer_id";
    $order_detail = find("all",$table,"*","where otp.order_id='$order_id'",array());

    $getcustomer = find("first","placeorder as p inner join customer as c on p.user_id=c.customer_id","*","where stockiest_order_id='$order_id'",array());


    foreach($order_detail as $key=>$val)
    {
        $distributor_id = $val["user_id"];
        $date = $val["created_date"];
        $createddate = date("d/m/Y",strtotime($date));
    }

    $name = $getcustomer["name"];
    $address = $getcustomer["address"];
    $email = $getcustomer["email"];

    if(isset($_POST["orderid"]))
    {
      
      $order_id = $_POST["orderid"];
      $filename = "requisition";

       $curl = curl_init("https://vetrinahealthcare.com/dms/html2pdf/pdfreqForm.php");
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, "order_id=$order_id");
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($curl);
        curl_close($curl);

        $data =  "success";

      $mailcontent = "New Requisition form created and attached with the mail.";
      $mailsubject = "New Requisition Form";
      $to = $email;//"tushar.patil@tdtl.world";
      contractMailwithattach($to,$mailsubject,$mailcontent,$filename);

    }
?>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Requisition From</title>
  <link  rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

 <style>
    body {
      width: 50%;
      margin: auto;
      font-size: 13px;
    }

    .card {
      -webkit-box-shadow: 1px 6px 11px -3px #6e6e6e;
      box-shadow: 1px 6px 11px -3px #6e6e6e;
    }

    .logo {
      width: 25%;
      margin-left: auto;
    }

    .card-head {
      display: flex;
      align-items: center;
      padding: 20px 35px;
    }

    .card-head h1 {
      font-size: 22px;
      font-weight: bold;

    }

    .card-head h1 span {
      font-size: 15px;
      font-weight: 100;
    }

    .order {
      text-align: center;
      font-size: 20px;
      font-weight: bold;
    }

    .details {
      padding: 0 35px;
    }

    table {
      width: 100%;
    }

    table,
    th,
    td {
      border-collapse: collapse;
      border: 1px solid black;
    }

    .card-foot {
      margin-bottom: 100px;

    }

    .card-foot p {
      text-align: center;
      font-weight: bold;
      margin-bottom: 2px;
    }


    @media(max-width:990px) {
      body {
        width: 100%;
      }

    }
  </style>
</head>

<body>
  <div class="card" id="temp-target">
    <div class="card-head">
      <h1>Vetrina Healthcare Pvt. Ltd.<br><span>CIN No. U74900PN2012PTC143742</span></h1>
      <img src="https://vetrinahealthcare.com/dms/uploads/vetrina_logo.png" class="logo" />
    </div>
    <h3 class="order" style="margin-bottom: 2px;">FINISH GOOD REQUISITION FORM</h3>
    <div class="card-body" style="padding-top: 0;">
      <table>
        <tbody>
          <tr>
            <td>Requisition made by</td>
            <td><?=$name?></td>
          </tr>
          <tr>
            <td>Requisition made to</td>
            <td>Vetrina Healthcare Pvt. Ltd</td>
          </tr>
          <tr>
            <td>Date</td>
            <td><?=$createddate?></td>
          </tr>
          <tr>
            <td>Requisition No.</td>
            <td>123</td>
          </tr>
        </tbody>
      </table>

      <h3 class="order" style="text-align: left; text-decoration: underline;margin: 25px 0;">Material Required</h3>
      <table>
        <thead>
          <tr>
            <th>Sr.No</th>
            <th>Name of Product</th>
            <th>Pack</th>
            <th>Required<br>Quantity</th>
            <th>Expected <br>Date</th>
            <th>Dispatch <br>Date</th>
            <th>Received <br>Date</th>
          </tr>
        </thead>
        <tbody>
        <?php   $i=0;
                if($i<30) {
                    foreach($order_detail as $key => $value){ $i++;
                ?>
          <tr>
            <td><?=$i;?></td>
            <td><?=$value['product_name']?></td>
            <td><?=$value['units']?></td>
            <td><?=$value['quantity']?></td>
            <td>08-12-21</td>
            <td></td>
            <td></td>
          </tr>
          <?php } } ?>
          
        </tbody>
      </table>

    </div>

    <div class="card-foot" style="margin-top: 25%;">
      <div style="display: flex;padding: 0 22px;">
        <div>
          <p style="text-align: left;">Signature</p>
          <p>Date: 07-12-2021</p>
        </div>
        <div style="margin-left: 50%;">
          <p>Approved by</p><br><br>
          <p>Dr. Mangesh Ghadiogaonkar</p>
        </div>
      </div>


      <div style="margin-top: 30px;">
        <p>Registered Office : - A/30, Kudle Patil Township, Sr.No. 33/23, Manikbaug, Sinhagad Road, Pune - 411051</p>
        <p>Corporate Office : - 1,Unique Tower, Chandrabhaga Nagar, Katraj dairy Road, Katraj , Pune - 411046</p>
        <p>Tel No. 8600844450, Email: info@vetrinahealthcare.com, www.vetrinahealthcare.com</p>
      </div>

    </div>



    </div>

    <div class="row">
        <div class="col-md-12">
            <br><br>
           <center> <button onclick="converHTMLFileToPDF();" class="btn btn-success"> <i class="fas fa-file-download"></i> Generate PDF</button> 
           <form action="" method="POST">
             <input type="text" style="display:none;" name="orderid" value="<?=$order_id?>" id="">
             <button type="submit" name="send" class="btn btn-warning"> <i class="fas fa-paper-plane"></i> Send Mail </span> </center> 
           </form>
        </div>
    </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.3.1/jspdf.umd.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" ></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.0/html2canvas.min.js" ></script>
  <script>

      function converHTMLFileToPDF() 
      {
          const { jsPDF } = window.jspdf;
          var doc = new jsPDF('l', 'mm', [1800 , 1210]);

          var pdfjs = document.querySelector('#temp-target');

          // Convert HTML to PDF in JavaScript
          doc.html(pdfjs, {
              callback: function(doc) {
                  doc.save("FINISH GOOD REQUISITION FORM.pdf");
              },
              x: 10,
              y: 10
          });
      }
  
  </script>

</body>

</html>
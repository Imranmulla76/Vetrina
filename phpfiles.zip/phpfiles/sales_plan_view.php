<?php include("init.php");

    $_SESSION["product_plan"] = 1;
    $role = $_SESSION["roll"];

    $sales_plan_id = $_REQUEST["plan_id"];

   

    if(isset($_POST["update_plan"]))
    {
        $product_id = $_POST["product"];
        $product_quantity = $_POST["product_quantity"];
        $plan_value = $_POST["plan_value"];
        $sales_meta_id = $_POST["sales_meta_id"];

        foreach($product_id as $k=>$v)
        {
            $product = $product_id[$k];
            $quantity = $product_quantity[$k];
            $value = $plan_value[$k];

            $fields = "sales_meta_id,product_id,product_quantity,product_value";
            $values = ":sales_meta_id,:product_id,:product_quantity,:product_value";
            $exe = array(":sales_meta_id"=>$sales_meta_id,":product_id"=>$product,":product_quantity"=>$quantity,":product_value"=>$value);
            $save = save("sales_plan_product_meta",$fields,$values,$exe);
        }
    }

    if(isset($_POST["sales_meta_id"]))
    {
        $sales_meta_id =$_POST["sales_meta_id"];
        $status = $_POST["status"];

        if($status=="Y")
        {
            $setval ="status=:status";
            $where = "where sales_meta_id='$sales_meta_id'";
            $exe = array(":status"=>"Y");
            $updatestatus = update("sales_plan_meta",$setval,$where,$exe);
            
            if($updatestatus)
            {
                echo"<script>alert('Sales Plan Approved');</script>";
            }
        }
        else {

            $setval ="status=:status";
            $where = "where sales_meta_id='$sales_meta_id'";
            $exe = array(":status"=>"N");
            $updatestatus = update("sales_plan_meta",$setval,$where,$exe);
            
            if($updatestatus)
            {
                echo"<script>alert('Sales Plan Rejected');</script>";
            }
        }
    }

    $table="sales_plan as s inner join sales_plan_meta as spm on s.sale_plan_id=spm.sales_plan_id inner join customer as c on spm.customer_id=c.customer_id";
    $customer_plan_details = find("all",$table,"*,spm.status as approval,s.plan_amount as total","where spm.sales_plan_id='$sales_plan_id' and customer_role='Customer'",array());
    
    $table="sales_plan as s inner join sales_plan_meta as spm on s.sale_plan_id=spm.sales_plan_id inner join vetzone as v on spm.customer_id=v.vetzone_id";
    $vetzone_plan_details = find("all",$table,"*,spm.status as approval,s.plan_amount as total","where spm.sales_plan_id='$sales_plan_id' and customer_role='VetZone'",array());
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="./vendor/select2/css/select2.min.css">
    <title>SCM | Vetrina</title>

    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    <style>
        .form-control
        {
            width:auto;
        }
    </style>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
            <div class="content-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-3">
                            <a href="sales_plan.php" class="btn btn-sm btn-primary">Back to sales Plan</a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header bg-info shadow">
                                    <h4 class="card-title">Sales Plan Detailed View</h4>
                                </div> 

                                <div class="card-body">
                                   <div class="table-responsive">
                                        <table id="example3" class="display">
                                            <thead>
                                                <tr>
                                                    <th>Sr.No.</th>
                                                    <th>Party Name</th>
                                                    <th>Party Type</th>
                                                    <th>Last Month Sale</th>
                                                    <th>Sales Plan</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                    $i=0;
                                                    foreach($customer_plan_details as $key=>$val) { $i++;?>
                                                    <tr>
                                                        <td><?=$i?></td>
                                                        <td><?=$val["name"]?></td>
                                                        <td><?=$val["customer_role"]?></td>
                                                        <td><input type="text" readonly name="last_month_sale" value="500000" class="form-control" id=""></td>
                                                        <td><input type="number" readonly name="paln_amount" value="<?=$val["plan_value"]?>" class="form-control" id=""></td>
                                                        <td>
                                                            <?php if($role=="5"){ 
                                                             if($val["approval"]=="Y")
                                                                    { 
                                                                        echo "<p class='text-success'>Accepted</p>";
                                                                    } 
                                                                    else if($val["approval"]=="N")
                                                                    {
                                                                    echo "<p class='text-success'>Rejected</p>";} else {
                                                                ?>    
                                                          
                                                                <form action="" method="POST" id="approval1">
                                                                    <input type="text" hidden name="sales_meta_id" value="<?=$val['sales_meta_id']?>">
                                                                    <select name="status" class="form-control" onchange="submitform1();" id="status1">
                                                                        <option value="">Select Status</option>
                                                                        <option <?php if($val["approval"]=="Y"){echo "Selected";}?> value="Y">Accept</option>
                                                                        <option <?php if($val["approval"]=="N"){echo "Selected";}?> value="N">Reject</option>
                                                                    </select>
                                                                </form>    
                                                            <?php } } else {
                                                                if($val["approval"]=="P")
                                                                {echo "<p class='text-warning'>Pending</p>";}
                                                                else if($val["approval"]=="Y")
                                                                {echo "<p class='text-success'>Accepted</p>";}
                                                                else 
                                                                {echo "<p class='text-danger'>Rejected</p>";}
                                                            } ?>
                                                        </td>
                                                        <td>
                                                            <span onclick="editplan(<?=$val['sales_meta_id']?>)" class="btn btn-primary shadow btn-xs sharp mr-1"><i class="fa fa-pencil"></i></span>
                                                        </td>
                                                    </tr>
                                                <?php }
                                                 foreach($vetzone_plan_details as $key=>$val) { $i++;?>
                                                    <tr>
                                                        <td><?=$i?></td>
                                                        <td><?=$val["name"]?></td>
                                                        <td><?=$val["customer_role"]?></td>
                                                        <td><input type="text" readonly name="last_month_sale" value="500000" class="form-control" id=""></td>
                                                        <td><input type="number" readonly name="paln_amount" value="<?=$val["plan_value"]?>" class="form-control" id=""></td>
                                                        <td>
                                                            <?php if($role=="5"){ 
                                                                    if($val["approval"]=="Y")
                                                                    { 
                                                                        echo "<p class='text-success'>Accepted</p>";
                                                                    } 
                                                                    else if($val["approval"]=="N")
                                                                    {
                                                                    echo "<p class='text-success'>Rejected</p>";} else {
                                                                ?>
                                                                <form action="" method="POST" id="approval2">
                                                                    <input type="text" hidden name="sales_meta_id" value="<?=$val['sales_meta_id']?>">
                                                                    <select name="status" class="form-control" onchange="submitform2();" id="status1">
                                                                        <option value="">Select Status</option>
                                                                        <option <?php if($val["approval"]=="Y"){echo "Selected";}?>  value="Y">Accept</option>
                                                                        <option <?php if($val["approval"]=="N"){echo "Selected";}?>  value="N">Reject</option>
                                                                    </select>
                                                                </form>    
                                                            <?php } }else{
                                                             
                                                                if($val["approval"]=="P")
                                                                {echo "<p class='text-warning'>Pending</p>";}
                                                                else if($val["approval"]=="Y")
                                                                {echo "<p class='text-success'>Accepted</p>";}
                                                                else 
                                                                {echo "<p class='text-danger'>Rejected</p>";}
                                                             }?>
                                                        </td>
                                                        <td>
                                                            <span onclick="editplan(<?=$val['sales_meta_id']?>)" class="btn btn-primary shadow btn-xs sharp mr-1"><i class="fa fa-pencil"></i></span>
                                                        </td>
                                                    </tr>
                                                <?php $total = $val["total"]; }?>
                                                    
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td colspan="4"><b>Total</b></td>
                                                    <td colspan="3"><b><?=$total?></b></td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div> 
                        </div> 
                    </div> 
                </div> 
            </div> 
        
        <!-------main content end----->

        <!-- Create Modal -->
        <div id="productplan" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Create Product wise Sales Plan</h5>
                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                        </button>
                    </div>
                    <form action="" method="POST">
                        <div class="modal-body" id="planform">
                            
                            
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" id="btn-sub" name="update_plan">Update Plan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    <!-- Create Modal -->

        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
        <script src="./vendor/select2/js/select2.full.min.js"></script>
        
        <script>
            $("#single-select").select2();

            function editplan(sales_meta_id)
            {
                $("#productplan").modal("show");

                $.ajax({
                    url:"ajax/createsalesplan.php",
                    method:"POST",
                    data:{sales_meta_id:sales_meta_id}
                }).done(function(response){
                    $("#planform").html(response);
                });
            }

            function additeminlist()
            {
                $.ajax({
                    url:"ajax/add_product_row.php",
                    data:{}
                }).done(function(msg){
                    $("#productwiseplan").append(msg);
                });
            }

            function removeiteminlist(row) 
            {
                $("#new_row"+row).remove();
            }

            function submitform1()
            {
                $("#approval1").submit();
            }
            function submitform2()
            {
                $("#approval2").submit();
            }
        </script>
</body>
</html>
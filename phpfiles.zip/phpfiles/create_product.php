<?php include("init.php");
        //check_login();

    if(isset($_POST["add_product"]))
    {
        $p_name = $_POST["p_name"];
        $p_category = $_POST["p_category"];
        $p_code = $_POST["p_code"];
        $sku = $_POST["sku"];
        $number = $_POST["number"];
        $unit = $number." ".$_POST["unit"];
        $manufacturer = $_POST["manufacturer"];
        $gst = $_POST["gst"];
        $igst = $_POST["igst"];
        $cgst = $_POST["cgst"];
        $sgst = $_POST["sgst"];
        $p_group = $_POST["p_group"];
        $p_division = $_POST["division"];
        $barcode = $_POST["barcode"];
        $shipper_size = $_POST["shipper_size"];
        $hsn = $_POST["hsn"];
        $ic_code = $_POST["ic_code"];
        $nrv = $_POST["nrv"];
        $schedule = $_POST["schedule"];
        $inventory_days = $_POST["inventory_days"];

        $fields = "product_name,sku,product_code,unit,product_division,category_id,group_id,manufacturer,barcode,shipper_size,hsn_code,ic_code,schedule,inventory_days";
        $values = ":product_name,:sku,:product_code,:unit,:product_division,:category_id,:group_id,:manufacturer,:barcode,:shipper_size,:hsn_code,:ic_code,:schedule,:inventory_days";
        $exe = array(
            ":product_name"=>$p_name,
            ":sku"=>$sku,
            ":product_code"=>$p_code,
            ":unit"=>$unit,
            ":product_division"=>$p_division,
            ":category_id"=>$p_category,
            ":group_id"=>$p_group,
            ":manufacturer"=>$manufacturer,
            ":barcode"=>$barcode,
            ":shipper_size"=>$shipper_size,
            ":hsn_code"=>$hsn,
            ":ic_code"=>$ic_code,
            ":schedule"=>$schedule,
            ":inventory_days"=>$inventory_days
        );

        $saveproduct = save("product",$fields,$values,$exe);

        if($saveproduct)
        {
            $f = "product_id,gst,igst,cgst,sgst";
            $v = ":product_id,:gst,:igst,:cgst,:sgst";
            $exe = array(
                ":product_id"=>$saveproduct,
                ":gst"=>$gst,
                ":igst"=>$igst,
                ":cgst"=>$cgst,
                ":sgst"=>$sgst
            );
            
            $savegst = save("product_gst",$f,$v,$exe);
        }
    }

    $category = find("all","product_category","*","where 1",array());
    $group = find("all","product_group","*","where 1",array());
    $division = find("all","divisions","*","where 1",array());
    $tblproductdetails = "product as p inner join product_category as pc on p.category_id=pc.category_id inner join divisions as d on p.product_division=d.division_id";
    $findproduct = find("all",$tblproductdetails,"*","where 1",array());

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>

</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
   <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
                    <a href="add_product.php" class="btn btn-primary">+ Add Product</a>
				</div>

                <div class="row mt-3">
                    <div class="col-12">
                      <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Products</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example3" class="display min-w850">
                                <thead>
                                    <tr>
                                        <th>SR.No.</th>
                                        <th>Product Name</th>
                                        <th>Category</th>
                                        <th>Product Code</th>
                                        <th>SKU</th>
                                        <th>Division</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php //print_r($finddesignations); ?>
                                    <?php $i=0; foreach($findproduct as $k=>$v) { $i++;?>
                                    <tr>
                                        <td><?=$i;?></td>
                                        <td><strong><?=$v["product_name"]?></strong></td>
                                        <td><?=$v["category_name"]?></td>
                                        <td><?=$v["product_code"]?></td>
                                        <td><?=$v["sku"]?></td>
                                        <td><?=$v["division_name"]?></td>
                                        <td>
                                            <div class="d-flex">
                                                <a href="edit_product.php?product_id=<?=$v['product_id']?>" class="btn btn-primary shadow btn-xs sharp mr-1"><i class="fa fa-pencil"></i></a>
                                                <a href="#" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
											</div>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                                </table>
                            
                            </div>
                           
                        </div>
                    </div>
                    </div>
                </div>

            </div>
        </div>
        !-------main content end----->
        <?php include("footer.php"); ?>
    </div>


    <!-- Create Modal -->
 <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Create Product (Item) </h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <form action="" method="POST">
            <div class="modal-body">
                
                   <div class="row">
                       <div class="col-3">
                            <label for="">Product Name</label>
                            <input type="text" name="p_name" id="" class="form-control">
                       </div>
                       <div class="col-3">
                            <label for="">Category</label>
                             <select name="p_category" id="" class="form-control">
                                <option value="">Select Category</option>
                                <?php foreach($category as $k=>$v) { ?>
                                    <option value="<?=$v["category_id"]?>"><?=$v["category_name"]?></option>
                                <?php } ?>
                                <option onclick="addCategory(this.value);" value="other">Other</option>
                            </select>
                       </div>
                        <div class="col-3">
                            <label for="">Product Code</label>
                            <input type="text" name="p_code" id="" class="form-control">
                       </div>
                        <div class="col-3">
                            <label for="">SKU</label>
                            <input type="text" name="sku" id="" class="form-control">
                       </div>
                   </div>
                
                   <br>
                    <div class="row">
                       <div class="col-4">
                            <label for="">Unit</label>
                            <div class="row">
                                <div class="col-6">
                                    <input type="number" name="number" id="" class="form-control">
                                </div>
                                 <div class="col-6">
                                    <select name="unit" class="form-control" id="">
                                        <option value="ml">ml</option>
                                        <option value="Kg">Kg</option>
                                        <option value="No">No</option>
                                        <option value="g">g</option>
                                        <option value="lit">lit</option>
                                    </select>
                                </div>
                            </div>
                       </div>

                       <div class="col-4">
                            <label for="">Manufacturer</label>
                            <input type="text" name="manufacturer" id="" class="form-control">
                       </div>
                        <div class="col-4">
                            <label for="">GST</label>
                            <input type="text" name="gst" id="" class="form-control">
                       </div>
                    </div>
<br>
                    <div class="row">
                       
                        <div class="col-4">
                            <label for="">IGST</label>
                            <input type="text" name="igst" id="" class="form-control">
                       </div>
                        <div class="col-4">
                            <label for="">CGST</label>
                            <input type="text" name="cgst" id="location" class="form-control">
                       </div>
                        <div class="col-4">
                            <label for="">SGST</label>
                            <input type="text" name="sgst" id="location" class="form-control">
                       </div>
                        
                    </div>
                    <br>

                   <div class="row">
                       <div class="col-4">
                           <label for="">Group</label>
                            <select name="p_group" id="" class="form-control">
                                <option value="">Select Group</option>
                                <?php foreach($group as $k=>$v) { ?>
                                    <option value="<?=$v["group_id"]?>"><?=$v["group_name"]?></option>
                                <?php } ?>
                                <option onclick="addCategory(this.value);" value="other">Other</option>
                            </select>
                       </div>

                        <div class="col-4">
                           <label for="">Division</label>
                            <select name="division" id="" class="form-control">
                                    <option value="">Select division</option>
                                    <?php foreach($division as $k=>$v) { ?>
                                        <option value="<?=$v["division_id"]?>"><?=$v["division_name"]?></option>
                                    <?php } ?>
                           </select>
                        </div>
                      
                       <div class="col-4">
                           <label for="">Barcode</label>
                           <input type="text" name="barcode" id="" class="form-control">
                        </div>
                   </div>
                   <br>

                   <div class="row">
                        
                        <div class="col-4">
                           <label for="">Shipper Size</label>
                           <input type="text" name="shipper_size" id="" class="form-control">
                        </div>
                       
                        <div class="col-4">
                           <label for="">HSN Code</label>
                           <input type="text" name="hsn" id="" class="form-control">
                        </div>
                        <div class="col-3">
                           <label for="">IC Code</label>
                         <input type="text" name="ic_code" id="" class="form-control">
                       </div>
                   </div>
                
                   <br>

                   <div class="row">
                       
                       <div class="col-3">
                            <label for="">NRV</label>
                            <input type="text" name="nrv" id="" class="form-control">
                       </div>
                       <div class="col-3">
                            <label for="">Schedule</label>
                            <input type="text" name="schedule" id="" class="form-control">
                       </div>
                       <div class="col-3">
                            <label for="">Inventory Days</label>
                            <input type="text" name="inventory_days" id="" class="form-control">
                       </div>
                   </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" name="add_product">Add Product</button>
            </div>
            </form>
        </div>
    </div>
</div>

 <!-- Create Modal -->


        <?php include("jslink.php"); ?>
        <script>
            $(document).ready(function(){
                <?php if($saveproduct) { ?>
                    swal("User Added","New User Created","success");    
                <?php } ?>
            })
        </script>
</body>
</html>
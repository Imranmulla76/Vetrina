<?php 
    include("init.php");

    // $table = "order_table_product as otp inner join placeorder as p otp.order_id=p.stockiest_order_id";
    $user_id = $_SESSION["user_id"]; 
    $role = $_SESSION["roll"]; 
   
    /* select *, sum(amount) as due FROM
    vetzone_credit_note_table vcnt, vetzone v
    where vcnt.user_id = v.vetzone_id
    and payment_status = 'Y'
    group by vcnt.user_id; */
   $table = "vetzone_credit_note_table vcnt, vetzone v";
   $payments = find("all", $table, "*, sum(amount) as due","where vcnt.user_id = v.vetzone_id and payment_status = 'Y'
   group by vcnt.user_id", array());

   
   
 ?>
<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table bordered id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Customer Name</th>
                                                <th>Total Paid Amount</th>
                                                <th>Payment Date</th>
                                                <th>Payment Status</th>
                                                <th>Comment</th>
                                                <th>View</th>
                                             </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                $i=0; foreach($payments as $key=>$val) { $i++;
                                                    $paid_amount = $val["due"];
                                                    $vetzone_id = $val["user_id"];
                                                    $getpaymentdetails = find("first","vetzone_payment_details","*","where amount='$paid_amount' and vetzone_id='$vetzone_id'",array());
                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["name"]?></td>
                                                <td><?=$getpaymentdetails["amount"]?></td>
                                                <td><?=$getpaymentdetails["payment_date"]?></td>
                                                <td>
                                                <?php
                                                    if($val["payment_status"]=="Y")
                                                    {
                                                        echo "<label class='label label-success'>Completed</label>";
                                                    }
                                                
                                                    ?>
                                                </td> 
                                                <td><?=$val["comment"]?></td>
                                                <td><span onclick="view_payment_details('<?=$val['vetzone_id']?>')"  class="btn btn-info shadow btn-xs sharp"><i class="fa fa-eye"></i></span></td>
                                                
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>        
                            </div>
                        </div>            
                    </div>            
                </div>            
            </div>            
        </div>            
        <!-------main content end----->
        

         <!-- Payment Modal -->
    <div class="modal fade paymentdetails" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header header-primary">
                    <h5 class="modal-title">Payment Details</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="modal-body" id="payment_details">
                           
                    </div>
                    <div class="modal-footer">

                        <select name="action" class="form-control" required id="">
                            <option value="approve">Approve</option>
                            <option value="decline">Decline</option>
                        </select>
                        <button type="submit" class="btn btn-primary" name="apply">Apply</button>
                        <!-- <button type="submit" class="btn btn-primary" name="approve">Save & Approve Order</button> -->
                        <!-- <button type="submit" class="btn btn-danger" name="decline">Decline Order</button> -->
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->


        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

        <script>

            $(function(){

                <?php if($updatepaymentstatusApprove) { ?>
                    swal("Payment Approved","vetzone payment approved","success");
                <?php } ?>

                <?php if($updatepaymentstatusDecline) { ?>
                    swal("Payment Declined","vetzone payment declined","danger");
                <?php } ?>
            });

           function view_payment_details(vetzone_id)
           {
                $(".paymentdetails").modal("show");

                $.ajax({
                    url:"ajax/vetzone_payment_details.php",
                    method:"POST",
                    data:{vetzone_id : vetzone_id}
                }).done(function(response) {
                    $("#payment_details").html(response);
                });
               
           }

        </script>
    </body>
</html>
    <?php 
    
    include("init.php");

        $finddesignations = find("all","designations","*","where 1",array());
        $finddivision = find("all","divisions","*","where 1",array());
        $findheadquarter = find("all","headquarters","*","where 1",array());

       $table = "target_meta as tm inner join target_table as tt on tt.target_id=tm.target_id inner join admin as a on tt.user_id=a.admin_id inner join admin_roles as ar on a.admin_id=ar.admin_id inner join designations as d on ar.desig_id=d.desig_id inner join headquarters as h on tt.hq_id=h.hq_id";

       // $table = "target_table as tt inner join target_meta as tm on tt.target_id=tm.target_id inner join admin as a on tt.user_id=a.admin_id";
        
        if(isset($_POST["delete"]))
        {
            $target = $_POST["target_id"];

            $where = "where target_id='$target'";
            $exe=array();
            $deletemeta = delete("target_meta",$where,$exe);

            if($deletemeta)
            {
                $where = "where target_id='$target'";
                $exe=array();
                $deletetarget = delete("target_table",$where,$exe);
            }
        }

        $findtarget = find("all",$table,"*","where 1 group by tm.target_id",array());

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>SCM | Vetrina</title>
        <!-- Favicon icon -->
        <?php include("csslink.php"); ?>
    </head>
    <body>
    <?php include("preloader.php") ?>

        <div id="main-wrapper">
            <?php include("navbar.php"); ?>
            <?php include("chatbox.php"); ?>		
            <?php include("header.php"); ?>
            <?php include("sidebar.php"); ?>
            <!-----maincontent start----->
            <div class="content-body">
                <!-- row -->
                <div class="container-fluid">
                    <div class="row">
                        <!-- <button class="btn btn-primary" data-target=".bd-example-modal-sm" data-toggle="modal">+ Add Target</button> -->
                        <a href="set_target.php" class="btn btn-primary">Set New Target</a>
                    </div>

                    
                    <div class="row mt-3">
                        <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Target</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table  id="example3" class="display min-w850">
                                    <thead>
                                        <tr>
                                            <th>SR No.</th>
                                            <th>User</th>
                                            <th>Email</th>
                                            <th>Headqurter</th>
                                            <th>Designation</th>
                                            <th>Yearly Target</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php //print_r($finddesignations); ?>
                                        <?php  $i=0; foreach($findtarget as $k=>$v) { $i++;
                                                
                                                //$yealrytarget = 0;
                                                // $findprod = find("all","product","*","where 1",array());

                                               
                                                    $product_id = $val["product_id"];
                                                    $user_id= $v['user_id'];
                                                    $target_id = $v["target_id"];

                                                    $target = find("first","target_meta","sum(value) as yearlytarget","where target_id='$target_id'",array());
                                                    $yealrytarget = $target["yearlytarget"];
                                                          
                                        ?>
                                        <tr>
                                            <td><?=$i;?></td>
                                            <td><?=$v["username"]?></td>
                                            <td><?=$v["admin_email"]?></td>
                                            <td><?=$v["hq_name"]?></td>
                                            <td><?=$v["desig_name"]?></td>
                                            <td><?=$yealrytarget?></td>
                                            <td>
                                                <div class="d-flex">
                                                    <a href="view_target_details.php?target_id=<?=$v["target_id"]?>" class="btn btn-primary shadow btn-xs sharp mr-1"><i class="fa fa-eye"></i></a>
                                                    <form action="" method="POST">
                                                        <input type="text" name="target_id" value="<?=$target_id?>" hidden id="">
                                                        <button class="btn btn-danger shadow btn-xs sharp" type="submit" name="delete"><i class="fa fa-trash"></i></button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php  } ?>
                                    </tbody>
                                    </table>
                                </div>
                            
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
            
            <!-------main content end----->
            <?php include("footer.php"); ?>
        </div>


        <!-- Create Modal -->
    <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Set Target</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                
                    <div class="modal-body">
                        
                        <form action="" method="POST">
                            <div class="row">
                                <div class="col-6">
                                    <label for="">Select User</label>
                                    <select name="designation" id="designation" onchange="getusersbydesig(this.value)" class="form-control">
                                        <option value="">Select Designation</option>
                                        <option value="2">GM (General Manager)</option>
                                        <option value="3">NSM (National Sales Manager)</option>
                                        <option value="4">ZSM (Zonal Sales Manager)</option>
                                        <option value="5">ASM (Area Sales Manager)</option>
                                        <option value="6">VSO (Veterinary Sales Officer)</option>
                                    </select>
                                </div>
                                <div class="col-6">
                                    <label for="">Select Headquarters</label>
                                    <select name="headquarter" class="form-control" onchange="getusers(this.value)" id="hq">
                                        <option value="">Select Headquarter</option>
                                        <?php foreach($findheadquarter as $k=>$v){?>
                                            <option value="<?=$v["hq_id"]?>"><?=$v["hq_name"]?> - (<?=$v["base_town"]?>)</option>
                                        <?php } ?>
                                    </select>
                                </div>
                                
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-6">
                                    <div id="user">
                                    </div>
                                </div>

                                <div class="col-6">
                                    <label for="">Excel Sheet</label>
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Upload</span>
                                        </div>
                                        <div class="custom-file">
                                            <input type="file" name="file" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" class="custom-file-input">
                                            <label class="custom-file-label">Choose file</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <br>

                        <div class="row">
                            <div class="col-3">
                                <button class="btn btn-sm btn-success shadow" onclick="uploadExcel()" id="calculateTarget">Upload & Calculate Target</button>
                            </div>
                        </div>
                        <br>
                    </form>
                    
                    <div class="row">
                            <div class="col-6">
                                <label for="">Year</label>
                                <input type="number" name="year" class="form-control" id="">
                            </div>
                            <div class="col-6">
                                <label for="">Yearly Target Amount</label>
                                <div class="row">
                                        <div class="col-sm-6">
                                            <input type="number" name="amount" id="amount" class="form-control">
                                        </div>
                                        <div class="col-sm-6">
                                            <select name="unit" id="" class="form-control">
                                                <option value="">Select Unit</option>
                                                <option value="">Thousand</option>
                                                <option value="">lac</option>
                                                <option value="">Cr</option>
                                            </select>
                                        </div>
                                </div>
                            </div>
                        </div>

                        <br>
                        <div class="row">
                            <div class="col-6">
                                <label for="">Quarter 1</label>
                                <input type="number" name="percent1" onkeyup="calpercent(this.value,'1')" class="form-control" placeholder="%" id="">
                            </div>
                            <div class="col-6">
                                <label for="">Amount</label>    
                                <input type="number" readonly class="form-control" name="amount1" id="amount1">

                            </div>
                        </div>

                        <br>
                        <div class="row">
                            <div class="col-6">
                                <label for="">Quarter 2</label>
                                <input type="number" onkeyup="calpercent(this.value,'2')" name="percent2" class="form-control" id="">
                            </div>
                            <div class="col-6">
                                <label for="">Amount</label>    
                                <input type="number" readonly class="form-control" name="amount2" id="amount2">
                                
                            </div>
                        </div>

                        <br>
                        <div class="row">
                            <div class="col-6">
                                <label for="">Quarter 3</label>
                                <input type="number" onkeyup="calpercent(this.value,'3')" name="percent3" class="form-control" id="">
                            </div>
                            <div class="col-6">
                                <label for="">Amount</label>    
                                <input type="number" readonly class="form-control" name="amount3" id="amount3">
                                
                            </div>
                        </div>

                        <br>
                        <div class="row">
                            <div class="col-6">
                                <label for="">Quarter 4</label>
                                <input type="number" onkeyup="calpercent(this.value,'4')" name="percent4" class="form-control" id="">
                            </div>
                            <div class="col-6">
                                <label for="">Amount</label>    
                                <input type="number" readonly class="form-control" name="amount4" id="amount4">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <span class="btn btn-info" onclick="calculateMonthly()">Show Monthly</span>
                        </div>
                        <div class="row">
                            <div class="monthly">

                            </div>                
                        </div>

                    </div>
                    
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="set_target">Set Target</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Modal -->


            <?php include("jslink.php"); ?>

            <script>

                <?php if($deletetarget) { ?>
                    swal("target Deleted !","target Deleted Successfully","success");
                <?php } ?>
                function getusers(hq_id) {
                    var desig_id = $("#designation").val();

                    $.ajax({
                        url: "ajax/getUsers.php",
                        method: "POST",
                        data: {
                            desig_id:desig_id , hq_id:hq_id
                        },
                        success: function( result ) {
                            $("#user").html(result);
                        }
                        });
                }

                function getusersbydesig(desig_id) {
                    var hq_id = $("#hq").val();

                    $.ajax({
                        url: "ajax/getUsers.php",
                        method: "POST",
                        data: {
                            desig_id:desig_id , hq_id:hq_id
                        },
                        success: function( result ) {
                            $("#user").html(result);
                        }
                        });
                }

                function calpercent(percent,Quarter)
                {
                    var yearlyAmount = $("#amount").val();
                    
                    if(Quarter == "1")
                    {
                        var amount1 =  Math.round(yearlyAmount *  (percent / 100) );
                        $("#amount1").val(amount1);
                    }

                    if(Quarter == "2")
                    {
                        var amount2 =  Math.round(yearlyAmount * (percent / 100));
                        $("#amount2").val(amount2);
                    }

                    if(Quarter == "3")
                    {
                        var amount3 =  Math.round(yearlyAmount * (percent / 100));
                        $("#amount3").val(amount3);
                    }

                    if(Quarter == "4")
                    {
                        var amount4 =  Math.round(yearlyAmount * (percent / 100));
                        $("#amount4").val(amount4);
                    }
                    
                }

                function calculateMonthly()
                {
                   var quarter1 = $("#amount1").val();
                   var quarter2 = $("#amount2").val();
                   var quarter3 = $("#amount3").val();
                   var quarter4 = $("#amount4").val();

                   var janTomar = Math.round(quarter1/3);
                   var aprlTojune = Math.round(quarter2/3);
                   var julyTosep = Math.round(quarter3/3);
                   var octTodec = Math.round(quarter4/3);

                   $(".monthly").append('<span class="badge light badge-danger">January - '+janTomar+'</span> &nbsp;&nbsp;&nbsp;&nbsp;  <span class="badge light badge-danger">February - '+janTomar+'</span> &nbsp;&nbsp;&nbsp;&nbsp;  <span class="badge light badge-danger">March - '+janTomar+'</span><br>');
                   $(".monthly").append('<br><span class="badge light badge-danger">April - '+aprlTojune+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">May - '+aprlTojune+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">June - '+aprlTojune+'</span><br>');
                   $(".monthly").append('<br><span class="badge light badge-danger">July - '+julyTosep+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">August - '+julyTosep+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">September - '+julyTosep+'</span><br>');
                   $(".monthly").append('<br><span class="badge light badge-danger">October - '+octTodec+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">November - '+octTodec+'</span> &nbsp;&nbsp;&nbsp;&nbsp; <span class="badge light badge-danger">December - '+octTodec+'</span><br>');
                }
            </script>
        
    </body>
    </html>
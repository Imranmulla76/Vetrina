<?php include("init.php");
       
       $roll = $_SESSION["roll"];
        echo $roll;
       if(isset($_POST["delete"]))
       {
            $vetzone_id = $_POST["vetzone_id"];
            $where ="where vetzone_id='$vetzone_id'";
            $exe = array();
            $deletevetzone_meta = delete("vetzone_meta",$where,$exe);

           if($deletevetzone)
           {
                $where ="where vetzone_id='$vetzone_id'";
                $exe = array();
                $deletevetzone_meta = delete("vetzone_meta",$where,$exe);
           }
       }
       
      
        $tbladmin = "admin as a inner join admin_hq_div as ahd on ahd.admin_id=a.admin_id";
        $admin_id = $_SESSION["user_id"];

        $table = "vetzone as v inner join vetzone_type as vt on v.type=vt.v_type_id";

        if($roll == "7")
        {
            $findcustomers = find("all",$table,"*","where v.kyc_status ='Y'AND  v.approval_status = 'Y' AND v.is_registered='Y' ",array());
        }
        else
        {
            $findcustomers = find("all",$table,"*","where  v.approval_status = 'N' and is_registered='Y'",array());
        }
       
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"> Active VetZone List</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.no</th>
                                                <th>VetZone Name</th>
                                                <th>Type</th>
                                                <th>Email</th>
                                                <th>Mobile No.</th>
                                                <th>Registration Date</th>
                                                <th>Approval status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; foreach($findcustomers as $key=>$val) { $i++;  ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["name"]?></td>
                                                <td><?=$val["v_type_name"]?></td>
                                                <td><?=$val["email"]?></td>
                                                <td><?=$val["mobile_number"]?></td>
                                                <td><?=$val["created_on"]?></td>
                                                <td>
                                                    <?php if($val["approval_status"]=="Y")
                                                        { 
                                                            echo "<label class='label label-success'>Approved</label>"; 
                                                        }
                                                        // else if($val["approval_status"]=="F")
                                                        // {
                                                        //     echo "<label class='label label-info'>Approved by finance</label>";
                                                        // }
                                                        // else 
                                                        // {
                                                        //     echo "<label class='label label-warning'>Pending</label>";
                                                        // }
                                                    ?>
                                                </td>
                                                <td>
                                                    <div class="d-flex" >
                                                        <a href="vetzone_details.php?vetzone_id=<?php echo $val["vetzone_id"];?>" class="btn btn-info shadow btn-xs sharp mr-1"><i class="fa fa-eye"></i></a>
                                                        <form action="" method="POST">
                                                            <input type="text" name="cust_id" value="<?=$val["vetzone_id"]?>" hidden id="">
                                                            <button name="delete" type="submit" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                    </div>
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
</body>
</html>
<?php 
    include("init.php");

    $table = "instock as i inner join product as p on i.product_id=p.product_id";
    $inventory = find("all",$table,"*,sum(quantity) as qnty","where 1 group by i.product_id",array());
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Product Name</th>
                                                <th>SKU</th>
                                                <th>Unit</th>
                                                <th>Product Code</th>
                                                <th>Available Quantity</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; foreach($inventory as $key=>$val) { $i++; 

                                                $getactualstock = find("first","order_table_product","* , sum(quantity) as qnt","where product_id='".$val["product_id"]."'",array());
                                                
                                                //echo "where product_id='".$val["product_id"]."' and batch='".$val["batch"]."' "; 
                                                $soldquantity = $getactualstock["qnt"];
                                               // echo $soldquantity."<br>";
                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["product_name"]?></td>
                                                <td><?=$val["sku"]?></td>
                                                <td><?=$val["unit"]?></td>
                                                <td><?=$val["product_code"]?></td>
                                                <td><?=$val["qnty"]-$soldquantity;?></td>
                                                <td><span class="btn btn-info btn-sm" onclick="viewProductDetails(<?=$val["product_id"]?>)"><i class="fa fa-eye"></i></span></td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>        
                            </div>
                        </div>            
                    </div>            
                </div>            
            </div>            
        </div>
        
        <!-- Modal Product Details -->

        <div class="modal fade bd-example-modal" id="productdetails" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Product Details</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="bactchquantity">
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="save_division">Save Divsion</button>
                </div>
            </div>
        </div>
    </div>

        
        <!-- / Modal Product Details -->

        <!-------main content end----->

        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

        <script>
            function viewProductDetails(product_id)
            {
                $("#productdetails").modal("show");

                $.ajax({
                    url :"ajax/viewcompanyinventory.php",
                    method :"POST",
                    data : { product_id:product_id }
                
                    }).done(function(response) {
                        $("#bactchquantity").html(response);
                });
            }
        </script>
    
</body>
</html>
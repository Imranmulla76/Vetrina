<?php 
    include("../init.php");
    $credit_id = $_POST["credit_id"];

    $getpaymentdetails = find("first","vetzone_payment_details","*","where credit_note_id='$credit_id'",array());

?>

 <label for="">Credit Id</label>
    <input type="text" name="credit_order_id" class="form-control" readonly id="cr_order_id" value="<?=$credit_id?>">
    <br>
    <label for="">Payment Mode</label>
    <select name="payment_mode" class="form-control" id="">
            <option <?php if($getpaymentdetails["payment_mode"]=="Net Banking"){ echo "selected"; }?> value="Net Banking">Net Banking</option>
            <option <?php if($getpaymentdetails["payment_mode"]=="Cash"){ echo "selected"; }?> value="Cash">Cash</option>
            <option <?php if($getpaymentdetails["payment_mode"]=="UPI"){ echo "selected"; }?> value="UPI">UPI</option>
    </select>
    <br>
    <label for="">Transaction Id</label>
    <input type="text" name="transaction_id" id="" value="<?=$getpaymentdetails["transcation_id"]?>" class="form-control">
    <br>
    <label for="">Amount</label>
    <input type="text" name="payment_amount" readonly id="amount" value="<?=$getpaymentdetails["amount"]?>" class="form-control">
    <br>
    <label for="">Reciept <span class="text-danger">*</span></label>
    <a href="vscm/vetzone_payments/<?=$getpaymentdetails["reciept"]?>" target="_blank"><img src="vscm/vetzone_payments/<?=$getpaymentdetails["reciept"]?>" height="50px" width="100px" alt=""></a>
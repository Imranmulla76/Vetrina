<?php include("init.php");
//check_login();
$_SESSION["product"] = 1;
$user_id = $_SESSION["user_id"];
$rand_no = rand(1, 9999);

$findgrno = find("all", "good_reciept", "*", "where 1", array());

$gr_no = count($findgrno) + 1;

$products = find("all", "product", "*", "where 1", array());

if (isset($_POST['savestock'])) {

    $gr_no = $_POST["gr_no"];
    $challan_no = $_POST["challan_no"];
    $challan_date = $_POST["challan_date"];
    $supplier = $_POST["supplier"];
    $product = $_POST["product"];
    $sku = $_POST["sku"];
    $quantity = $_POST["quantity"];
    // $batch = $_POST["batch"];
    $batch = $_POST["textbatch"];
    /* echo "batch : ";
    print_r($batch);
    echo "textbatch : ";
    print_r($textbatch); */
    // exit;
    $manfacturing_date = $_POST["manfacturing_date"];
    $expiry_date = $_POST["expiry_date"];
    $mrp = $_POST["mrp"];
    $purchase_rate = $_POST["purchase_rate"];
    $ptd = $_POST["ptd"];
    $ptr = $_POST["ptr"];
    $ptc = $_POST["ptc"];
    $ptv = $_POST["ptv"];
    $ptk = $_POST["ptk"];
    $margin = $_POST["margin"];
    //$ptp = $_POST["ptp"];
    // $invoice_qnty = $_POST["invoice_qnty"];
    // $free_qnty = $_POST["free_qnty"];

    $fields = "gr_no,challan_no,challan_date,supplier";
    $values = ":gr_no,:challan_no,:challan_date,:supplier";
    $exe = array(
        ":gr_no" => $gr_no,
        ":challan_no" => $challan_no,
        ":challan_date" => $challan_date,
        ":supplier" => $supplier
    );

    $savereciept = save("good_reciept", $fields, $values, $exe);

    if ($savereciept) {

        foreach ($product as $k => $v) {
            $prod = $product[$k];
            $skus = $sku[$k];
            $qnty = $quantity[$k];
            $batchs = $batch[$k];
            $manfacturing_dates = $manfacturing_date[$k];
            $expiry_dates = $expiry_date[$k];
            $mrps = $mrp[$k];
            $purchase_rates = $purchase_rate[$k];
            $ptds = $ptd[$k];
            $ptrs = $ptr[$k];
            $ptcs = $ptc[$k];
            $ptvs = $ptv[$k];
            $ptks = $ptk[$k];
            $margins = $margin[$k];
            // $ptps = $ptp[$k];
            // $invoice_qntys = $invoice_qnty[$k];
            // $free_qntys = $free_qnty[$k];

            $flds = "batch,product_id,good_reciept_id";
            $vals = ":batch,:product_id,:good_reciept_id";

            $ex = array(
                ":batch" => $batchs,
                ":product_id" => $prod,
                ":good_reciept_id" => $savereciept
            );
            $savebatch = save("batch", $flds, $vals, $ex);

            // $f = "good_reciept_id,product_id,sku,quantity,batch,manfacturing_date,expiry_date,mrp,purchase_rate,pts,ptr,ptc,ptv,ptk,ptp,invoice_qnty,free_qnty,created_by";
            $f = "good_reciept_id,product_id,sku,quantity,batch_id,batch,manfacturing_date,expiry_date,mrp,purchase_rate,pts,ptr,ptc,ptv,ptk,margin,created_by";
            // $v =":good_reciept_id,:product_id,:sku,:quantity,:batch,:manfacturing_date,:expiry_date,:mrp,:purchase_rate,:pts,:ptr,:ptc,:ptv,:ptk,:ptp,:invoice_qnty,:free_qnty,:created_by";
            $v = ":good_reciept_id,:product_id,:sku,:quantity,:batch_id,:batch,:manfacturing_date,:expiry_date,:mrp,:purchase_rate,:pts,:ptr,:ptc,:ptv,:ptk,:margin,:created_by";
            $e = array(
                ":good_reciept_id" => $savereciept,
                ":product_id" => $prod,
                ":sku" => $skus,
                ":quantity" => $qnty,
                ":batch_id" => $savebatch,
                ":batch" => $batchs,
                ":manfacturing_date" => $manfacturing_dates,
                ":expiry_date" => $expiry_dates,
                ":mrp" => $mrps,
                ":purchase_rate" => $purchase_rates,
                ":pts" => $ptds,
                ":ptr" => $ptrs,
                ":ptc" => $ptcs,
                ":ptv" => $ptvs,
                ":ptk" => $ptks,
                // ":ptp"=>$ptps,
                // ":invoice_qnty"=>$invoice_qntys,
                // ":free_qnty"=>$free_qntys,
                ":margin" => $margins,
                ":created_by" => $user_id
            );
            $saveinstock = save("instock", $f, $v, $e);
        }
    }
}

$getsuppliers = find("all", "suppliers", "*", "where 1", array());
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    <link rel="stylesheet" href="./vendor/select2/css/select2.min.css">
    <style>
        .form-control {
            width: auto;
        }

         .select-editable {
            position:relative;
            background-color:white;
            /* border:solid grey 1px; */
            width:100px;
            height: 56px;
        }
        .select-editable select {
            position:absolute;
            top:0px;
            left:0px;
            font-size:14px;
            border:none;
            width:120px;
            border: 1px solid #f0f1f5;
            margin:0;
        }
        .select-editable input {
            position:absolute;
            top:0px;
            left:0px;
            width:80px;
            /* padding:1px; */
            font-size:12px;
            border:none;
            height: 30px;
            margin: 10px 10px;
            padding:0;
        }
        .select-editable select:focus, .select-editable input:focus {
            outline:none;
        }
    </style>

</head>

<body>
    <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
            <div class="container-fluid">
                <div class="row">

                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Goods Receipt</h4>
                            </div>
                            <div class="card-body">
                                <form action="" method="POST">
                                    <div class="row">
                                        <div class="col-3">
                                            <label for="">Gr.No.</label>
                                            <input type="text" class="form-control" readonly name="gr_no"
                                                value="<?= $gr_no ?>">
                                        </div>
                                        <div class="col-3">
                                            <label for="">Challan No.*</label>
                                            <input type="text" required name="challan_no" class="form-control">
                                        </div>
                                        <div class="col-3">
                                            <label for="">Challan Date *</label>
                                            <input type="date" required name="challan_date" class="form-control" id="">
                                        </div>

                                        <div class="col-3">
                                            <label for="">Select Supplier *</label>
                                            <select name="supplier" class="form-control" id="" required>
                                                <option value="">Select Supplier</option>
                                                <option value="VetrinaHealthcare Pvt.Ltd.">VetrinaHealthcare Pvt.Ltd.
                                                </option>
                                                <?php foreach ($getsuppliers as $k => $v) { ?>
                                                    <option value="<?= $v["supplier_id"] ?>"><?= $v["sup_name"] ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-12">
                                            <h5 class="card-title">Product Details</h5>
                                        </div>
                                    </div>
                                    <div class="row" style="overflow-x:scroll;">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Product</th>
                                                    <th>SKU</th>
                                                    <th>Quantity</th>
                                                    <th>Batch</th>
                                                    <th>Manufacturing Date </th>
                                                    <th>Expiry Date</th>
                                                    <th>MRP</th>
                                                    <th>Purchase Rate (NRV)</th>
                                                    <th>PTS</th>
                                                    <th>PTR</th>
                                                    <th>PTC</th>
                                                    <th>PTV</th>
                                                    <th>PTK</th>
                                                    <!-- <th>PTP</th> -->
                                                    <!-- <th>Margin</th> -->
                                                    <th>Add</th>
                                                </tr>
                                            </thead>
                                            <tbody id="products">
                                                <tr>
                                                    <td>
                                                        <select name="product[]" class="form-control product1 select"
                                                            id="product1" onchange="getitemdetails(this.value,'1')">
                                                            <option value="">Select Product</option>
                                                            <?php foreach ($products as $k => $v) { ?>
                                                                <option value="<?= $v["product_id"] ?>">
                                                                    <?= $v["product_name"] ?>-<?= $v["sku"] ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </td>
                                                    <td><input type="text" readonly class="form-control sku1"
                                                            name="sku[]" id="sku1"></td>
                                                    <td><input type="number" class="form-control quantity1"
                                                            name="quantity[]" id=""></td>
                                                    <!-- <td><input type="text" class="form-control batch1" name="batch[]"
                                                            id="batch"></td> -->

                                                    <td>
                                                        <div class="select-editable">
                                                            <select name="batch[]"  class="form-control" id="batch1"  onchange="this.nextElementSibling.value=this.value;setprices(this.value,'1')">
                                                                <option value="">Select Batch</option>
                                                            </select>
                                                            <input type="text" name="textbatch[]" id="textbatch1" class="form-control" value="" />
                                                        </div>                                                    
                                                    </td>
                                                    <td><input type="date" class="form-control manfacturing_date1"
                                                            name="manfacturing_date[]" id=""></td>
                                                    <td><input type="date" class="form-control expiry_date1"
                                                            name="expiry_date[]" id=""></td>
                                                    <td><input type="number" class="form-control mrp1" name="mrp[]"
                                                            id="mrp1"></td>
                                                    <td><input type="number" class="form-control purchase_rate1"
                                                            name="purchase_rate[]" id="purchase_rate1"></td>
                                                    <td><input type="number" class="form-control ptd1" name="ptd[]"
                                                            id="ptd1"></td>
                                                    <td><input type="number" class="form-control ptr1" name="ptr[]"
                                                            id="ptr1"></td>
                                                    <td><input type="number" class="form-control ptc1" name="ptc[]"
                                                            id="ptc1"></td>
                                                    <td><input type="number" class="form-control ptv1" name="ptv[]"
                                                            id="ptv1"></td>
                                                    <td><input type="number" class="form-control ptk1" name="ptk[]"
                                                            id="ptk1"></td>
                                                    <!-- <td><input type="number" class="form-control ptp1" name="ptp[]" id="ptp1"></td> -->
                                                    <!-- <td>
                                                        <input type="number" class="form-control margin1" name="margin[]" id="margin1">
                                                    </td> -->
                                                    <td><span class="btn btn-xs sharp btn-info shadow"
                                                            onclick="additeminlist()">+</span></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div class="row">
                                        <div class="col-2 mt-1">
                                            <button class="btn btn-success shadow" type="submit" name="savestock">Add to
                                                Inventory</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
    <?php include("jslink.php"); ?>

    <script src="./vendor/select2/js/select2.full.min.js"></script>

    <script>

        $(function () {
            <?php if ($saveinstock) { ?>
            swal("Inventory Added", "Stock added to inventory", "success");
            <?php } ?>

        });

        $(".select").select2();

        // $(document).ready(function(){
        //     <?php //if($savereciept) { ?>
        //         swal("Added to Inventory","selected products added to inventory","success");    
        //     <?php //} ?>
        // })

        function getitemdetails(product_id, str) {
            // alert(product_id+" , "+str);
            $("#batch"+str).find("option").remove();
            $.ajax({
                method: "POST",
                url: "ajax/getitemdetails.php",
                data: { 
                        action : 'getbatchSku',
                        product_id: product_id
                      }
            })
                .done(function (response) {   
                    // alert("msg : "+response);
                    var data = JSON.parse(response);
                    var length = Object.keys(data[1]).length
                    // alert(data[1][1]["id"]+"--"+data[1][1]["name"]);
                    $("#sku"+str).val(data[0]["sku"]);
                    var appenddata = '';
                    $("#batch"+str).append('<option value="">Select Batch</option>');
                    for (var i = 1; i <= length; i++) 
                    {
                        // alert("i: "+i+" batchId: "+data[1][i]["id"]+" batch: "+data[1][i]["name"]);                        
                        appenddata = '<option value="'+data[1][i]["name"]+'">'+data[1][i]["name"]+'</option>';
                        $("#batch"+str).append(appenddata);
                    }
                     
                    // var ptr = data['ptr'];
                    // var mrp = data['mrp'];
                    // var gst = (ptr+(ptr * 0.18))/mrp;
                    // var amt = mrp-gst;
                    // var margin = Math.round(amt*100);
                    // $("#margin"+str).val(margin);
                });
        }

        function additeminlist() {
            $.ajax({
                method: "POST",
                url: "ajax/additemrow.php",
                data: {}
            })
                .done(function (msg) {
                    $("#products").append(msg);
                });
        }

        function calculatemargin(ptr, str) {
            var mrp = $("#mrp" + str).val();
            var gst = Math.round(ptr * 18 / 100);
            // console.log(gst);
            var margin = Math.round(mrp - (ptr + gst) / mrp) * 100;
            $("#margin" + str).val(margin);
        }

        function removeitemfromlist(str) {
            $("#newrow" + str).remove();
        }

        // $( "#batch" ).on( "change", function() {
        function setprices(batch, str) {
            // alert( "Handler for `change` called." +batch+" id: "+"#batch"+str);
            // var selectedBatch = $(this).children("option:selected").val();
            // var selectedBatch = $(this).children("option:selected").html();
            var selectedBatch = batch;
            var pid = $( "#product"+str ).val();
            // alert("selected product : "+pid);
            var sku = $( "#sku"+str ).val();
            // alert ("You have selected the batch - " + selectedBatch);
            $.ajax({ 
                url: "ajax/getitemdetails.php",
                type: "POST",
                data: { 
                    action : 'getprices',
                    pid : pid,
                    sku : sku,
                    batch : selectedBatch
                },
                success: function(response) {
                    // alert(response);
                    data = JSON.parse(response);
                    // alert(data);
                    $("#purchase_rate"+str).val(data['nrv']);
                    $("#mrp"+str).val(data['mrp']);
                    $("#ptd"+str).val(data['pts']);
                    $("#ptr"+str).val(data['ptr']);
                    $("#ptc"+str).val(data['ptc']);
                    $("#ptv"+str).val(data['ptv']);
                    $("#ptk"+str).val(data['ptk']);
                }
            });
        } 
        // } );


    </script>

</body>

</html>
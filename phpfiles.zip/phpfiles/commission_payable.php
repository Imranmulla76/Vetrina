<?php 
    include("init.php");
    if(isset($_POST["savetds"]))
    {
        $vetzone_id=$_POST["vetzone_id"];
    //  $product_id = $_POST["product_id"];
        $totalsale = $_POST["totalsale"];
        $totalcomissonamt = $_POST["totalcomissonamt"];
        $tds = $_POST["tds"];   
        $tdsamt=$_POST["tdsamt"];
        $payable=$_POST["comsnamt"];
        $status=$_POST["status"];
        $currentdate=date('Y-m-d H:i:s');        
        $fields="comission_meta_id,vetzone_id,total_sale_amt,total_comission_amt,tds,tds_amount,payble,status,created_at";
        $value=":comission_meta_id,:vetzone_id,:total_sale_amt,:total_comission_amt,:tds,:tds_amount,:payble,:status,:created_at";
        $table="monthly_comission_payable";      
        foreach($vetzone_id as $k=>$val)
        {
            $v_id = $vetzone_id[$k];
            $ts = $totalsale[$k];
            $tc = $totalcomissonamt[$k];
            $tdss = $tds[$k];
            $tdsam=$tdsamt[$k];
            $totalpayble = $payable[$k];
            $st = $status[$k];          
            $exe=array(":comission_meta_id"=>$v_id,":vetzone_id"=>$v_id,":total_sale_amt"=>$ts,":total_comission_amt"=>$tc,":tds"=>$tdss,":tds_amount"=>$tdsam,":payble"=>$totalpayble,":status"=>$st,":created_at"=>$currentdate);
       
            $savetds=save($table,$fields,$value,$exe);
         
    
       }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        
         <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                           
                            <div class="card-header">
                                <b class="card-title">Monthly Comission Payable</b>
                            </div>
                            <div class="card-body">
                           
                              
                                   
                                    <div class="col-sm-5">
                                        <label for="">Month</label>
                                        <select id='Month' class="form-control" name="Month" >
                                                <option value=''>--Select Month--</option>
                                                <option value='1'>Janaury</option>
                                                <option value='2'>February</option>
                                                <option value='3'>March</option>
                                                <option value='4'>April</option>
                                                <option value='5'>May</option>
                                                <option value='6'>June</option>
                                                <option value='7'>July</option>
                                                <option value='8'>August</option>
                                                <option value='9'>September</option>
                                                <option value='10'>October</option>
                                                <option value='11'>November</option>
                                                <option value='12'>December</option>
                                        </select> 
                                    </div>
                                    <!-- <div class="col-sm-5">
                                        <label for="">To</label>
                                        <input type="date" name="todate" id="todate" class="form-control" />
                                    </div> -->
                                    <div class="col-sm-5">
                                    <button class="btn btn-md btn-info" onclick="TDS();" >Click to Generate Report</button>
                                </div>
                                </div>
                               
                                <form action="" method="POST">
                                <div class="table-responsive">
                                     <table id="example3" class="display min-w850">
                                        
                                     </table>
                                  
        
                             </div>
                             <div class="row">
                                        <div class="col-2 mt-1">
                                            <button class="btn btn-success shadow" type="submit" name="savetds">Save TDS</button>
                                        </div>
                                    </div>
                           
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>                 

        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
        <script>
       
       //today = new Date().toISOString().split('T')[0];

       function TDS()
       {
        
         
           var fromdate=$('#Month').val();
          //var todate=$('#todate').val();
           console.log("from date:"+ fromdate);
           //console.log("to date:" + todate);
          
        //    if(fromdate > today || todate > today)
        //      {
        //         alert("Invalid Date is Selected");
        //        swal("Wrong!","Invalid Date is Selected","error"); 
        //     }
            $.ajax({
                    url:"/vscm/ajax/vetZone_TDS.php",
                    type:"POST",
                    data:{
                       
                       action:'displayreport',                       
                       fromdate:fromdate,
                     //  todate:todate,
                     
                   },
                }).done(function(response){
                    $("#example3").html(response);
                });
        }          

   function cal(rownum)
    {   
        var totalamt=$("#totalcomissonamt"+rownum).val();
        var txtVal = $("#tds"+rownum).val();
        var tds=totalamt*(txtVal/100);
        
       // var tdsamt=tds.toFixed(2);;
       var tdsamt=Math.round(tds);
       var payable=Math.round(totalamt-tds);
    
        //alert(comissionamt);
        $("#tdsamt"+rownum).val(tdsamt);
        $("#comsnamt"+rownum).val(payable);
    
    }

   </script>

</body>
</html>
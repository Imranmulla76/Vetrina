<?php 

//total target
$table = "target_table t, target_meta tm";
$admin_id = $_SESSION["user_id"];
$gettarget = find("first", $table, "round(sum(tm.value), 2) target", "where t.target_id = tm.target_id and t.user_id = $admin_id", array());
if($gettarget['target'] > 0)
    $target = $gettarget['target'];
else
    $target = 0;

//total primary Sale
if(date("m") > 3)
{
    $fyear = date("Y").'/04/01  - '.(date("Y")+1).'/03/31';
    $from_dt = date("Y").'-04-01';
    $to_dt = (date("Y")+1).'-03-31';
}
else
{
    $from_dt = (date("Y")-1).'-04-01';
    $to_dt = date("Y").'-03-31';
}
$getCustomers = hierarchy($admin_id, "ASM");
$users = array();
foreach($getCustomers as $item)
{
    $users[] = $item['customer_id'];
}
$users = join(', ', $users);

$table = "order_table_product otp, placeorder p";
$where = "where p.user_id in ($users) and otp.order_id = p.stockiest_order_id and otp.user_id = p.user_id and otp.created_at between '$from_dt' and '$to_dt'";
$result = find("first", $table, "round(sum(otp.rate * otp.quantity), 2) saleValue", $where, array());

//Pending Sale
if($result['saleValue'] > $gettarget['target'])
{
    $pending = 0;
    $pending.="/-";
}
else
{
    $pending = $gettarget['target'] - $result['saleValue'];
    $pending.="/-";
}

//Achievement
if($gettarget['target'] > 0)
    $achievement = ($result['saleValue'] / $gettarget['target']) * 100 ;
else
    $achievement = 0;

?>

<div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				
                <div class="row">
					<div class="col-xl-12 col-xxl-12">
						<div class="row">
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-success mr-md-4 mr-3">
												<img src="images/target.png" alt="" width="40" height="40">
											</span>
											<div class="media-body">
												<p class="fs-14 mb-2">Target</p>
												<span class="title text-black font-w600">Rs. <?=$target;?>/-</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-success"></div>
								</div>
							</div>
							
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-secondary  mr-md-4 mr-3">
												<img src="images/badge.png" alt="" width="40" height="40">
											</span>
											<div class="media-body">
												<p class="fs-14 mb-2">Achievement</p>
												<span class="title text-black font-w600"><?=round($achievement, 2)?>%</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-secondary" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-secondary"></div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-danger mr-md-4 mr-3">
												<img src="images/commission.png" alt="" width="40" height="40">
											</span>
											<div class="media-body">
												<p class="fs-14 mb-2">Sale</p>
												<span class="title text-black font-w600">Rs. <?=$result['saleValue'];?>/-</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-danger"></div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-warning  mr-md-4 mr-3">
												<img src="images/salary.png" alt="" width="40" height="40">
											</span>
											<div class="media-body">
												<p class="fs-14 mb-2">Balance</p>
												<span class="title text-black font-w600">Rs. <?=$pending;?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-warning" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-warning"></div>
								</div>
							</div>
						</div>
					</div>
				
				</div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-info">
                                <h4 class="card-title">Head quarter wise new Orders</h4>
                            </div>
                            <div class="card-body">
                                <!-- <form action="" method="POST"> -->
                                    <div class="row">
                                        <div class="col-3">
                                            <label for="">From</label>
                                            <input type="date" name="from" id="from_date" class="form-control">
                                        </div>
                                        <div class="col-3">
                                            <label for="">To</label>
                                            <input type="date" name="to" id="to_date" class="form-control">
                                        </div>
                                        <div class="col-2">
                                            <button type="submit" class="btn btn-info btn-md mt-4" name="getorders" onclick="getreport()">Get Orders</button>
                                        </div>
                                    </div>
                                <!-- </form> -->
                                <br>
                                <br>
                                <div class="table-responsive">
                                    <table bordered id="orders" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Head Quarter ZSM</th>
                                                <th>Order Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-success">
                                <h4 class="card-title">Party New Orders</h4>
                            </div>
                            <div class="card-body">
                                 <div class="table-responsive">
                                    <table bordered id="hqWiseOrders" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Party Name</th>
                                                <th>Order Date</th>
                                                <th>Order Amount</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<script>

var from_dt;
var to_dt;
today = new Date().toISOString().split('T')[0];

$(function() {
	console.log( "ready!" );
});


function getreport()
{
    from_dt = $('#from_date').val(); //YYYY-MM-DD
    to_dt = $('#to_date').val();    

    // alert("from date : "+from_dt);
    console.log("to date : "+to_dt);
    console.log("today : "+today);

    if(from_dt > today || to_dt > today)
    {
        //alert("Invalid Date is Selected");
        swal("Wrong!","Invalid Date is Selected","error"); 
    }
    else{
        $.ajax({ 
            url: "ajax/get_zsm_dashboard.php",
            type: "POST",
            data: {
                action : 'getOrders',
                from_dt : from_dt,
                to_dt : to_dt,
            },
        }).done(function(response){
            // alert('success');
			$("#orders").html(response);
        });
    } 
	
	$("#orders").DataTable({
		dom: 'Blfrtip',
		buttons: [
        'copyHtml5', 'excelHtml5', 'pdfHtml5'
    ],
	});

}//End of getreport function


function Open(hq_id) {

	$.ajax ({
		url: "ajax/get_zsm_dashboard.php",
		method: "POST",
		data: {
			action : 'orderDetails',
			hq_id : hq_id,
			}
	}).done(function(response){
		console.log(response);
		$("#hqWiseOrders").html(response);
	});

	$("#hqWiseOrders").DataTable({
       dom: 'lfrtip',
    });
	
}

</script>
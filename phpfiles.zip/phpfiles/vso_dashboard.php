<?php 

	$table = "target_table as tt inner join target_meta as tm on tt.target_id=tm.target_id";
	$admin_id = $_SESSION["user_id"];
	echo $admin_id;
	$gettarget_details = find("all",$table,"*,sum(value) as target","where tt.user_id='$admin_id'",array());
	// print_r($gettarget_details);

	//total target
	$table = "target_table t, target_meta tm";
	$admin_id = $_SESSION["user_id"];
	$gettarget = find("first", $table, "round(sum(tm.value), 2) target,file as doc", "where t.target_id = tm.target_id and t.user_id = $admin_id", array());
	// print_r($gettarget);exit;
	if($gettarget['target'] > 0)
		$target = $gettarget['target'];
	else
		$target = 0;

	//total primary Sale
	if(date("m") > 3)
	{
		$fyear = date("Y").'/04/01  - '.(date("Y")+1).'/03/31';
		$from_dt = date("Y").'-04-01';
		$to_dt = (date("Y")+1).'-03-31';
	}
	else
	{
		$from_dt = (date("Y")-1).'-04-01';
		$to_dt = date("Y").'-03-31';
	}

	$getCustomers = hierarchy($admin_id, "VSO");
	echo "in vso Dashboard";
	print_r($getCustomers);
	if($getCustomers != 'FLAG')
	{    
		$users = join(', ', $getCustomers);
		echo "users : ".$users;

		$table = "order_table_product otp, placeorder p";
		$where = "where p.user_id in ($users) and otp.order_id = p.stockiest_order_id and otp.user_id = p.user_id and otp.created_at between '$from_dt' and '$to_dt'";
		$result = find("first", $table, "round(sum(otp.rate * otp.quantity), 2) saleValue", $where, array());
	}
	
	//Pending Sale
	if($result['saleValue'] > $target)
	{
		$pending = 0;
		$pending.="/-";
	}
	else
	{
		$pending = $target - $result['saleValue'];
		$pending.="/-";
	}

	//Achievement
	if($gettarget['target'] > 0)
		$achievement = ($result['saleValue'] / $gettarget['target']) * 100 ;
	else
		$achievement = 0;
	

	$user_id = $_SESSION['user_id'];
	//get headquarter of logged in VSO
	//select hq_id from admin_hq_div where admin_id = $user_id;
	$gethq = find("first", "admin_hq_div", "hq_id", "where admin_id = $user_id", array());
	$hq_id = $gethq['hq_id'];

    $getQryResult1 = find("all", "order_table_product otp, customer c", "otp.user_role, otp.created_at, sum(otp.rate * otp.quantity) amount, otp.status, c.customer_id, c.name", "where otp.user_id in (select customer_id from customer_hq_div where hq_id = $hq_id) and otp.user_role <> 'VetZone' and c.customer_id = otp.user_id group by otp.order_id order by customer_id", array());

    $getQryResult2 = find("all", "order_table_product otp, vetzone v", "otp.user_role, otp.created_at, sum(otp.rate * otp.quantity) amount, otp.status, v.vetzone_id, v.name", "where otp.user_id in (select vetzone_id from vetzone_hq_div where hq_id = $hq_id) and otp.user_role = 'VetZone' and v.vetzone_id = otp.user_id group by otp.order_id order by vetzone_id", array());

    $finaldetails = array_merge($getQryResult1, $getQryResult2);
?>
<div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				
                <div class="row">
					<div class="col-xl-12 col-xxl-12">
						<div class="row">
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-success mr-md-4 mr-3">
												<img src="images/target.png" alt="" width="40" height="40">
											</span>
											<a href="import-xlsx/uploads/<?=$gettarget["doc"]?>" target="_blank">
											<div class="media-body">
												<p class="fs-14 mb-2">Target</p>
												<span class="title text-black font-w600">Rs. <?=$target;?>/-</span>
											</div>
											</a>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-success" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-success"></div>
								</div>
							</div>
							
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-secondary  mr-md-4 mr-3">
												<img src="images/badge.png" alt="" width="40" height="40">
											</span>
											<div class="media-body">
												<p class="fs-14 mb-2">Achievement</p>
												<span class="title text-black font-w600"><?=round($achievement, 2)?>%</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-secondary" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-secondary"></div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-danger mr-md-4 mr-3">
												<img src="images/commission.png" alt="" width="40" height="40">
											</span>
											<div class="media-body">
												<p class="fs-14 mb-2">Sale</p>
												<span class="title text-black font-w600">Rs. <?=$result['saleValue'];?>/-</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-danger" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-danger"></div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-warning  mr-md-4 mr-3">
												<img src="images/salary.png" alt="" width="40" height="40">
											</span>
											<div class="media-body">
												<p class="fs-14 mb-2">Pending</p>
												<span class="title text-black font-w600">Rs. <?=$pending?></span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-warning" style="width: 100%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-warning"></div>
								</div>
							</div>
						</div>
					</div>
				
				</div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Party New Orders</h4>
                            </div>
                            <div class="card-body">
                                 <div class="table-responsive">
                                    <table bordered id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Party Name</th>
                                                <th>Order Date</th>
                                                <th>Order Amount</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php 
											$i = 1;
											foreach($finaldetails as $item)
											{ 
										?>
                                            <tr>
											<td><?=$i?></td>
											<td><?=$item['name']?></td>
											<td><?=$item['created_at']?></td>
											<td><?=$item['amount']?></td>
											<td><?=$item['status']?></td>
                                            </tr>
										<?php 
											$i++;
											} //end of foreach
										?>
                                        </tbody>
										
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


<script>

$(function() {
	console.log( "ready!" );
	
});

$("#partyOrders").DataTable({
       dom: 'lfrtip',
    });
	
</script>
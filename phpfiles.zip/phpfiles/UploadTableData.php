<?php include("init.php");
$response = "";
$response_status = "none";
$prospectmsg = 0;
$FailFile = 0;

if (isset($_POST["upload"])) {
    $file_name = $_FILES["file"]["name"][0];
    $fileName = substr($file_name, 0, strrpos($file_name, "."));
    $file_type = $_FILES["file"]["type"][0];

    if ($file_type == "text/csv") {
        $csv = $_FILES["file"]["tmp_name"][0];
        $file = fopen($csv, "r");
        $firstLine = false;
        $data = fgetcsv($file);

        $fields = implode(", ",$data);
        $values = ':'.implode(", :",$data);

        $temp = explode(", ", $values);
        $d = $data;
        



        while (!feof($file)) {
            $data = fgetcsv($file);
            if (!$firstLine) { //Skippin 1st row
                if ($data) {
                    $num = count($data);
                    if ($num > 1) { // added check for empty row

                        $i = 0;                        
                        $exe = array();
                        foreach($temp as $key => $val)
                        {
                            // echo $d[$i];
                            $$d[$i] = str_replace("'", "", $data[$i]);
                            // echo $$d[$i];
                            // $c[] = '"'.$val.'" => '.$$d[$i];
                            $exe[$val] = $$d[$i];
                            $i++;
                        }
                        
                        /*$fields = "hq_id, hq_name, base_town, geo_location";
                        $values = ":hq_id, :hq_name, :base_town, :geo_location";
                        $exe = array(":hq_id" => $hq_id , ":hq_name" => $hq_name, ":base_town" => $base_town, ":geo_location" => $geo_location);
                        $savehq = save("headquarters", $fields, $values, $exe); */
                        $saverows = save($fileName, $fields, $values, $exe);

                    }
                }
            } else {
                $firstLine = false;
            }
        }
        fclose($file);
       
    } else {
        $FailFile = 1;
    }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>CRM || TDTL || Upload Prospect</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>

<body>
    

    <div id="main-wrapper">

        
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-6 col-xxl-12">
                        <div class="row">
                            <div class="col-sm-8">
                                <div class="card avtivity-card">
                                    <div class="card-header">
                                        <div class="card-title">
                                            Upload Prospect
                                        </div>
                                    </div>
                                    <div class="card-body">


                                        <form action="" method="POST" enctype="multipart/form-data">


                                            <!-- <div class="form-group">
                                                <label class="text ">File:</label>
                                            </div> -->
                                            <div class="col-sm-14">
                                                <div class="row">
                                                    <div class="form-group">
                                                        <label style="color:black;" class="text ">Choose .CSV File</label>
                                                    </div>
                                                    <div class="form-group">
                                                        <button type="button" style="margin-top: -18px;
                                                            margin-left: 300px;" class="btn btn-outline-primary"
                                                            onclick="location.href='download.php?file=dummy.csv'">Download
                                                            Sample CSV</button>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <input style="color:black;" type="file" name="file[]" class="form-control input-default "
                                                    placeholder="Browse your File" required>
                                            </div>

                                            <div class="form-group">
                                                <input type="submit" name="upload" class="btn btn-primary mb-2 "
                                                    value="Import Prospect">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            


                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>

    <?php include("jslink.php"); ?>
   

    
</body>

</html>
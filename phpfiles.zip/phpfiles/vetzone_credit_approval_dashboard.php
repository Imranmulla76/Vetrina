<?php 

include("init.php");

$user_id = $_SESSION['user_id'];

$type = $_SESSION['type'];


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    
</head>
<body>
   <?php include("preloader.php"); ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        
        <div class="content-body">
            <!-- row -->
            <div class="container-fluid">        
                <div class="row">
                    <div class="col-xl-12 col-xxl-12">
                        <div class="card">
                            <div class="card-body">

                                <div class="table-responsive">
                                    <table id="cnreport" class="display min-w850">

                                        <thead>                                        
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>return_id</th>
                                                <th>vetzone Id</th>
                                                <th>Name of VetZOne</th>
                                                <th>Total Outstanding</th>
                                                <th>Due Outstanding</th>
                                                <th>Remark</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>                                      
                                            </tr>                                        
                                        </tbody>

                                        <tfoot>
                                            <tr>                                            
                                            </tr>
                                        </tfoot>

                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
</body>
</html> 


<script>

$(document).ready(function () {
    getreport();
    /* alert("function called");
    $.ajax({ 
        url: "ajax/get_cnreport.php",
        type: "POST",
        data: { 
            action : 'getcnreport',
        },
        success: function(data) {
            alert(data);
            }
    }); */
});

function getreport()
{  
    carttable = $("#cnreport").DataTable({
        responsive: true,
        dom: 'lfrtip',

        "ajax":
			  {
			  	'url' : 'ajax/get_creditNote_approval.php',
				'type': 'POST',
				'data': {
						 action : 'getCreditApproved',
                         type : 'vetzone',
						},
				
			  },        

        columnDefs: [
            {
                render: function (data, type, row) {
                    // return '<a class = "nav-danger" onclick = "removeproduct('+row[1]+');" id = "remove"> - Remove </a>';
                    return '<select name="action" id="action" onchange="getValue('+row[1]+', this.value);"> <option>Select</option> <option value="Y">Approve</option> <option value="N">Decline</option></select>'
                },
                targets: -1,
            },

            {
                render: function (data, type, row) {
                    return '<input type="text" id="remark" onchange="getRemark('+row[1]+', this.value);">'
                },
                targets: -2,
            },

            { 
                visible: false, 
                targets: [1,2] 
            },
        ],

        destroy : true,
        
    });    

    // carttable.destroy();

}

function getValue(returnid, act)
{
    // alert("function called " + returnid + "value : " + act);
    $.ajax({ 
        url: "ajax/get_creditNote_approval.php",
        type: "POST",
        data: { 
            action : 'approval',
            returnid : returnid,
            act : act,
        },
        success: function(data) {
            // alert(data);
            }
    });
}

function getRemark(returnid, remark)
{
    // alert("function called " + returnid + "value : " + remark);
    $.ajax({ 
        url: "ajax/get_creditNote_approval.php",
        type: "POST",
        data: { 
            action : 'setremark',
            returnid : returnid,
            remark : remark,
        },
        success: function(data) {
            // alert(data);
            }
    });
}

</script>
	<script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="./vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>
    <script src="./vendor/peity/jquery.peity.min.js"></script>
	<script src="./vendor/owl-carousel/owl.carousel.js"></script>
	<script src="./vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="./js/plugins-init/datatables.init.js"></script>
	
	<!-- Jquery cdn and databales Added on 19-6-23 -->
	
	<!-- <script type="text/javascript" src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script> -->
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script>
	<!-- Buttons Excel JS Added on 19-6-23 -->
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.flash.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.5.0/jszip.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.70/pdfmake.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.70/vfs_fonts.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
	<!-- Toastr -->
 
	<script src="./vendor/sweetalert2/dist/sweetalert2.min.js"></script>
    <script src="./js/plugins-init/sweetalert.init.js"></script>


	<!-- Functions for global use -->
	<script type="text/javascript">

		 $(function(){
			cartsummery();
			invoicesummary();
			viewCustomerInvoice();
			viewrequisition();
			//notifysummery();
			/* setInterval(function() {
				notifysummery();
			}, 2000); */
		 });

		 function notifysummery() {
			$.ajax({
					method: "POST",
					url: "ajax/notifysummery.php",
					data: {}
				})
				.done(function(response) {
					if (response == "shownotify") {
						$("#notifybtn").click();
					}
				});
		}

		function getnotification() {
			$.ajax({
					method: "POST",
					url: "ajax/notification.php",
					data: {}
				})
				.done(function(response) {
					$("#notifyajax").html(response);
				});
		}


		function isclicknow(notifiid) {
			var nowrowofnotify = $("#notifyrowthis" + notifiid);
			$("#notifyrowthis" + notifiid).css("background", "white");
			$.ajax({
					method: "POST",
					url: "ajax/clicktoviewnofy.php",
					data: {
						notifiid: notifiid
					}
				})
				.done(function(response) {
					nowrowofnotify.remove();
				});
		}

		function cartsummery()
            {
                $.ajax({
					method: "POST",
					url: "ajax/cartsummery.php",
					data: {}
				})
				.done(function(response) {
					$("#cartsummery").html(response);
				});
            }

		function invoicesummary()
            {
                $.ajax({
					method: "POST",
					url: "ajax/invoicesummery.php",
					data: {}
				})
				.done(function(response) {
					$("#invoice").html(response);
				});
            }	

		function viewcart() {
			//$("#cart").modal('show');
			$.ajax({
					method: "POST",
					url: "ajax/viewcart.php",
					data: {}
				})
				.done(function(response) {
					$("#viewcart").html(response);
					$("#viewcarttable").DataTable({
						responsive: true,
						dom: 'lfrtip',
					});
				});
		}

		function viewCustomerInvoice() {
			$.ajax({
					method: "POST",
					url: "ajax/viewcustomer_invoice.php",
					data: {}
				})
				.done(function(response) {
					$("#invoice").html(response);
					//$("#viewcart").html(response);
					$("#invoicetable").DataTable({
						responsive: true,
						dom: 'lfrtip',
					});
				});
		}

		// function deletecart(productid,callfrom,orderid) {
			
		// 	$.ajax({
		// 			method: "POST",
		// 			url: "ajax/deletecart.php",
		// 			data: {
		// 				productid:productid,
		// 				orderid:orderid
		// 				callfrom:callfrom
		// 			},
		// 			success: function(response) {
		// 			viewcart();
		// 			cartsummery();
		// 			viewCustomerInvoice();
		// 		}
		// 		});
		// }

		function deletecart(productid) {
			
			$.ajax({
					method: "POST",
					url: "ajax/deletecart.php",
					data: {
						productid:productid,
					},
					success: function(response) {
					viewcart();
					cartsummery();
					viewCustomerInvoice();
				}
				});
		}

		function deletecartpos(productid,callfrom,orderid,batch) {
			
			$.ajax({
					method: "POST",
					url: "ajax/deletecart.php",
					data: {
						productid:productid,
						callfrom:callfrom,
						orderid:orderid,
						batch:batch
					},
					success: function(response) {
					viewcart();
					cartsummery();
					viewCustomerInvoice();
				}
				});
		}

		function paymentForm(payment_mode)
		{
			if(payment_mode=="Advanced")
			{
				$("#paymentform").show("toggle");
			}
			else if(payment_mode=="Credit")
			{
				$("#paymentform").hide();
			}
		}
		 
	</script>
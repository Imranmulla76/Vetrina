<?php include("init.php");

    $admins = find("all","admin","*","where 1",array());

    if(isset($_POST["send_notification"]))
    {

        $notification_text = $_POST["notification_text"];
        $to = $_POST["to"];

        $send_form_id = "1";
        $send_to_id =  $to;
        $notify_text = $notification_text;
        notify($send_form_id,$send_to_id,$notify_text);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="./vendor/select2/css/select2.min.css">
    <title>SCM | Vetrina</title>

    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
            <div class="content-body">
                <div class="container-fluid">
                    <div class="row">
                        
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header bg-info shadow">
                                    <h4 class="card-title">Send Notification</h4>
                                </div> 

                                <div class="card-body">
                                    <form method="POST" action="">

                                        <label for="">Select Employee/User </label>
                                        <select name="to" class="form-control" id="single-select">
                                            <option value="">Select User</option>
                                            <?php foreach($admins as $key=>$val) { ?>
                                                <option value="<?=$val["admin_id"]?>"><?=$val["username"]?></option>    
                                            <?php } ?>
                                        </select>

                                        <br>
                                        <br>

                                        <label for="">Notification Text</label>
                                        <textarea name="notification_text" class="form-control" cols="30" rows="10"></textarea>

                                        <br>
                                        <br>

                                        <button type="submit" class="btn btn-info" name="send_notification"><i class="fa fa-paper-plane mr-1"></i>Send Notification</button>

                                    </form>
                                </div>

                            </div> 
                        </div> 
                    </div> 
                </div> 
            </div> 
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
         <script src="./vendor/select2/js/select2.full.min.js"></script>
        
        <script>

            $("#single-select").select2();
        </script>
</body>
</html>
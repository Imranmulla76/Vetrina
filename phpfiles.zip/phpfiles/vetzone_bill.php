<?php 
  include("init.php");
    $vetzone_id = $_SESSION["user_id"];
    $cust_order_id = $_GET["order_id"];

    $table = "customer_order_table_product as cotp inner join product as p on cotp.product_id=p.product_id";
    $vetzone_details = find("first","vetzone","*","where vetzone_id='$vetzone_id'",array());
    $getorder_details = find("all",$table,"*","where 1",array());
     if(date("m") > 3)
	{
		$fyear = date("y").'-'.(date("y")+1);
	}
	else
	{
		$fyear = (date("y")-1).'-'.date("y");
	}
?>
<!DOCTYPE html>
<html>

<head>
  <title>VetZone Bill</title>
  <!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
      margin: 0;
      padding: 0;
    }

    .bill {
      width: 217.32px;
      margin: 50px auto;
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    }

    h3 {
      text-align: center;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th,
    td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #f2f2f2;
    }

    tr:last-child td {
      font-weight: bold;
    }

    .total-label {
      text-align: left;
    }

    .total {
      font-size: 1.2em;
      text-align: left;
    }
  </style>
</head>

<body>
    <div id="temp-target">
  <div class="bill">
    <h3><?=$vetzone_details["name"]?></h3>
    <P style="text-align: center;">Phone: <?=$vetzone_details["mobile_number"]?></P>

    <h3>SalesBill</h3>
    <p>Date: 12-Apr-2023 07;04;44 pm</p>
    <p>Invoice No:VZ<?=$fyear?>/<?=$cust_order_id?></p>
    <p>Customer: </p>
    <table>
      <!-- <tr>
        <th>Description</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Total</th>
      </tr> -->
      <tr>
        <td>ITEM HSN</td>
        <td>QTY</td>
        <td>RATE GST%</td>
        <td>AMT CESS%</td>
      </tr>
      <tr>
        <td>BETAFERT 500GM</td>
        <td>320</td>
        <td>640</td>
        <td>$240</td>
      </tr>
      <tr>
        <td>Total Qty:2.00</td>
        <td>Net:640.00</td>

      </tr>
      <tr>
        <td colspan="3" class="total-label">Total: $665</td>

      </tr>

    </table>
    <p style="text-align: center;">***Vetrina***</p>
    <p style="text-align: center;">Software by The DataTech Labs</p>
  </div>
</div>
<button class="btn btn-primary" onclick="converHTMLFileToPDF()">Print Bill</button>

    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.3.1/jspdf.umd.min.js"></script>
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.0/html2canvas.min.js" integrity="sha512-UcDEnmFoMh0dYHu0wGsf5SKB7z7i5j3GuXHCnb3i4s44hfctoLihr896bxM0zL7jGkcHQXXrJsFIL62ehtd6yQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>

        function converHTMLFileToPDF() 
        {
            const { jsPDF } = window.jspdf;
            var doc = new jsPDF('l', 'mm', [1800 , 1210]);

            var pdfjs = document.querySelector('#temp-target');

            // Convert HTML to PDF in JavaScript
            doc.html(pdfjs, {
                callback: function(doc) {
                    doc.save("Supply Bill.pdf");
                },
                x: 1,
                y: 2
            });
        }

  </script>
</body>

</html>
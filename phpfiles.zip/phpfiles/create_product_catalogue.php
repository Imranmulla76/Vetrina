    <?php include("init.php");
            //check_login();

        if(isset($_POST["save_pricing"]))
        {
            $division = $_POST["division"];
            $filename = $_FILES["file"]["name"];
            $filetempname = $_FILES['file']['tmp_name'];

            $fields = "division_id,file,created_by";
            $values = ":division_id,:file,:created_by";
            $exe = array(":division_id"=>$division,":file"=>$filename,":created_by"=>$_SESSION["user_id"]);
            $save = save("product_catalogue",$fields,$values,$exe);

            if($save)
            {
                 move_uploaded_file($filetempname, "product_catalogue/" . $filename);
            } 
        }

        if(isset($_POST["delete"]))
        {
            $product_catalogue_id = $_POST["product_catalogue_id"];
            $where = "where product_catalogue_id='$product_catalogue_id'";
            $exe = array();
            $delete_structure = delete("product_catalogue",$where,$exe);
        }

        $division = find("all","divisions","*","where 1",array());
        $findpricingstructure = find("all","product_catalogue as ps inner join divisions as d on ps.division_id=d.division_id","*","where 1",array());

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>SCM | Vetrina</title>
        <!-- Favicon icon -->
        <?php include("csslink.php"); ?>
    </head>
    <body>
    <?php include("preloader.php") ?>

        <div id="main-wrapper">
            <?php include("navbar.php"); ?>
            <?php include("chatbox.php"); ?>		
            <?php include("header.php"); ?>
            <?php include("sidebar.php"); ?>
            <!-----maincontent start----->
            <div class="content-body">
                <!-- row -->
                <div class="container-fluid">
                    <div class="row">
                        <button class="btn btn-primary" data-target=".bd-example-modal-sm" data-toggle="modal">+ Add Product Catalogue</button>
                    </div>

                    
                    <div class="row mt-3">
                        <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Product Catalogue</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table  id="example3" class="display min-w850">
                                    <thead>
                                        <tr>
                                            <th>SR No.</th>
                                            <th>Division</th>
                                            <th>File</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php //print_r($finddesignations); ?>
                                        <?php $i=0; foreach($findpricingstructure as $k=>$v) { $i++;?>
                                        <tr>
                                            <td><?=$i;?></td>
                                            <td><?=$v["division_name"]?></td>
                                            <td><a href="product_catalogue/<?php echo $v["file"] ?>">View File</a></td>
                                            <td>
                                                <div class="d-flex">
                                                    <!-- <a href="#" class="btn btn-primary shadow btn-xs sharp mr-1"><i class="fa fa-pencil"></i></a> -->
                                                    <form action="" method="POST">
                                                        <input type="text" hidden name="product_catalogue_id" value="<?=$v["product_catalogue_id"]?>" id="">
                                                        <button type="submit" name="delete" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></button>
                                                    </form> 
                                                </div>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                    </table>
                                </div>
                            
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
            
            <!-------main content end----->
            <?php include("footer.php"); ?>
        </div>


        <!-- Create Modal -->
    <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Product Catalogue</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    
                        <label for="">Select Division</label>
                        <select name="division" id="" class="form-control">
                                <option value="">Select division</option>
                                <?php foreach($division as $k=>$v) { ?>
                                    <option value="<?=$v["division_id"]?>"><?=$v["division_name"]?></option>
                                <?php } ?>
                        </select>
                        <br>
                        <label for="">Upload File</label>
                       <input type="file" name="file" accept="application/pdf" class="form-control" id="">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="save_pricing">Save Product Catalogue</button>
                </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Create Modal -->


            <?php include("jslink.php"); ?>
        
    </body>
    </html>
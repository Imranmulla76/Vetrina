<?php include("init.php");
        //check_login();
    $user_id = $_SESSION['user_id'];
    $findnotify = find("all","Notification","*","where its_click = 'N' and send_to_id = '$user_id' order by notify_id desc ",array());
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                            <?php if(!$findnotify)
                                { ?>
                                     <div class="row">
                                         <div class="col-12">
                                             <div class="card">
                                                <div class="card-body">
                                                        <label class="text text-danger">Sorry!, No New Notifications yet.</label>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>                       
                            <?php } else {

                            foreach($findnotify as $key => $val)
                                {
                                    $notifiid = $val["notify_id"];
                                    $setfiled= "its_view=:its_view";
                                    $setar= array(":its_view"=>"Y");
                                    $wh= "where  send_to_id = '$user_id'";
                                    $its_view_class="";
                                    if($val["its_view"]=="N")
                                    {
                                        $its_view_class="background:#1e275d; color:white;";
                                    }
                                    else {
                                        $its_view_class="background:#a0c7e98c; color:#080808;";
                                    }

                            ?> 
                            <div class="card">
                                <div class="card-body" style="<?=$its_view_class?>">
                                    <div class="col-12">
                                        <div class="row notifyrowbox" onclick="isclicknow(<?=$notifiid?>)" id="notifyrowthis<?=$notifiid?>">
                                            <div class="col-10 justify-content-center">
                                            <div onclick="isclicknow(<?=$notifiid?>)"> <?php echo $val["notification_text"]; ?></div>
                                            </div>
                                            <div class="col-2">
                                            <?=date("d M y",strtotime($val['notifiedtime']))?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <?php
                                $update= update("Notification",$setfiled,$wh,$setar); 
                                } 
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
    
</body>
</html>
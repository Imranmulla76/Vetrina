<?php include("init.php");
        //check_login();
    $adminrole = $_SESSION["roll"];
    $adminid = $_SESSION["user_id"];

    $divisions = find("all","divisions","*","where 1",array());

    $table = "placeorder as p inner join order_table_product as otp on p.stockiest_order_id=otp.order_id inner join customer as c on otp.user_id=c.customer_id inner join customer_hq_div as chd on c.customer_id=chd.customer_id inner join headquarters as hq on chd.hq_id=hq.hq_id";

    if($adminrole=="9")
    {
        $customerorderdetails = find("all",$table,"*,sum(tax) as amount","where payment_method='Credit' and p.user_role!='vetZone' group by otp.order_id",array());
    }
    else 
    {
        $getadminhq = find("first","admin_hq_div","*","where admin_id='$adminid'",array());
        $hq_id =  $getadminhq["hq_id"];
        // echo $hq_id;
        // exit();

        $getcustomershq = find("all","customer_hq_div","*","where hq_id='$hq_id'",array());
        // print_r($getcustomershq);
        // exit();

        $cust_id = array();
        foreach($getcustomershq as $k=>$v)
        {
            //$cust = 
            array_push($cust_id,$v["customer_id"] );
        }
        
        $customers = implode(",",$cust_id);

        // echo $customers;
        // exit;
        $customerorderdetails = find("all",$table,"*,sum(tax) as amount","where payment_method='Credit' and otp.user_id IN ($customers) and p.user_role!='vetZone' group by otp.order_id",array());

        // print_r($customerorderdetails);
        // exit();
    }

    $totaldueamt = 0;
    foreach( $customerorderdetails as $k=>$v)
    {
        $dueamt = $v["amount"];
        $totaldueamt = $totaldueamt+$dueamt;
    }

    if(isset($_POST["date"]))
    {
        $date = $_POST["date"];
        // echo $date;
        // exit;
        $customerorderdetails = find("all",$table,"*,sum(tax) as amount","where payment_method='Credit' and p.user_role!='vetZone' group by otp.order_id and DATE(created_at) = '$date'",array());
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
   <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
                    <div class="col-3">
                        <div class="card">
                             <div class="card-header">
                                <h5>Total Collection</h5>
                            </div>
                            <div class="card-body">
                              Rs. <?=$totaldueamt?>/-  
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                             <div class="card-header">
                                <h5>Due Collection</h5> 
                            </div>
                            <div class="card-body">
                                Rs. <?=$totaldueamt?>/-
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-header">
                                <h5>45 to 60</h5> 
                            </div>
                            <div class="card-body">
                                Rs./-
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="card">
                            <div class="card-header">
                                <h5>60 to 90</h5>
                            </div>
                            <div class="card-body">
                                 Rs. /-
                            </div>
                        </div>
                    </div>
                </div>

                <form action="" method="POST">
                <div class="row">
                        <div class="col-3">
                            <label for="">Search By Date</label>
                            <input type="date" name="date" id="" class="form-control">
                        </div>

                        <div class="col-3">
                            <label for="">Division</label>
                            <select name="division" class='form-control' id="">
                                <option value="">Select Division</option>
                                <?php foreach ($divisions as $k => $v) { ?>
                                    <option value="<?=$v['division_id']?>"><?=$v["division_name"]?></option>
                                <?php }?>
                            </select>
                        </div>

                        <div class="col-2">
                            <button type="submt" name="search" class="btn btn-primary mt-2">Serach</button>
                        </div>
                    </div>
                </form>

                <div class="row mt-3">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Collections</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table  id="example3" class="display min-w850">
                                <thead>
                                    <tr>
                                        <th>SR No.</th>
                                        <th>Headquarter</th>
                                        <th>Party Name</th>
                                        <th>Invoice Number</th>
                                        <th>Invoice Date</th>
                                        <th>Invoice Amount</th>
                                        <th>Due Date</th>
                                        <th>Overdue Days</th>
                                        <th>45 to 60</th>
                                        <th>60 to 90</th>
                                        <th>Above 90 Days</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i=0; foreach($customerorderdetails as $k=>$v) { $i++; 
                                    $invoicedate = date("d-M-Y",strtotime($v["created_at"]));
                                    $duedate = date("d-m-Y",strtotime($invoicedate.'+ 45 day'));

                                    $now = date("d-m-Y"); // or your date as well
                                    $datediff = strtotime($now)-strtotime($duedate);
                                    $duedays = round($datediff/86400 );

                                    $invoiceamount = $v["amount"];
                                    ?>
                                  <tr>
                                    <td><?=$i?></td>
                                    <td><?=$v["hq_name"]?></td>
                                    <td><?=$v["name"]?></td>
                                    <td><?=$v["order_id"]?></td>
                                    <td><?=$invoicedate?></td>
                                    <td><?=$invoiceamount?></td>
                                    <td><?=$duedate?></td>
                                    <td><?php if($duedays < 0) { echo "0"; }else { echo $duedays; } ?> Days </td>
                                    <td><?php if($duedays >= 45 && $duedays <= 60) { echo $invoiceamount; }else { echo "-"; } ?></td>
                                    <td><?php if($duedays >= 60 && $duedays <= 90) { echo $invoiceamount; }else { echo "-"; } ?></td>
                                    <td><?php if($duedays >= 90) { echo $invoiceamount; }else { echo "-"; } ?></td>
                                  </tr>
                                  <?php } ?>
                                </tbody>
                                </table>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
 <?php include("jslink.php"); ?>

    
</body>
</html>
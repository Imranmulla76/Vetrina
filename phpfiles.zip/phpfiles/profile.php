<?php include("init.php");
        
        $admin_id = $_GET["admin_id"];
        $type = $_SESSION['type'];

        $table = "admin as a inner join admin_meta as am on a.admin_id=am.admin_id inner join admin_hq_div as ahd on a.admin_id=ahd.admin_id inner join admin_roles as ar on a.admin_id=ar.admin_id inner join designations as des on ar.desig_id=des.desig_id inner join headquarters as hq on ahd.hq_id=hq.hq_id inner join divisions as d on ahd.div_id=d.division_id";

        $findadmin_details = find("first",$table,"*","where a.admin_id='$admin_id'",array());
        // print_r($findadmin_details);
        $tbladmin = "admin as a inner join admin_roles as ar on a.admin_id= ar.admin_id inner join designations as d on ar.desig_id=d.desig_id";
        $users =  find("all",$tbladmin,"*","where status='Y'",array());
        $designation = find("all","designations","*","where 1",array());
        $findheadquarter = find("all","headquarters","*","where 1",array());
        $finddivision =  find("all","divisions","*","where 1",array());

        $getparentroleid = $findadmin_details["parent_desig_id"];
        $getlinemanager = find("all",$tbladmin,"*","where ar.desig_id='$getparentroleid'",array());

        if(isset($_POST["update_user"]))
        {
            $name = $_POST["name"];
            $email = $_POST["email"];
            $designation = $_POST["designation"];
            $line_manager = $_POST["line_manager"];
            $address = $_POST["address"];
            $hq = $_POST["hq"];
            $division = $_POST["division"];
            $taluka = $_POST["taluka"];
            $district = $_POST["district"];
            $state = $_POST["state"];
            $pincode = $_POST["pincode"];
            $m_no_company = $_POST["m_no_company"];
            $m_no_personal = $_POST["m_no_personal"];
            $filename = $_FILES["file"]["name"];
            $filetempname = $_FILES['file']['tmp_name'];

            $setv="username=:username,admin_email=:admin_email,line_manager=:line_manager";
            $wh = "where admin_id='$admin_id'";
            $exe = array(":admin_email"=>$email,":username"=>$name,":line_manager"=>$line_manager);

            $updateadmin = update("admin",$setv,$wh,$exe);

            if (empty($_FILES['file']['name'])) {
            $setval = "address=:address,taluka=:taluka,district=:district,state=:state,pin_code=:pin_code,mob_number_company=:mob_number_company,mob_number_personal=:mob_number_personal,vetzone=:vetzone";
            $where = "where admin_id='$admin_id'";
            $ex = array(
                ":address"=>$address,
                ":taluka"=>$taluka,
                ":district"=>$district,
                ":state"=>$state,
                ":pin_code"=>$pincode,
                ":mob_number_company"=>$m_no_company,
                ":mob_number_personal"=>$m_no_personal,
                ":vetzone"=>'0',
            );

        }
        else {
            $setval = "address=:address,taluka=:taluka,district=:district,state=:state,pin_code=:pin_code,mob_number_company=:mob_number_company,mob_number_personal=:mob_number_personal,vetzone=:vetzone,profile_pic=:profile_pic";

            $where = "where admin_id='$admin_id'";
            $ex = array(
                ":address"=>$address,
                ":taluka"=>$taluka,
                ":district"=>$district,
                ":state"=>$state,
                ":pin_code"=>$pincode,
                ":mob_number_company"=>$m_no_company,
                ":mob_number_personal"=>$m_no_personal,
                ":vetzone"=>'0',
                ":profile_pic"=>$filename
            );
        }

            $update_admin_meta = update("admin_meta",$setval,$where,$ex);
            if($update_admin_meta)
            {
                 move_uploaded_file($filetempname, "user_profile/" . $filename);
            }    

            $s = "hq_id=:hq_id,div_id=:div_id";
            $w = "where admin_id='$admin_id'";
            $e = array(
                ":hq_id"=>$hq,
                ":div_id"=>$division
            );

            $update_admin_hq_div = update("admin_hq_div",$s,$w,$e);

            header("Refresh:0; url=profile.php?admin_id=$admin_id");
        }

    if($type=="admin")
	{
		$att = "";
	}
	else{
		$att="disabled";
	}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    <style>
        /* The switch - the box around the slider */
        .switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 34px;
        }

        /* Hide default HTML checkbox */
        .switch input {
        opacity: 0;
        width: 0;
        height: 0;
        }

        /* The slider */
        .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        -webkit-transition: .4s;
        transition: .4s;
        }

        .slider:before {
        position: absolute;
        content: "";
        height: 26px;
        width: 26px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        -webkit-transition: .4s;
        transition: .4s;
        }

        input:checked + .slider {
        background-color: #2196F3;
        }

        input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
        }

        input:checked + .slider:before {
        -webkit-transform: translateX(26px);
        -ms-transform: translateX(26px);
        transform: translateX(26px);
        }

        /* Rounded sliders */
        .slider.round {
        border-radius: 34px;
        }

        .slider.round:before {
        border-radius: 50%;
        }

    </style>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
                <div class="container-fluid">
                    <div class="row">
                        
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header bg-info shadow">
                                    <label for="" class="card-title text-white"> <?=$findadmin_details["username"]?></label>
                                </div>
                            
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-3" style="height:120px; width:120px;">
                                                <img src="user_profile/<?=$findadmin_details["profile_pic"]?>" alt="profile not loading." height="120px" width="120px"/>
                                        </div>
                                        <div class="col-9">
                                            <table class="">
                                                <tbody>
                                                <tr>
                                                    <td><label for="">Employee Id </label></td>
                                                    <td> : <?=$findadmin_details["emp_id"]?></td>
                                                </tr>
                                                <tr>
                                                    <td><label for="">Designation </label></td>
                                                    <td> : <?=$findadmin_details["desig_name"]?></td>
                                                </tr>
                                                <tr>
                                                    <td><label for="">Headquarter </label></td>
                                                    <td> : <?=$findadmin_details["hq_name"]?></td>
                                                </tr>
                                                <tr>
                                                    <td> <label for="">Division </label></td>
                                                    <td> : <?=$findadmin_details["division_name"]?></td>
                                                </tr>
                                                <tr>
                                                    <td><label for="">Status </label></td>
                                                    <td> : <?php 
                                                        if($findadmin_details["status"]=="Y")
                                                             { ?><label class="btn btn-success btn-xs shadow">Active</label> <?php } 
                                                        else { ?><label class="btn btn-danger btn-xs shadow">Inactive</label> <?php } ?>
                                                    </td>
                                                </tr>
                                                <?php if($type=="admin") { ?>
                                                <tr>
                                                    <td>
                                                       <label for="">Block User</label>
                                                    </td>
                                                    <td>
                                                        Unblock
                                                        <label class="switch">
                                                            <input type="checkbox" onclick="blockUser('<?=$findadmin_details['admin_id']?>')">
                                                            <span class="slider round"></span>
                                                        </label>
                                                        Block
                                                    </td>
                                                </tr>
                                                <?php } ?>
                                               </tbody> 
                                            </table>    

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            
                            <div class="row">
                                <div class="col-12">
                                    <form action="" method="POST" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="col-4">
                                                <label for="">Profile Photo</label>
                                                <div class="input-group mb-3">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text">Upload</span>
                                                    </div>
                                                    <div class="custom-file">
                                                        <input type="file" name="file" accept="image/*" class="custom-file-input">
                                                        <label class="custom-file-label">Choose file</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                             <div class="col-4">
                                                <label for="">Employee ID</label>
                                                <input type="text" name="emp_id" id="" <?=$att?> value="<?=$findadmin_details["emp_id"]?>" class="form-control">
                                            </div>
                                             <div class="col-4">
                                                <label for="">Name </label>
                                                <input type="text" name="name" class="form-control" <?=$att?>  value="<?=$findadmin_details["username"]?>" id="">
                                            </div>
                                            <div class="col-4">
                                                <label for="">Email </label>
                                                <input type="text" name="email" class="form-control" <?=$att?> value="<?=$findadmin_details["admin_email"]?>" id="">
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                            <div class="col-4">
                                                <label for="">Password </label>
                                                <input type="password" readonly name="password" class="form-control" value="<?=$findadmin_details["password"]?>" id="">
                                            </div>
                                            <div class="col-4">
                                                <label for=""> Designation </label>
                                                <select name="designation" <?=$att?>  id="" class="form-control">
                                                    <option value="">Select Designation</option>
                                                    <?php foreach($designation as $k=>$v) { ?>
                                                        <option <?php if($findadmin_details["desig_id"]==$v["desig_id"]) { echo "selected"; }?> value="<?=$v["desig_id"]?>"><?=$v["desig_name"]?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                             <div class="col-4">
                                                <label for="">Line Manager</label>
                                                <select name="line_manager" <?=$att?>  id="" class="form-control">
                                                        <?php foreach($getlinemanager as $k=>$v) { ?>
                                                            <option <?php if($findadmin_details["line_manager"]==$v["admin_id"]) { echo "selected"; }?> value="<?=$v["admin_id"]?>"><?=$v["username"]?> - <?=$v["desig_name"]?></option>
                                                        <?php } ?>    
                                                </select>
                                            </div>
                                        </div>

                                        <br>
                                        
                                        <div class="row">
                                            <div class="col-4">
                                                <label for="">Address</label>
                                                <textarea name="address" id=""  <?=$att?>  class="form-control"><?=$findadmin_details["address"]?></textarea>
                                            </div>
                                            <div class="col-4">
                                                <label for="">Headquarter</label>
                                                 <select name="hq" id="" <?=$att?>  class="form-control">
                                                    <option value="">Select Headquarter</option>
                                                    <?php foreach($findheadquarter as $k=>$v) { ?>
                                                        <option <?php if($findadmin_details["hq_id"]==$v["hq_id"]) { echo "selected"; }?> value="<?=$v["hq_id"]?>"><?=$v["hq_name"]?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-4">
                                                <label for="">Division</label>
                                                <select name="division" id="" <?=$att?>  class="form-control">
                                                    <option value="">Select division</option>
                                                    <?php foreach($finddivision as $k=>$v) { ?>
                                                        <option <?php if($findadmin_details["division_id"]==$v["division_id"]) { echo "selected"; }?> value="<?=$v["division_id"]?>"><?=$v["division_name"]?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                            <div class="col-4">
                                                <label for="">Taluka</label>
                                                <input type="text" name="taluka" class="form-control" <?=$att?>  value="<?=$findadmin_details["taluka"]?>" id="">
                                            </div>
                                            <div class="col-4">
                                                <label for="">District</label>
                                                <input type="text" name="district" class="form-control" <?=$att?>  value="<?=$findadmin_details["district"]?>" id="">
                                            </div>
                                            <div class="col-4">
                                                <label for="">State</label>
                                                 <input type="text" name="state" class="form-control" <?=$att?>  value="<?=$findadmin_details["state"]?>" id="">
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                            <div class="col-4">
                                                <label for="">Pincode</label>
                                                 <input type="text" name="pincode" class="form-control" <?=$att?>  value="<?=$findadmin_details["pin_code"]?>" id="">
                                            </div>
                                            <div class="col-4">
                                                <label for="">Mobile Number (Company)</label>
                                                <input type="number" name="m_no_company" class="form-control" <?=$att?> value="<?=$findadmin_details["mob_number_company"]?>" id="">
                                            </div>
                                            <div class="col-4">
                                                <label for="">Mobile Number (Personal)</label>
                                                <input type="number" name="m_no_personal" class="form-control" <?=$att?> value="<?=$findadmin_details["mob_number_personal"]?>" id="">
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                            <div class="col-4">
                                                
                                            </div>
                                            <div class="col-4">
                                                <center>
                                                    <button type="submit" name="update_user" class="btn btn-success shadow btn-md">Update</button>
                                                </center>
                                            </div>
                                            <div class="col-4">
        
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
        </div>
       
        
        <!-------main content end----->

        <?php include("footer.php"); ?>

    </div>

        <?php include("jslink.php"); ?>
    
        <script>
            
            function blockUser(admin_id)
            {
                $.ajax({
					method: "POST",
					url: "ajax/blockuser.php",
					data: {
						admin_id:admin_id
					}
				}).done(function(response){
                    if(response == "blocked")
                    {
                        alert("User Blocked");
                    }
                    else
                    {
                        alert("User unblocked");
                    }
                });
            }
        </script>
    
</body>
</html>
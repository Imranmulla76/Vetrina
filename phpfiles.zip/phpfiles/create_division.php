    <?php include("init.php");
            //check_login();

        if(isset($_POST["save_division"]))
        {
            $division = $_POST["division"];
            $savedesig = save("divisions","division_name",":division_name",array(":division_name"=>$division));
        }

        if(isset($_POST["update_division"]))
        {
        
            $div_id = $_POST["div_id"];
            $division_name = $_POST["division_name"];
          

            $setval = "division_name=:division_name";
            $where = "where division_id='$div_id'";
            $exe = array(":division_name"=>$division_name);

            $update_division = update("divisions",$setval,$where,$exe);
        }

        if(isset($_POST["delete"]))
        {
            $div_id = $_POST["div_id"];
            $where = "where division_id='$div_id'";
            $exe = array();

            $delete = delete("divisions",$where,$exe);
        }

        $finddivision = find("all","divisions","*","where 1",array());

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>SCM | Vetrina</title>
        <!-- Favicon icon -->
        <?php include("csslink.php"); ?>
    </head>
    <body>
    <?php include("preloader.php") ?>

        <div id="main-wrapper">
            <?php include("navbar.php"); ?>
            <?php include("chatbox.php"); ?>		
            <?php include("header.php"); ?>
            <?php include("sidebar.php"); ?>
            <!-----maincontent start----->
            <div class="content-body">
                <!-- row -->
                <div class="container-fluid">
                    <div class="row">
                        <button class="btn btn-primary" data-target=".bd-example-modal-sm" data-toggle="modal">+ Add Division</button>
                    </div>

                    
                    <div class="row mt-3">
                        <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Division</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table  id="example3" class="display min-w850">
                                    <thead>
                                        <tr>
                                            <th>SR No.</th>
                                            <th>Division</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php //print_r($finddesignations); ?>
                                        <?php $i=0; foreach($finddivision as $k=>$v) { $i++;?>
                                        <tr>
                                            <td><?=$i;?></td>
                                            <td><?=$v["division_name"]?></td>
                                            <td>
                                                <div class="d-flex">
                                                    <span onclick="updateDivision(<?=$v['division_id']?>)" class="btn btn-primary shadow btn-xs sharp mr-1"><i class="fa fa-pencil"></i></span>
                                                    <form action="" method="POST">
                                                        <input type="text" name="div_id" value="<?=$v["division_id"]?>" hidden id="">
                                                        <button type="submit" name="delete" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                    </table>
                                </div>
                            
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
            
            <!-------main content end----->
            <?php include("footer.php"); ?>
        </div>


        <!-- Create Modal -->
    <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create Division</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST">
                <div class="modal-body" id="">
                    
                        <label for="">Division</label>
                        <input type="text" class="form-control" name="division" id="">
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="save_division">Save Divsion</button>
                </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Create Modal -->

    <!-- Update Modal -->
    <div class="modal fade bd-example-modal-sm1" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create Division</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST">
                <div class="modal-body" id="div_form">
                    
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="update_division">Update Divsion</button>
                </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Create Modal -->


            <?php include("jslink.php"); ?>
        <script>
            $(document).ready(function(){
                        <?php if($savedesig) { ?>
                            swal("Division Added","New Division Added","success");    
                        <?php } ?>
                    });

            function updateDivision(div_id)
            {
                $(".bd-example-modal-sm1").modal("show");

                $.ajax({
                    url:"ajax/update_division.php",
                    method:"POST",
                    data:{div_id:div_id}
                }).done(function(response){
                    $("#div_form").html(response);
                });
            }
        </script>
    </body>
    </html>
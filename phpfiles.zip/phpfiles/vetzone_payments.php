<?php 
    include("init.php");

    // $table = "order_table_product as otp inner join placeorder as p otp.order_id=p.stockiest_order_id";
    $user_id = $_SESSION["user_id"]; 
    $role = $_SESSION["roll"]; 
   
    //$table = "customer_placeorder as cp inner join vetzone as c on cp.user_id=c.vetzone_id inner join customer_order_table_product as cotp on cp.customer_order_id=cotp.order_id inner join vetzone_end_customer as vec on cotp.customer_id=vec.end_customer_id";
   $table = "vetzone_credit_note_table as vcnt inner join vetzone as v on vcnt.user_id=v.vetzone_id";
   $payments = find("all",$table,"*","where user_id='$user_id'",array());

   $totaldue = find("first","vetzone_credit_note_table","sum(amount) as total","where user_id='$user_id' and payment_status='N'",array());
   

    
?>
<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="text-danger">Total Due</h3><br>
                                <h4>RS. <?=$totaldue["total"]?> /-</h4>  <a href="pay_now.php?amount=<?=$totaldue['total']?>" class="btn btn-info btn-md" >Pay</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table bordered id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>VetZone Name</th>
                                                <th>Order Id</th>
                                                <th>invoice Date</th>
                                                <th>Total Amount</th>
                                                <th>Due Date</th>
                                                <th>Payment Status</th>
                                                <th>Comment</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                $i=0; foreach($payments as $key=>$val) { $i++;
                                                $invoice_date = date("d M Y",strtotime($val["invoice_date"]));
                                                $due_date = date("d M Y",strtotime($val["credit_end_date"]));
                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["name"]?></td>
                                                <td><?=$val["order_id"]?></td>
                                                <td><?=$invoice_date?></td>
                                                <td><?=$val["amount"]?></td>
                                                <td> <STRONG class="text-danger"> <?=$due_date?> </STRONG> </td>
                                                <td>
                                                <?php
                                                    if($val["payment_status"]=="N")
                                                    {
                                                        echo "<label class='label label-warning'>Pending</label>";
                                                    }
                                                    else if($val["payment_status"]=="P")
                                                    {
                                                        echo "<label class='label label-info'>Pending for Approval</label>";
                                                    }
                                                     else if($val["payment_status"]=="Y")
                                                    {
                                                        echo "<label class='label label-success'>Completed</label>";
                                                    }
                                                     else
                                                    {
                                                        echo "<label class='label label-danger'>Declined</label>";
                                                    }
                                                    ?>
                                                </td> 
                                                <td><?=$val["comment"]?></td>
                                               
                                                
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>        
                            </div>
                        </div>            
                    </div>            
                </div>            
            </div>            
        </div>            
    <!-------main content end----->
        

    <!-- Payment Modal -->
    <div class="modal fade paymentdetails" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header header-primary">
                    <h5 class="modal-title">Payment Details</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="modal-body" id="order_details">
                            <label for="">Credit Id</label>
                            <input type="text" name="credit_order_id" class="form-control" readonly id="cr_order_id" value="">
                            <br>
                            <label for="">Payment Mode</label>
                            <select name="payment_mode" class="form-control" id="">
                                 <option value="Net Banking">Net Banking</option>
                                 <option value="Cash">Cash</option>
                                 <option value="UPI">UPI</option>
                            </select>
                            <br>
                            <label for="">Transaction Id</label>
                            <input type="text" name="transaction_id" id="" class="form-control">
                            <br>
                            <label for="">Amount</label>
                            <input type="text" name="payment_amount" readonly id="amount" class="form-control">
                            <br>
                            <label for="">Reciept <span class="text-danger">*</span></label>
                            <input type="file" name="file" required class="form-control" id="">
                    </div>
                    <div class="modal-footer">
                        
                        <button type="submit" class="btn btn-primary" name="save_paymentdetails">Submit</button>
                        <!-- <button type="submit" class="btn btn-primary" name="approve">Save & Approve Order</button> -->
                        <!-- <button type="submit" class="btn btn-danger" name="decline">Decline Order</button> -->
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->


        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

        <script>

           function paynow(credit_id,amount)
           {
                $(".paymentdetails").modal("show");
                $("#cr_order_id").val(credit_id);
                $("#amount").val(amount);
           }

        </script>
    </body>
</html>
<?php include("init.php");
       
       $roll = $_SESSION["roll"];

       if(isset($_POST["save"]))
       {
            $vetzone_id = $_POST["vetzone_id"];
            $sim_number=$_POST["sim_number"];
            $opening_goods=$_POST["open_goods"];
            $machine_number=$_POST["machine_number"];
            $furniture=$_POST['furniture'];

            $fields="vetzone_id,sim_number,opening_goods,machine_number,furniture";
            $values=":vetzone_id,:sim_number,:opening_goods,:machine_number,:furniture";
            $exe = array(":vetzone_id"=>$vetzone_id,":sim_number"=>$sim_number,":opening_goods"=>$opening_goods,":machine_number"=>$machine_number,":furniture"=>$furniture);
           
            $savelrdetails = save("vetzone_goods",$fields,$values,$exe);

            if($savelrdetails)
            {
                $setvalue="establishment_status=:establishment_status";
                $where ="where vetzone_id='$vetzone_id'";
                $exe = array(":establishment_status"=>'Y');
                $updatevetzone_meta = update("vetzone",$setvalue,$where,$exe);
 
            }
            
          
       }      
      
        $tbladmin = "admin as a inner join admin_hq_div as ahd on ahd.admin_id=a.admin_id";
        $admin_id = $_SESSION["user_id"];

        $table = "vetzone as v inner join vetzone_type as vt on v.type=vt.v_type_id inner join vetzone_goods as vg on v.vetzone_id=vg.vetzone_id inner join vetzone_hq_div as vhd on vhd.vetzone_id=v.vetzone_id
        inner join headquarters as hq on hq.hq_id=vhd.hq_id";

        if($roll == "7")
        {
            $findcustomers = find("all",$table,"*","where v.approval_status = 'Y' AND v.is_registered='Y' AND v.establishment_status='Y' ",array());
        }
        else {
            $findcustomers = find("all",$table,"*","where v.approval_status = 'N' and is_registered='Y'",array());
        }
       
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">VetZone  List</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.no</th>
                                                <th>VetZone Name</th>
                                                <th>HQ</th>
                                                <th>Mobile Number</th>
                                                <th>SIM Number</th>
                                                <th>Opening Goods</th>
                                                <th>Machine</th>
                                                <th>Furniture</th>
                                               
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; foreach($findcustomers as $key=>$val) { $i++;  ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["name"]?></td>
                                                <td><?=$val["hq_name"]?></td>
                                                <td><?=$val['mobile_number']?></td>
                                                <td><?=$val['sim_number']?></td>
                                                <td><?=$val['opening_goods']?></td>                                                
                                                <td><?=$val['machine']?></td>
                                                <td><?=$val['furniture']?>                                                  
                                                </td>
                                                <!-- <td>
                                                    <div class="d-flex" >
                                                        <form action="" method="POST">
                                                            <input type="text" name="cust_id" value="<?=$val["vetzone_id"]?>" hidden id="">
                                                            <span type="submit" name="view_details" onclick="view_order_details('<?=$val['vetzone_id']?>')"  class="btn btn-info ">Establish</span> 
                                                        </form>
                                                    </div>
                                                </td> -->
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>        
                </div>
            </div>
        </div>
        <!-- Establishment Form  -->
        <div class="modal fade ordersdetails" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">VetZone Goods</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST">
                    <div class="modal-body" id="order_details">
                        
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" name="save">Save</button>
                       
                    </div>
                </form>
            </div>
        </div>
    </div>
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
        <script>
      $(document).ready(function(){
                <?php if($save) { ?>
                    swal("VetZone Goods ","VetZone Created","success");    
                <?php } ?>
            });

        function view_order_details(cust_id)
            {
                $(".ordersdetails").modal("show");

                $.ajax(
                {
                     url:"ajax/establishment_form.php",
                     method:"POST",
                     data:{cust_id:cust_id}

                }).done(function(response){
                    $("#order_details").html(response);
                });
            }
            </script>
</body>
</html>
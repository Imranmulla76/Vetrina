<?php include("init.php");
      
     $vetzones = find("all","vetzone","*","where approval_status='Y' and establishment_status='Y'",array());

     $user_id = $_SESSION["user_id"];
     $response = "";
     if(isset($_POST["request"]))
     {
        $vetzone_id = $_POST["vetzone"];

        $check = find("first","vetzone_close_request","*","where vetzone_id='$vetzone_id'",array());
        if($check)
        {
            $response = "<p class='text-danger'>Close request already generated for this VetZone.</p>";
        }
        else {
            
        $fields = "vetzone_id,created_by";
        $values = ":vetzone_id,:created_by";
        $exe = array(":vetzone_id"=>$vetzone_id,":created_by"=>$user_id);
        $close_request = save("vetzone_close_request",$fields,$values,$exe);

        if($close_request)
        {
            $setval="approval_status=:approval_status";
            $where = "where vetzone_id='$vetzone_id'";
            $exe = array(":approval_status"=>"N");
            $updatevetzonestatus = update("vetzone",$setval,$where,$exe);
        }

        $response="<p class='text-success'>Close request for VetZone Sent Successfully !.</p><br><strong>This VetZone is Now Blocked</strong>";
        }
    }

     $tbl = "vetzone_close_request as vcr inner join vetzone as v on vcr.vetzone_id=v.vetzone_id inner join admin as a on vcr.created_by=a.admin_id";
     $getvetzonecloserequest = find("all",$tbl,"*,vcr.status as requestStatus","where 1",array());
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    <link rel="stylesheet" href="./vendor/select2/css/select2.min.css">
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
         <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                       
                        <div class="card">
                            <div class="card-header">
                                <h4>VetZone Close Request</h4>
                            </div>
                            <div class="card-body">
                                   <form action="" method="POST">
                                        <label for="">Select VetZone *</label>
                                        <select name="vetzone" id="vetzone-select" class="form-control">
                                            <option value="">Select VetZone</option>
                                            <?php foreach($vetzones as $k=>$v) { ?>
                                                <option value="<?=$v["vetzone_id"]?>"><?=$v["name"]?></option>
                                            <?php } ?>
                                        </select>
                                        <br>
                                        <br>
                                        <button type="submit" name="request" class="btn btn-success btn">Send Vetzone Close</button>
                                   </form>
                                   <br>
                                   <span><?=$response?></span>
                            </div>
                        </div>
                    </div>
                </div>
                    
                                            
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>Requested List</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table bordered id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>VetZone Name</th>
                                                <th>HQ</th>
                                                <th>Requested By</th>
                                                <th>Requested Date</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; foreach($getvetzonecloserequest as $k=>$val) { $i++;?>
                                                <tr>
                                                    <td><?=$i?></td>
                                                    <td><?=$val["name"]?></td>
                                                    <td>Headquarter</td>
                                                    <td><?=$val["username"]?></td>
                                                    <td><?=$val["created_on"]?></td>
                                                    <td><?=$val["requestStatus"]?></td>
                                                </tr>
                                            <?php } ?>

                                        </tbody>
                                    </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
     <script src="./vendor/select2/js/select2.full.min.js"></script>
        
        <script>
            $("#vetzone-select").select2();
                                                
            <?php if($close_request) { ?>
            swal("Close Request Sent !","Close request is generated","success");
            <?php } ?>
        </script>
</body>
</html>
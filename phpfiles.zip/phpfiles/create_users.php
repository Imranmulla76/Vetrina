<?php include("init.php");
        //check_login();

    if(isset($_POST["add_user"]))
    {
        $name = $_POST["name"];
        $designation = $_POST["designation"];
        $address = $_POST["address"];
        $taluka = $_POST["taluka"];
        $district = $_POST["district"];
        $state = $_POST["state"];
        $taluka = $_POST["taluka"];
        $pincode = $_POST["pincode"];
        $geo_location = $_POST["geo_location"];
        $latitude = $_POST["latitude"];
        $emp_id = $_POST["emp_id"];
        $m_no_company = $_POST["m_no_company"];
        $m_no_personal = $_POST["m_no_personal"];
        $email = $_POST["email"];
        $hq = $_POST["hq"];
        $division = $_POST["division"];
        $line_manager = $_POST["line_manager"];
        $password = $_POST["password"];


        $fields = "username,admin_email,password,permission_id,created_by";
        $values = ":username,:admin_email,:password,:permission_id,:created_by";
        $exe = array(
            ":username"=>$name,
            ":admin_email"=>$email,
            ":password"=>$password,
            ":permission_id"=>"1",
            ":created_by"=>$_SESSION["user_id"]
        );

        $saveadmin = save("admin",$fields,$values,$exe);

        if($saveadmin)
        {
            $f = "admin_id,address,taluka,district,state,pin_code,geo_location,emp_id,mob_number_company,mob_number_personal,vetzone";
            $v = ":admin_id,:address,:taluka,:district,:state,:pin_code,:geo_location,:emp_id,:mob_number_company,:mob_number_personal,:vetzone";
            $arr = array(
                ":admin_id"=>$saveadmin,
                ":address"=>$address,
                ":taluka"=>$taluka,
                ":district"=>$district,
                ":state"=>$state,
                ":pin_code"=>$pincode,
                ":geo_location"=>$geo_location,
                ":emp_id"=>$emp_id,
                ":mob_number_company"=>$m_no_company,
                ":mob_number_personal"=>$m_no_personal,
                ":vetzone"=>$vetzone,
            );

            $saveadminmeta = save("admin_meta",$f,$v,$arr);

            $fd = "admin_id,desig_id";
            $val = ":admin_id,:desig_id";
            $ar = array(":admin_id"=>$saveadmin,":desig_id"=>$designation);
            $saveadminrole = save("admin_roles",$fd,$val,$ar);

            $fild = "admin_id,hq_id,div_id";
            $valu = ":admin_id,:hq_id,:div_id";
            $ary = array(":admin_id"=>$saveadmin,":hq_id"=>$hq,":div_id"=>$division);
            $saveadminhqdiv = save("admin_hq_div",$fild,$valu,$ary);

            $getdesignation = find("first","designations","*","where desig_id='$designation'",array());
            $desig_name = $getdesignation["desig_name"];

            $url = "https://tdtl.world/vscm/PHPMailer/send_mail.php";
                $data = array(
                        "mailto" => $email,
                        "subject" => "Welcome to VetrinaHealthcare" ,
                        "fullname" => "User Registration",
                        "fromname" => "Vetrina Healthcare",
                        "message" => "Dear ".$name.",<br>
                        <center><b>We Welcome you in<br>
                        Vetrina Family</b></center>
                        Download the mobile application <b>VetBiz</b> from play store and user login as <b>".$desig_name."</b> 
                        with credentials as follows,<br>
                        Email ID- ".$email."<br>
                        Password: 123456 <br>
                        You can also login on web Panel on <a href='https://tdtl.world/vscm/user_login.php'>User Login</a>."
                );

                $curl = curl_init($url);
                curl_setopt($curl, CURLOPT_POST, true);
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                $res = curl_exec($curl);
                curl_close($curl);
        }

    }

    if(isset($_POST["delete"]))
    {
        $admin_id = $_POST["admin_id"];
        $where = "where admin_id='$admin_id'";
        $setval = "status=:status";
        $exe = array(":status"=>'N');
        $updatedelete = update("admin",$setval,$where,$exe);
    }

    $designation = find("all","designations","*","where 1",array());
    $findheadquarter = find("all","headquarters","*","where 1",array());
    $finddivision =  find("all","divisions","*","where 1",array());
    $tbladmin = "admin as a inner join admin_roles as ar on a.admin_id= ar.admin_id inner join designations as d on ar.desig_id=d.desig_id";
    $users =  find("all",$tbladmin,"*","where status='Y'",array());

    $admins ="admin as a inner join admin_roles as ar on a.admin_id= ar.admin_id inner join designations as d on ar.desig_id=d.desig_id inner join admin_meta as am on a.admin_id=am.admin_id";
    $finduser = find("all",$admins,"*","where status='Y'",array());
    $findblockeduser = find("all",$admins,"*","where status='N'",array());
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>

</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
   <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
                    <button class="btn btn-primary" data-target=".bd-example-modal-sm" data-toggle="modal">+ Add User</button>
				</div>

                <div class="row mt-3">
                    <div class="col-12">
                      <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Active Users</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example3" class="display min-w850">
                                <thead>
                                    <tr>
                                        <th>SR.No.</th>
                                        <th>User Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Designation</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php //print_r($finddesignations); ?>
                                    <?php $i=0; foreach($finduser as $k=>$v) { $i++;?>
                                    <tr>
                                        <td><?=$i;?></td>
                                        <td><?=$v["username"]?></td>
                                        <td><?=$v["admin_email"]?></td>
                                        <td><?=$v["mob_number_personal"]?></td>
                                        <td><?=$v["desig_name"]?></td>
                                        <td>   
                                            <?php if($v["status"]=="Y")  
                                            { ?><label class="btn btn-success btn-xs shadow">Active</label> <?php } 
                                            else { ?><label class="btn btn-danger btn-xs shadow">Inactive</label> <?php } ?>
                                        </td>
                                        <td>
                                            <div class="d-flex">
                                                <form action="" method='POST'>
                                                    <input type="text" hidden name="admin_id" value="<?=$v["admin_id"]?>" id="">
                                                    <button type="submit" name="delete" class="btn btn-danger shadow btn-xs sharp mr-1"><i class="fa fa-trash"></i></button>
                                                </form>
                                                <a href="profile.php?admin_id=<?php echo $v["admin_id"];?>" class="btn btn-info shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
											</div>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                                </table>
                            
                            </div>
                           
                        </div>
                    </div>
                    </div>
                </div>

                <!-- Blocked Users -->

                 <div class="row mt-3">
                    <div class="col-12">
                      <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Blocked Users</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example3" class="display min-w850">
                                <thead>
                                    <tr>
                                        <th>SR.No.</th>
                                        <th>User Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Designation</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php //print_r($finddesignations); ?>
                                    <?php $i=0; foreach($findblockeduser as $k=>$v) { $i++;?>
                                    <tr>
                                        <td><?=$i;?></td>
                                        <td><?=$v["username"]?></td>
                                        <td><?=$v["admin_email"]?></td>
                                        <td><?=$v["mob_number_personal"]?></td>
                                        <td><?=$v["desig_name"]?></td>
                                        <td>   
                                            <?php if($v["status"]=="Y")  
                                            { ?><label class="btn btn-success btn-xs shadow">Active</label> <?php } 
                                            else { ?><label class="btn btn-danger btn-xs shadow">Inactive</label> <?php } ?>
                                        </td>
                                        <td>
                                            <div class="d-flex">
                                                <form action="" method='POST'>
                                                    <input type="text" hidden name="admin_id" value="<?=$v["admin_id"]?>" id="">
                                                    <button type="submit" name="delete" class="btn btn-danger shadow btn-xs sharp mr-1"><i class="fa fa-trash"></i></button>
                                                </form>
                                                <a href="profile.php?admin_id=<?php echo $v["admin_id"];?>" class="btn btn-info shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
											</div>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                                </table>
                            
                            </div>
                           
                        </div>
                    </div>
                    </div>
                </div>

            </div>
        </div>
        !-------main content end----->
        <?php include("footer.php"); ?>
    </div>


    <!-- Create Modal -->
 <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add User</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <form action="" method="POST">
            <div class="modal-body">
                
                   <div class="row">
                       <div class="col-4">
                            <label for="">Name</label>
                            <input type="text" name="name" id="" class="form-control">
                       </div>
                       <div class="col-4">
                            <label for="">Designation</label>
                             <select name="designation" id="" class="form-control">
                                <option value="">Select Designation</option>
                                <?php foreach($designation as $k=>$v) { ?>
                                    <option value="<?=$v["desig_id"]?>"><?=$v["desig_name"]?></option>
                                <?php } ?>
                            </select>
                       </div>
                   </div>
                    <br>
                    <div class="row">
                       <div class="col-12">
                           <label for="">Address</label>
                           <textarea name="address" id="" cols="15" class="form-control"></textarea>
                       </div>
                   </div>
                    <br>
                <div class="row">
                       <div class="col-4">
                            <label for="">Taluka</label>
                            <input type="text" name="taluka" id="" class="form-control">
                       </div>
                       <div class="col-4">
                            <label for="">District</label>
                            <input type="text" name="district" id="" class="form-control">
                       </div>
                        <div class="col-4">
                            <label for="">State</label>
                            <input type="text" name="state" id="" class="form-control">
                       </div>
                    </div>
<br>
                    <div class="row">
                       
                        <div class="col-4">
                            <label for="">Pin Code</label>
                            <input type="number" name="pincode" id="" class="form-control">
                       </div>
                        
                        <div class="col-4" id="map">

                        </div>

                        <div class="col-4">
                            <label for="">Geo Location</label>
                            <input type="text" name="geo_location" id="location" class="form-control">
                       </div>
                        
                    </div>
                    <br>

                   <div class="row">
                       <div class="col-4">
                           <label for="">Employee ID</label>
                           <input type="text" name="emp_id" id="" class="form-control">
                       </div>
                       <div class="col-4">
                           <label for="">Mobile Number (Company)</label>
                           <input type="number" name="m_no_company" id="" class="form-control">
                       </div>
                       <div class="col-4">
                           <label for="">Mobile Number (Personal)</label>
                           <input type="number" name="m_no_personal" id="" class="form-control">
                        </div>
                   </div>
                   <br>
                   <div class="row">
                        
                        <div class="col-4">
                           <label for="">Email Id</label>
                           <input type="email" name="email" id="" class="form-control">
                        </div>
                   
                        <div class="col-4">
                           <label for="">Headquarter</label>
                           <select name="hq" id="" class="form-control">
                                    <option value="">Select Headquarter</option>
                                    <?php foreach($findheadquarter as $k=>$v) { ?>
                                        <option value="<?=$v["hq_id"]?>"><?=$v["hq_name"]?></option>
                                    <?php } ?>
                           </select>
                        </div>
                        <div class="col-4">
                           <label for="">Division</label>
                                <select name="division" id="" class="form-control">
                                        <option value="">Select division</option>
                                        <?php foreach($finddivision as $k=>$v) { ?>
                                            <option value="<?=$v["division_id"]?>"><?=$v["division_name"]?></option>
                                        <?php } ?>
                                </select>
                        </div>
                   </div>
                <br>
                   <div class="row">
                       <div class="col-6">
                           <label for="">Line Manager</label>
                           <select name="line_manager" id="" class="form-control">
                                <?php foreach($users as $k=>$v) { ?>
                                    <option value="<?=$v["admin_id"]?>"><?=$v["username"]?> - <?=$v["desig_name"]?></option>
                                <?php } ?>    
                           </select>
                       </div>
                       <div class="col-6">
                            <label for="">Password</label>
                            <input type="password" name="password" id="" value="123456" readonly class="form-control">
                       </div>
                   </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" name="add_user">Add User</button>
            </div>
            </form>
        </div>
    </div>
</div>

 <!-- Create Modal -->


        <?php include("jslink.php"); ?>
        <script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAZ98Q6wSl8SSCoVpc2vKFpZtF01ls0Yoo&callback=initMap&v=weekly"
        async></script>
        
        <script>
            $(document).ready(function(){
                <?php if($saveadmin) { ?>
                    swal("User Added","New User Created","success");    
                    <?php } ?>
                })
                </script>
        <script>

        let map;


        function initMap() {
            const myLatlng = { lat: 18.5204, lng: 73.8567 };
            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 8,
                center: myLatlng,
            });
            // Create the initial InfoWindow.
            let infoWindow = new google.maps.InfoWindow({
                content: "Click the map to get Lat/Lng!",
                position: myLatlng,
            });

            infoWindow.open(map);
            // Configure the click listener.
            map.addListener("click", (mapsMouseEvent) => {
                // Close the current InfoWindow.
                infoWindow.close();
                // Create a new InfoWindow.
                infoWindow = new google.maps.InfoWindow({
                    position: mapsMouseEvent.latLng,
                });
                infoWindow.setContent(
                    JSON.stringify(mapsMouseEvent.latLng.toJSON(), null, 2)
                );
                infoWindow.open(map);
                // alert(JSON.stringify(mapsMouseEvent.latLng.toJSON(), null, 2));
                $("#location").val(JSON.stringify(mapsMouseEvent.latLng.toJSON(), null, 2));
            });
        }
    </script>
    
</body>
</html>
<?php 
    include("init.php");

    
    $user_id = $_SESSION["user_id"]; 
    $role = $_SESSION["roll"]; 

    $table="vetzone_close_request as vc inner join vetzone as v on v.vetzone_id=vc.vetzone_id inner join vetzone_type as vt on v.type=vt.v_type_id
            INNER join vetzone_hq_div as vhd on vhd.vetzone_id=v.vetzone_id
            INNER join divisions as d on d.division_id=vhd.div_id ";
    $closevetzone=find("all",$table,"*","where vc.status='P'",array());

    // SELECT *,sum(rate*quantity) FROM `customer_order_table_product` 
    // inner join vetzone_close_request on vetzone_close_request.vetzone_id=customer_order_table_product.seller_user_id
    // where vetzone_close_request.status='P' GROUP By customer_order_table_product.`seller_user_id`;
    if(isset($_POST["approve"]))
    {
        $vetzone_id=$_POST['vetzone_id'];
        $setval="status=:status";
        $where ="where vetzone_id=$vetzone_id";
        $exe=array(":status"=>"Y");
        $updateclosevetzonestatus=update("vetzone_close_request",$setval,$where,$exe);
    }
     
    
?>

<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table bordered id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>VetZone Name</th>
                                                <th>Division</th>
                                                <th>Sale</th>
                                                <th>Available Stock</th>
                                                <th>Paid Commission</th>
                                                <th>Refund Amount</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                
                                                $i=0; foreach($closevetzone as $key=>$val) { $i++;
                                                    $vetzone_id=$val['vetzone_id'];
                                                    $stable="customer_order_table_product inner join vetzone_close_request as vc on vc.vetzone_id=customer_order_table_product.seller_user_id";
                                                    $where="where vc.status='P'  AND vc.vetzone_id=$vetzone_id GROUP By customer_order_table_product.seller_user_id";
                                                    $findvetzonesale=find("all",$stable,"sum(rate*quantity) as sale",$where,array());
                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["name"]?></td>
                                                <td><?=$val["division_name"]?></td>
                                                <td><?=$findvetzonesale["sale"]?></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>
                                                   <?php if($val["status"]=="P") {
                                                        echo "<label class='label label-warning'>Pending</label>";
                                                    }
                                                    else if($val["status"]=="D")
                                                    {
                                                        echo "<label class='label label-danger'>Decliened</label>";
                                                    }
                                                    else if($val["status"]=="Y")
                                                    {
                                                        echo "<label class='label label-success'>Closed</label>";
                                                    }
                                                   
                                                    ?>
                                                </td>
                                                <td>
                                                   <form action="" method="POST">
                                                    <input type="text" name="vetzone_id" value="<?=$val['vetzone_id']?>" hidden/>
                                                   <button type="submit" class="btn btn-primary" name="approve">Approve</button>
                                                </form>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody> 
                                    </table>
                                </div>        
                            </div>
                        </div>            
                    </div>            
                </div>            
            </div>            
        </div>            
        <!-------main content end----->      

      
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

     

    </body>
</html>
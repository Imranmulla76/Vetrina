<?php include("logininit.php");

$roll = $_SESSION["roll"];

 foreach($_SESSION as $key=>$val)
 {
     if(isset($_SESSION[$key]))
     {
        echo $_SESSION[$key]."<br>";
     }
 }
 ?>
<?php include("init.php");
    
    $roll = $_SESSION["roll"];
    $type = $_SESSION["type"];

    $user_loged_in = $_SESSION["user_id"];
    $customer_id = $_GET["customer_id"];
    // echo $customer_id;

    $fcust = find("first","customer","*","where customer_id='$customer_id'",array());
    if($fcust["role"]=="1" || $fcust["role"]=="2" || $fcust["role"]=="3" || $fcust["role"]=="7" || $fcust["role"]=="8") {
        $table = "customer as c inner join customer_roles as cr on c.role=cr.cust_role_id inner join distributor_type as dt on c.type=dt.distributor_type_id inner join customer_kyc_document as ckd on c.customer_id=ckd.customer_id";
    }
    else {
        $table = "customer as c inner join customer_roles as cr on c.role=cr.cust_role_id inner join distributor_type as dt on c.type=dt.distributor_type_id";
    }

    $findcustomer = find("first",$table,"*","where c.customer_id='$customer_id' order by c.customer_id DESC",array());

    $roles = find("all","customer_roles","*","where 1",array());
    $distributor_type = find("all","distributor_type","*","where 1",array());
    $findheadquarter = find("all","headquarters","*","where 1",array());
    $finddivision =  find("all","divisions","*","where 1",array());
    $kycdoc =  find("all","customer_kyc_document","*","where customer_id='$customer_id'",array());

    $findadmin = find("all","admin as a inner join admin_hq_div as ahq on a.admin_id=ahq.admin_id inner join headquarters as hq on ahq.hq_id=hq.hq_id inner join divisions as d on ahq.div_id=d.division_id","*","where 1",array());




    $customer_meta = find("all","customer_meta","*","where customer_id='$customer_id'",array());

       foreach($customer_meta as $key=>$val)
        {
            if($val["customer_meta_value"]!="")
            {
                define($val["customer_meta_key"],$val["customer_meta_value"]);
            }
            else
            {
                define($val["customer_meta_key"],"0");
            }
        }

        if(isset($_POST["update_customer"]))
        {
            $headquarter = $_POST["hq"];
            $division = $_POST["division"];
            $approval_admin_id = $_POST["approval_admin_id"];

            $fields = "customer_id,hq_id,div_id,approval_admin_id";
            $values = ":customer_id,:hq_id,:div_id,:approval_admin_id";

            $ex = array(":customer_id"=>$customer_id,":hq_id"=>$headquarter,":div_id"=>$division,":approval_admin_id"=>$approval_admin_id);
            $save_cust_hq_div = save("customer_hq_div",$fields,$values,$ex);

           $data = $_POST;

           $where = "where customer_id='$customer_id'";
           $exe = array();
           $delete = delete("customer_meta",$where,$exe);

           foreach($data as $key=>$val)
           {
                $customer_meta_key	= $key;
                $customer_meta_value = $val;

                $fields = "customer_id,customer_meta_key,customer_meta_value";
                $values = ":customer_id,:customer_meta_key,:customer_meta_value";
                
                $exe = array(":customer_id"=>$customer_id,":customer_meta_key"=>$customer_meta_key,":customer_meta_value"=>$customer_meta_value);
                $savecustmeta = save("customer_meta",$fields,$values,$exe);
           }

           if($savecustmeta)
           {
               $data = array("cust_id"=>$customer_id,"action"=>"approve","to_admin_id"=>$approval_admin_id);
               registrationProcess($data);

               if($roll == 1)
               {
                    $send_form_id = "1";
                    $send_to_id =  $approval_admin_id;
                    $notify_text = "New Customer Registration Request for Approval , Approved by Admin";
                    notify($send_form_id,$send_to_id,$notify_text);
               }
               else if($roll == "3" || $roll == "4" || $roll == "5")
               {
                    $send_form_id = $user_loged_in;
                    $send_to_id =  "5";
                    $notify_text = "New Customer Registration Request for Approval , Approved by Sales Head";
                    notify($send_form_id,$send_to_id,$notify_text);
               }
               else if($roll=="9")
               {
                    // Save credit details of customer in credit table 
                    $getcredits = find("first","credit_note_user_details","*","where user_id='$customer_id'",array());
                    $credit_days = $_POST["credit_days"];
                    $credit_limit =  $_POST["credit_limit"];
                    if($getcredits)
                    {
                        $setval = "credit_limit=:credit_limit,credit_days=:credit_days";
                        $where = "where user_id='$customer_id'";
                        $exe = array(
                            ":credit_limit"=>$credit_limit,
                            ":credit_days"=>$credit_days
                        );
                        $update_credit = update("credit_note_user_details",$setval,$where,$exe);
                    }
                    else
                    {
                        $credit_days = $_POST["credit_days"];
                        $credit_limit =  $_POST["credit_limit"];
                        $fields = "user_id,credit_limit,credit_days";
                        $values = ":user_id,:credit_limit,:credit_days";
                        $exe = array(
                            ":user_id"=>$customer_id,
                            ":credit_limit"=>$credit_limit,
                            ":credit_days"=>$credit_days
                        );

                        $savecustomer_credit = save("credit_note_user_details",$fields,$values,$exe);
                    }
                    $send_form_id = $user_loged_in;
                    $send_to_id =  "7";
                    $notify_text = "New Customer Registration Request for Approval , Approved by Finance";
                    notify($send_form_id,$send_to_id,$notify_text);
               }
           }

           if($roll == 11)
           {
               $setval = "kyc_status=:kyc_status,approval_status=:approval_status";
               $where = "where customer_id = '$customer_id'";
               $statusexe = array(":kyc_status"=>"Y",":approval_status"=>"Y");
               $updatecust = update("customer",$setval,$where,$statusexe);

               if($updatecust)
               {
                   $url = "https://vscm.vetrinahealthcare.com/PHPMailer/send_mail.php";
                $data = array(
                        "mailto" => $findcustomer["email"],
                        "subject" => "Customer Approved at VetrinaHealthcare" ,
                        "fullname" => "Welcome To Vetrinahealthcare",
                        "fromname" => "Vetrina Healthcare",
                        "message" => "Dear ".$findcustomer["name"].",<br>
                                    <center><b>We Welcome you in<br>
                                    Vetrina Family</b></center>
                                    Kindly check your login credentials as follows,<br>
                                    Email ID- ".$findcustomer["email"]."<br>
                                    Password: 123456 <br>
                                    To Place your first order please Visit our customer Panel on <a href='https://vscm.vetrinahealthcare.com/customer_login.php'>Customer Login</a>."
                );

                $curl = curl_init($url);
                curl_setopt($curl, CURLOPT_POST, true);
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                $res = curl_exec($curl);
                curl_close($curl);

                $send_form_id = $user_loged_in;
                $send_to_id =  "5";
                $notify_text = "New Customer Registration Request for Approval";
                notify($send_form_id,$send_to_id,$notify_text);

               }
           }


           redirectfn("approvals.php");
        }


        if(isset($_POST["saveorderapproval"]))
        {
            $customer =  $customer_id;
            $action =  $_POST["action"];
            $paymentmode =  $_POST["paymentmode"];
            
            $from_admin = $_POST["from"];
            $findfromrole = find("first","admin as a inner join admin_roles as ar on a.admin_id=ar.admin_id","*","where a.admin_id='$from_admin'",array());
            $from_admin_role = $findfromrole["desig_id"];
            
            $to_admin = $_POST["to"];
            $findtorole = find("first","admin as a inner join admin_roles as ar on a.admin_id=ar.admin_id","*","where a.admin_id='$to_admin'",array());
            $to_admin_role = $findtorole["desig_id"];

            $fields = "from_customer_id,from_admin_id,from_role_id,action,to_admin_id,to_role_id,payment_method";
            $values = ":from_customer_id,:from_admin_id,:from_role_id,:action,:to_admin_id,:to_role_id,:payment_method";
            
            $findorderinghie = find("all","ordering_hierarchy","*","where from_customer_id='$customer_id'",array());

            if(!$findorderinghie)
            {
                $exe = array(
                ":from_customer_id"=>$customer,
                ":from_admin_id"=>"0",
                ":from_role_id"=>"0",
                ":action"=>$action,
                ":to_admin_id"=>$to_admin,
                ":to_role_id"=>$to_admin_role,
                ":payment_method"=>$paymentmode
            );
            }
            else {
                $exe = array(
                ":from_customer_id"=>$customer,
                ":from_admin_id"=>$from_admin,
                ":from_role_id"=>$from_admin_role,
                ":action"=>$action,
                ":to_admin_id"=>$to_admin,
                ":to_role_id"=>$to_admin_role,
                ":payment_method"=>$paymentmode
            );
            }

           
            $saveorderinghierarchy = save("ordering_hierarchy",$fields,$values,$exe);
        }

         if(isset($_POST["reset"]))
            {
                $cust_id = $_POST["cust_id"];
                $where = "where from_customer_id='$cust_id'";
                $exe = array();
                $delete = delete("ordering_hierarchy",$where,$exe);
            }


        $tablecustdivhq ="customer as c inner join customer_hq_div as chd on c.customer_id=chd.customer_id inner join headquarters as h on chd.hq_id=h.hq_id inner join divisions as d on chd.div_id=d.division_id";
        $findheadquarter = find("first",$tablecustdivhq,"*","where c.customer_id='$customer_id'",array());
      
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="./vendor/select2/css/select2.min.css">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
                <div class="container-fluid">
                    <div class="col-12">
                    <div class="row">
                        
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header bg-info shadow">
                                    <label for="" class="card-title text-white"> <?=$findcustomer["name"]?></label>
                                </div>
                            
                                <div class="card-body">
                                    <div class="row">
                                        <!-- <div class="col-3" style="height:120px; width:120px;">
                                                <img src="kyc_documents/<?php //$findcustomer["document"][7]?>" alt="Not Availabel" height="120px" width="120px"/>
                                        </div> -->
                                        <div class="col-9">
                                            <table class="table table-bordered">
                                                <tbody>
                                                <tr>
                                                    <td><label for="">Customer Id </label></td>
                                                    <td> : <?=$findcustomer["customer_id"]?></td>
                                                </tr>
                                                
                                                <tr>
                                                    <td><label for="">Role </label></td>
                                                    <td> : <?=$findcustomer["role_name"]?></td>
                                                </tr>
                                                <tr>
                                                    <td><label for="">Type </label></td>
                                                    <td> : <?=$findcustomer["distributor_type"]?></td>
                                                </tr>
                                                <tr>
                                                    <td><label for="">Headquarter </label></td>
                                                    <td> : <?=$findheadquarter["hq_name"]?></td>
                                                </tr>
                                                <tr>
                                                    <td> <label for="">Division </label></td>
                                                    <td> : <?=$findheadquarter["division_name"]?></td>
                                                </tr>
                                                <tr>
                                                    <td><label for="">Status </label></td>
                                                    <td> : <?php 
                                                        if($findcustomer["approval_status"]=="Y")
                                                             { ?><label class="btn btn-success btn-xs shadow">Approved</label> <?php } 
                                                        else { ?><label class="btn btn-danger btn-xs shadow">Pending</label> <?php } ?>
                                                    </td>
                                                </tr>
                                               </tbody> 
                                            </table>    

                                        </div>

                                       
                                    </div>
                                </div>
                            </div>
                        </div>

                         <div class="col-6">
                             <div class="row">
                                 <span class="btn btn-info btn-md shadow" onclick="getcustomerDetails('<?=$findcustomer['customer_id']?>')">View All Details</span> <br>
                                 <!-- <span class="btn btn-success btn-md shadow ml-1" onclick="setorder_approval('<?php //$findcustomer['customer_id']?>')">Set Order Approval</span> -->
                            </div>

                            <?php if($type=="admin") { ?>
                                <div class="row mt-4">
                                    <div class="col-12">
                                        <div class="card">
                                            <div class="card-header">
                                                <h4>Customer Order Approval</h4>

                                            </div>
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th>From</th>
                                                            <th>Payment Mode</th>
                                                            <th>Action</th>
                                                            <th>TO</th>
                                                            <th>Save</th>
                                                        </tr>
                                                    </thead>
                                                    <form action="" method="POST">
                                                        <tbody>
                                                            
                                                            <?php 
                                                                $cust_id = $findcustomer["customer_id"];
                                                                $tbl = "ordering_hierarchy";
                                                                $findorderinghier = find("all",$tbl,"*","where from_customer_id='$cust_id'",array()); 
                                                                foreach($findorderinghier as $key=>$val) {
                                                                $fromadmin = $val["from_admin_id"];
                                                                $toadmin = $val["to_admin_id"];
                                                            ?>
                                                            <tr>
                                                                <td>
                                                                    <?php if($val["from_admin_id"]=="0") 
                                                                    { 
                                                                        echo $findcustomer["name"]; 
                                                                    }else{
                                                                        $getfromadmin = find("first","admin","*","where admin_id='$fromadmin'",array());
                                                                        echo $getfromadmin["username"];
                                                                    }?>
                                                                </td>
                                                                <td><?=$val["payment_method"]?></td>
                                                                <td><?=$val["action"]?></td>
                                                                <td><?php
                                                                        $gettoadmin = find("first","admin","*","where admin_id='$toadmin'",array());
                                                                        echo $gettoadmin["username"];                                                        
                                                                    ?>
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                            <?php } ?>

                                                            <tr>
                                                                <td>
                                                                    <?php 
                                                                $findorderinghiera = find("first",$tbl,"*","where from_customer_id='$cust_id' order by ordering_hierarchy_id desc",array()); 

                                                                $fromadmin_id = $findorderinghiera["to_admin_id"];

                                                                if(!$findorderinghiera)
                                                                {
                                                                    echo $findcustomer["name"];
                                                                }
                                                                else 
                                                                { 
                                                                    ?>
                                                                    <input type="text" name="from" id="" hidden value="<?=$fromadmin_id?>">
                                                                    <?php 
                                                                        $getfromadmin = find("first","admin","*","where admin_id='$fromadmin_id'",array());
                                                                        echo $getfromadmin["username"];
                                                                        }
                                                                    ?>

                                                                </td> 
                                                                <td>
                                                                    <select name="paymentmode" id="" class="form-control">
                                                                        <option value="">Select Payment Mode</option>
                                                                        <option value="Advanced">Advanced</option>
                                                                        <option value="Credit">Credit</option>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="action" class="form-control" id="">
                                                                        <option value="">Select Action</option>
                                                                        <option value="Approve">Approve</option>
                                                                        <option value="Decline">Decline</option>
                                                                        <option value="Complete">Complete</option>
                                                                    </select>
                                                                </td>
                                                                
                                                                <td>
                                                                    <select name="to" class="form-control" id="single-select">
                                                                        <option value="">Select Admin</option>
                                                                        <?php 
                                                                        foreach($findadmin as $k=>$v){
                                                                            ?>
                                                                            <option value="<?=$v["admin_id"]?>"><?=$v["username"]?> ( hq-<?=$v["hq_name"]?> , Div-<?=$v["division_name"]?> ) </option>
                                                                        <?php }
                                                                        ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <button type="submit" name="saveorderapproval" class="btn btn-sm btn-warning">Save</button>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </form>
                                                </table>
                                            </div>  
                                            
                                            <div class="card-footer">
                                                <form action="" method="POST">
                                                    <input type="text" hidden name="cust_id" value="<?=$cust_id ?>" id="">
                                                    <button type="submit" name="reset" class="btn btn-sm btn-primary"><i class="fa fa-pencil"></i> Reset All</button>
                                                </form>
                                            </div> 
                                        </div>
                                       
                                    </div>
                                </div>
                            <?php } ?>
                         </div>   
                    </div>
                </div>    

                    <div class="card">
                        <div class="card-body">
                            
                            <div class="row">
                                <div class="col-12" id="customer_details">
                                   
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
        </div>
       
        
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>
        <script src="./vendor/select2/js/select2.full.min.js"></script>
        
        <script>

            $("#single-select").select2();
               
            $(function(){
                <?php if( $update_credit) { ?>
                    swal("Credit Details Updated","customer credit details updated successfully","success");
                <?php } ?>
                <?php if( $savecustomer_credit) { ?>
                    swal("Credit Details Saved","customer credit details Saved successfully","success");
                <?php } ?>
            });

            function getcustomerDetails(customer_id) {
                $.ajax({
                    url:"ajax/customer_details_form.php",
                    method:"POST",
                    data :{customer_id:customer_id}
                }).done(function(response){
                    $("#customer_details").html(response);
                });             
            }

            function getmanagers(division)
            {
                var hq = $("#hq").val();
                $.ajax({
                        
                        url:"ajax/get_hq_vise_admin.php",
                        method:"POST",
                        data:{division:division,hq:hq}

                }).done(function(response){
                    $("#manager").html(response);
                });
            }
        </script>
</body>
</html>
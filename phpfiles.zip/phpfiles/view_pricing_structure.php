<?php 
    include("init.php");

    $customer_role = $_SESSION["roll"];
 
    // $findcustomerdivision = find("first","customer as c inner join customer_hq_div as chd on c.customer_id=chd.div_id inner join divisions as d on chd.div_id=d.division_id","*","where c.customer_id='$customer_id'",array());
    // $divisionid = $findcustomerdivision["div_id"];
    // $division = $findcustomerdivision["division_name"];

    $table = "pricing_structure as ps inner join divisions as d on ps.division_id=d.division_id inner join customer_roles as cr on ps.customer_type=cr.cust_role_id";
    $findpricingstructure = find("all",$table,"*","where ps.customer_type='$customer_role'",array());
    // $filename = $findpricing["file"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
            <div class="content-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Divisional Pricing Structure</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                         <div class="table-responsive">
                                    <table  id="example3" class="display min-w850">
                                    <thead>
                                        <tr>
                                            <th>SR No.</th>
                                            <th>Division</th>
                                            <th>Customer</th>
                                            <th>File</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php //print_r($finddesignations); ?>
                                        <?php $i=0; foreach($findpricingstructure as $k=>$v) { $i++;?>
                                        <tr>
                                            <td><?=$i?></td>
                                            <td><?=$v["division_name"]?></td>
                                            <td><?=$v["role_name"]?></td>
                                            <td><a href="pricing/<?php echo $v["file"] ?>">View File</a></td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                    </table>
                                </div>
                                    </div>
                                </div>
                            </div>
                        </div>        
                    </div>
                </div> 
            </div>       
        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

    </body>
</html>        
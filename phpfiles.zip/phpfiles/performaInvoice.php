<?php 
    include("init.php");
   
    $order_id = $_GET["order_id"];

    
    $getcustomertype = find("first","placeorder","*","where stockiest_order_id='$order_id'",array());
    $customerrole = $getcustomertype["user_role"];

    if($customerrole=="VetZone")
    {
        $table = "order_table_product as otp inner join placeorder as p on otp.order_id=p.stockiest_order_id inner join product as pd on otp.product_id=pd.product_id inner join vetzone as c on p.user_id=c.vetzone_id";
        $order_detail = find("all",$table,"*","where otp.order_id='$order_id'",array());

        $getcustomer = find("first","placeorder as p inner join vetzone as c on p.user_id=c.vetzone_id","*","where stockiest_order_id='$order_id'",array());
        $customer_id = $getcustomer["vetzone_id"];
        $comment = $getcustomer["comment"];

         $customer_meta = find("all","vetzone_meta","*","where vetzone_id='$customer_id'",array());

        foreach($customer_meta as $key=>$val)
        {
            if($val["vetzone_meta_value"]!="")
            {
                define($val["vetzone_meta_key"],$val["vetzone_meta_value"]);
            }
            else
            {
                define($val["vetzone_meta_key"],"0");
            }
        }
    }
    else 
    {
        $table = "order_table_product as otp inner join placeorder as p on otp.order_id=p.stockiest_order_id inner join product as pd on otp.product_id=pd.product_id inner join customer as c on p.user_id=c.customer_id";
        $order_detail = find("all",$table,"*","where otp.order_id='$order_id'",array());
    
        $getcustomer = find("first","placeorder as p inner join customer as c on p.user_id=c.customer_id","*","where stockiest_order_id='$order_id'",array());
        $customer_id = $getcustomer["customer_id"];
        $comment = $getcustomer["comment"];
        
        $customer_meta = find("all","customer_meta","*","where customer_id='$customer_id'",array());

        foreach($customer_meta as $key=>$val)
        {
            if($val["customer_meta_value"]!="")
            {
                define($val["customer_meta_key"],$val["customer_meta_value"]);
            }
            else
            {
                define($val["customer_meta_key"],"0");
            }
        }
    }


    if(isset($_POST["orderid"]))
    {
      
      $order_id = $_POST["orderid"];
     // echo $order_id;
     // exit;
      $filename = "performaInvoice";

        $curl = curl_init("https://vetrinahealthcare.com/dms/html2pdf/pdfperformaInvoice.php");
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, "order_id=$order_id");
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($curl);
        curl_close($curl);

        $data =  "success";


      $mailcontent = "New Performa Invoice for your Order created and attached with the mail.";
      $mailsubject = "Performa Invoice";
      $to =  $email;
      contractMailwithattach($to,$mailsubject,$mailcontent,$filename);

    }
        
?>

<html>

<head>
     <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Performa Invoice</title>
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <div class="performa" id="temp-target">
        <div class="main" style="width: 1200px; margin: 10px auto; padding: 0 69px; font-weight: bold;border: 1px solid black;">
            <div class="head" style="display: flex;border-bottom: 1px solid #60497A;border-width: 20px;">
                <div class="para">
                    <p> Vetrina Healthcare Pvt. Ltd. <br>Punyai Pride, Shivshambho Nagar Lane 3A, Katraj Kondwa Road,
                        Katraj, Pune, 411046 <br>Pune - 411051, Mobile - 7410027596, admin@vetrinahealthcare.com <br></p>
                </div>
                <div class="img"><img src="uploads/vetrina_logo.png" alt=""></div>
            </div>
            <div class="mid">
                <h2 style="text-align: center;"><b>PERFORMA INVOICE</b></h2>
                <h2></h2>

                <table style="border: 1px solid black; width: 1060px; border-collapse: collapse;">

                    <tr>
                        <td style="border: 1px solid black;" colspan="2">Bank</td>
                        <td style="border: 1px solid black;"><?=bank_name?></td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid black;" colspan="2">Branch</td>
                        <td style="border: 1px solid black;"><?=bank_address?></td>
                        <td style="border: 1px solid black;">State Code </td>
                        <td style="border: 1px solid black;"><?=State?></td>

                    </tr>
                    <tr>
                        <td style="border: 1px solid black;" colspan="2">IFSC CODE:</td>
                        <td style="border: 1px solid black;"><?=bank_ifsc?></td>
                        <td style="border: 1px solid black;">GSTIN: </td>
                        <td style="border: 1px solid black;"><?=gst_no?></td>

                    </tr>
                    <tr>
                        <td style="border: 1px solid black;" colspan="2">ACC NO:</td>
                        <td style="border: 1px solid black;"><?=bank_ac_no?></td>
                        <td style="border: 1px solid black;">PAN NO. : </td>
                        <td style="border: 1px solid black;"><?=pan_no?></td>

                    </tr>
                    <tr>
                        <td style="border: 1px solid black;" colspan="2"><b>TO:</b></td>
                        <td style="border: 1px solid black;"><b><?=cust_name?></b></td>
                        <td style="border: 1px solid black;">Ref/PO No</td>
                        <td style="border: 1px solid black;"></td>

                    </tr>
                    <tr>
                        <td style="border: 1px solid black;" colspan="2"></td>
                        <td style="border: 1px solid black;"><b><?=address?> ,</b></td>
                        <td style="border: 1px solid black;">PO Date:</td>
                        <td style="border: 1px solid black;"><?=date("Y-m-d",strtotime($getcustomer['created_date']))?></td>

                    </tr>
                    <tr>
                        <td style="border: 1px solid black;" colspan="2"></td>
                        <td style="border: 1px solid black;"><b><?=mob_no?></b></td>
                        <td style="border: 1px solid black;">Invoice No </td>
                        <td style="border: 1px solid black;"><?=$getcustomer['stockiest_order_id']?></td>

                    </tr>
                    <tr>
                        <td style="border: 1px solid black;" colspan="2"></td>
                        <td style="border: 1px solid black;"></td>
                        <td style="border: 1px solid black;">Transport: </td>
                        <td style="border: 1px solid black;"></td>

                    </tr>

                </table>
                <br>
                <div class="table">
                    <table style="border: 1px solid black; width: 1060px; border-collapse: collapse;text-align: center;">
                        <thead>

                            <tr>
                                <td style="border: 1px solid black;"><b>Sr</b></td>
                                <td style="border: 1px solid black;"><b>Product Name</b></td>
                                <td style="border: 1px solid black;"><b>Pack</b></td>
                                <td style="border: 1px solid black;"><b>Container</b></td>
                                <td style="border: 1px solid black;"><b>Qty</b></td>
                                <td style="border: 1px solid black;"><b>Price</b></td>
                                <td style="border: 1px solid black;"><b>MRP</b></td>
                                <td style="border: 1px solid black;"><b>GST</b></td>
                                <td style="border: 1px solid black;"><b>Amount</b></td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i=0; $gross=0; $nettotal=0; $gst=0;

                                foreach($order_detail as $key => $value){ $i++;
                                    $product_id = $value["product_id"];

                                    $amount = $value['quantity']*$value["rate"];

                                    $findgst = find("first","product_gst","*","where product_id='$product_id'",array());
                                    $gstamt=($amount* $findgst["gst"])/100;
                                    $total=$gstamt+$amount;
                                ?>
                                <tr>
                                    
                                    <td style="border: 1px solid black;"><?=$i?></td>
                                    <td style="border: 1px solid black;"><?=$value['product_name']?></td>
                                    <td style="border: 1px solid black;"><?=$value['unit']?></td>
                                    <td style="border: 1px solid black;"><?=$value['sku']?></td>
                                    <td style="border: 1px solid black;"><?=$value['quantity']?></td>
                                    <td style="border: 1px solid black;"><?=$value['rate']?></td>
                                    <td style="border: 1px solid black;"><?=$value['mrp']?></td>
                                    <td style="border: 1px solid black;"><?=$findgst['gst']?></td>
                                    <td style="border: 1px solid black;"><?=$total?></td>
                                </tr>
                                <?php 
                                $nettotal+=$total;
                                $gst += $gstamt;
                                $gross+=$amount;  
                                }
                                ?>
                            
                            <tr>
                                <td colspan="9" style="height: 20px;border: 1px solid black;"></td>
                            </tr>
                            <tr>
                                <td style="border: 1px solid black;text-align: end;" colspan="8"> <strong>Total</strong> </td>
                                <td style="border: 1px solid black;"><?=$nettotal?></td>
                            </tr>
                            <tr>
                                <td style="border: 1px solid black;text-align: left;" colspan="2"><strong>Amount In Words</strong></td>
                                <td style="border: 1px solid black;text-align: left;" colspan="7"> <strong><?=strtoupper(NumberToIndianCurrency($nettotal));?></strong> </td>
                            </tr>
                            <tr>
                                <td style="border: 1px solid black;text-align: left;" colspan="12">Remark:</td>
                            </tr>
                            <tr>
                                <td colspan="5"></td>
                                <td style="border: 1px solid black;border-bottom: hidden;" colspan="1"></td>
                                <td style="border: 1px solid black;" colspan="2">Gross</td>
                                <td style="border: 1px solid black;"><?=$gross?></td>
                            </tr>
                            <tr>
                                <td colspan="5"></td>
                                <td style="border: 1px solid black;border-bottom: hidden;" colspan="1"></td>
                                <td style="border: 1px solid black;" colspan="2">GST</td>
                                <td style="border: 1px solid black;"><?=$gst?></td>
                            </tr>
                            <tr>
                                <td colspan="5"></td>
                                <td style="border: 1px solid black;border-bottom: hidden;" colspan="1"></td>
                                <td style="border: 1px solid black;" colspan="2">Cr. Note</td>
                                <td style="border: 1px solid black;">0</td>
                            </tr>
                            <tr>
                                <td style="border: 1px solid black; border-top: hidden;" colspan="5"></td>
                                <td style="border: 1px solid black;border-bottom: hidden;" colspan="1"></td>
                                <td style="border: 1px solid black;" colspan="2">Dr. Note</td>
                                <td style="border: 1px solid black;">0</td>
                            </tr>
                            <tr>
                                <td colspan="5"> <strong>Vetrina Healthcare Pvt Ltd</strong> </td>
                                <td style="border: 1px solid black;border-bottom: hidden;" colspan="1"></td>
                                <td style="border: 1px solid black;" colspan="2">Others</td>
                                <td style="border: 1px solid black;">0</td>
                            </tr>
                            <tr>
                                <td colspan="5"></td>
                                <td style="border: 1px solid black;border-bottom: hidden;" colspan="1"></td>
                                <td style="border: 1px solid black;" colspan="2">Discount </td>
                                <td style="border: 1px solid black;">0</td>
                            </tr>
                            <tr>
                                <td style="border: 1px solid black; border-top: hidden;" colspan="5"></td>
                                <td style="border: 1px solid black;border-bottom: hidden;" colspan="1"></td>
                                <td style="border: 1px solid black;" colspan="2">Net Amount</td>
                                <td style="border: 1px solid black;"><?=$nettotal?></td>
                            </tr>
                            <tr>
                                <td colspan="5" style="border: 1px solid black;border-top: hidden;">Authorised sign</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td style="height: 25px;border: 1px solid black;" colspan="9"></td>
                            </tr>
                            <tr>
                                <td colspan="12">Any claim/dispute ariese in respect of this invoice is subjected to
                                    jurdiction of Pune court only. Any complaints with regards to quality & quantity must be
                                    made to us in writing within 8 days from the date of goods receipt. There after no
                                    complaint will be entairtened
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
           
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <br><br>
        <center> <button onclick="converHTMLFileToPDF();" class="btn btn-primary"> <i class="fas fa-file-download"></i> Generate PDF</button></center>
        </div>
    </div>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.3.1/jspdf.umd.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.0/html2canvas.min.js" integrity="sha512-UcDEnmFoMh0dYHu0wGsf5SKB7z7i5j3GuXHCnb3i4s44hfctoLihr896bxM0zL7jGkcHQXXrJsFIL62ehtd6yQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        
        <script>

            function converHTMLFileToPDF() 
            {
                const { jsPDF } = window.jspdf;
                // var doc = new jsPDF('l', 'mm', [1800 , 1210]);
               var doc = new jsPDF('l', 'mm', [1800 , 1500]);

                var pdfjs = document.querySelector('#temp-target');

                // Convert HTML to PDF in JavaScript
                doc.html(pdfjs, {
                    callback: function(doc) {
                        doc.save("Performa Invoice.pdf");
                    },
                    x: 1,
                    y: 2
                });
            }
        </script>

        </body>
</html>
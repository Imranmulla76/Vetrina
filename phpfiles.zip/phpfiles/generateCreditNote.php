<?php

include("init.php");

$user_id = $_SESSION["user_id"];
// echo $user_id;exit;
$_SESSION["file_name"];
// print_r($_SESSION);exit;
$type = $_SESSION["type"]; //customer  and vetzone

// $_SERVER["SCRIPT_FILENAME"] => C:/xampp/htdocs/vscm/generateCreditNote.php
// $_SERVER["PHP_SELF"] => /vscm/generateCreditNote.php

/* select p.product_id, p.product_name, p.sku, p.product_code, p.unit,
ci.product_id, ci.quantity, ci.batch, ci.manfacturing_date, ci.expiry_date, ci.created_by
from product p, customer_instock ci
where p.product_id = ci.product_id
and ci.expiry_date > date(now() + INTERVAL 90 DAY)
and created_by = 4; */
if($type == 'customer')
{
    $table = "product p, customer_instock ci";
    $value = "p.product_id, p.product_name, p.sku, p.product_code, p.unit, ci.product_id, ci.quantity, ci.batch, ci.manfacturing_date, ci.expiry_date, ci.created_by";
    $where = "where p.product_id = ci.product_id and ci.expiry_date > date(now() + INTERVAL 90 DAY) and created_by = $user_id";
    $products = find("all", $table, $value, $where, array());
}
else if($type == 'vetzone')
{
    $table = "product p, vetzone_instock vi";
    $value = "p.product_id, p.product_name, p.sku, p.product_code, p.unit, vi.product_id, vi.quantity, vi.batch, vi.manfacturing_date, vi.expiry_date, vi.created_by";
    $where = "where p.product_id = vi.product_id and vi.expiry_date > date(now() + INTERVAL 90 DAY) and created_by = $user_id";
    $products = find("all", $table, $value, $where, array());
}




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
    <link rel="stylesheet" href="./vendor/select2/css/select2.min.css">

</head>
<body>

<?php include("preloader.php") ?>

<div id="main-wrapper">
    <?php include("navbar.php"); ?>
    <?php include("chatbox.php"); ?>
    <?php include("header.php"); ?>
    <?php include("sidebar.php"); ?>
    <!-----maincontent start----->
    <div class="content-body">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <button onclick="viewreturncart();" data-toggle="modal" data-target="#returnedproducts" class="btn">Return Cart <img src="icons/cart.png" height="28" alt=""></button>                               
                                </div>    
                            </div>
                                <!-- <div class="col-2">
                                    Return Cart                                  
                                </div>
                                <div class="col-2">
                                    <a class="nav-link" onclick="viewreturncart();" data-toggle="modal" data-target="#returnedproducts" title = "Products to Return" id = "returncart">
                                        <img src="icons/cart.png" height="28" alt=""> 
                                    </a>
                                </div> -->
                            
                            
                            <div class="table-responsive">
                                <table id="creditNote" class="display min-w850">

                                    <thead>
                                        <tr>
                                            <th>Sr.No</th>
                                            <th>Product</th>
                                            <th>SKU</th>
                                            <th>Unit</th>
                                            <th>Product Code</th>
                                            <th>Batch</th>
                                            <th>Expiry date</th>
                                            <th>Available Quantity</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php
                                            $i = 0;
                                            foreach($products as $item)
                                            {
                                                $i++;
                                                if($type == 'customer')
                                                    $isvetzone = "seller_user_role <> 'VetZone'";
                                                else if($type == 'vetzone')
                                                    $isvetzone = "seller_user_role = 'VetZone'";
                                                $soldproducts = find("first","customer_order_table_product", "* , sum(quantity) as qty", "where product_id=".$item['product_id']." and batch='".$item['batch']."' and seller_user_id=".$user_id." and ".$isvetzone, array());
                                                $qty = $item["quantity"] - $soldproducts["qty"];
                                                if($qty == 0)
                                                {
                                                    continue;
                                                }
                                                $p_id = $item['product_id'];
                                                $p_name = $item["product_name"];
                                                $sku = $item["sku"];
                                                $batch = $item["batch"];

                                        ?>
                                        <tr>
                                            <td><?=$i;?></td>
                                            <td><?=$item["product_name"];?></td>
                                            <td><?=$item["sku"];?></td>
                                            <td><?=$item["unit"];?></td>
                                            <td><?=$item["product_code"];?></td>
                                            <td><?=$item["batch"];?></td>
                                            <td><?=$item["expiry_date"];?></td>
                                            <td><?=$qty;?></td>
                                        <?php
                                            $isadded = find("first", "goods_return_details", "*", "where product_id = $p_id and sku = '$sku' and batch = '$batch'", array());
                                            if($isadded)
                                            {
                                        ?>
                                                <td><button class="btn btn-sm shadow btn-info" disabled>+ Add to return</button></td>                                                
                                        <?php  
                                            }
                                            else
                                            {
                                        ?>                                            
                                               <td><button class="btn btn-sm shadow btn-info" onclick="addtoreturn('<?=$p_id.'+'.$p_name.'+'.$sku.'+'.$batch.'+'.$qty?>')">+ Add to return</button></td> 
                                        <?php
                                            }
                                        ?>
                                        </tr>
                                        <?php
                                            }
                                        ?>
                                    </tbody>

                                    <tfoot>
                                        <tr>
                                            
                                        </tr>
                                    </tfoot>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal for cart (return goods) -->
    <div class="modal fade" id="returnedproducts" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Product Details to Return</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="modal-body" id="returnedproductsdetails">
                    <table id="returncarttable" class="table" style="width:100%" >
                            <thead>
                                <th>Sr.No</th>
                                <th>Product Id</th>
                                <th>Product Name</th>
                                <th>SKU</th>
                                <th>Available Quantity</th>
                                <th>Action</th>                                
                            </thead>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <div class="" id="returntocartresponse"></div>
                        <button type="button" class="btn btn-danger light" data-dismiss="modal" id = "closemodal">Close</button>
                        <span type="submit" class="btn btn-primary" id="returnproducts" onclick="returnproduct();" name="save_pricing">Return</span>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- modal for cart (return goods) -->
    <!-------main content end----->
    <?php include("footer.php"); ?>
</div>
<?php include("jslink.php"); ?>
<script src="./vendor/select2/js/select2.full.min.js"></script>
<!-- <script src="./js/arrayToTable.js"></script> -->

<script>

var prodarray = [];

var carttable;

$(document).ready(function () {
    // $('#creditNote tr > *:nth-child(9)').hide();
    $('#creditNote').DataTable({
        dom: 'Bfrtip',
        
    });

});

/* $("#modalclose").click(function({
    location.reload();
});
) */

function removeproduct(pid)
{
    // alert(pid);
    $.ajax({ 
        url: "ajax/returnProduct.php",
        type: "POST",
        data: { 
            action : 'removefromcart',
            p_id : pid,
        },
        success: function(data) {
            // alert(data);
            // carttable.ajax.reload();
            viewreturncart();
            }
    });
}

function viewreturncart()
{  
    carttable = $("#returncarttable").DataTable({
        responsive: true,
        dom: 'lBfrtip',

        "ajax":
			  {
			  	'url' : 'ajax/returnProduct.php',
				'type': 'POST',
				'data': {
						 action : 'viewreturncart',
						},
				
			  },        

        columnDefs: [
            {
                render: function (data, type, row) {
                    return '<a class = "clickable" onclick = "removeproduct('+row[1]+');" id = "remove"> - Remove </a>';
                },
                targets: 5,
            },

            { 
                visible: false, 
                targets: [1] 
            },
        ],

        destroy : true,
        
    });    

    // carttable.destroy();

}

function addtoreturn(data)
{
    // alert(data);
    data = data.split('+');
    p_id = data[0];
    p_name = data[1];
    sku = data[2]
    batch = data[3];
    qty = data[4]; 
    // alert(data);
    $.ajax({ 
        url: "ajax/returnProduct.php",
        type: "POST",
        data: { 
            action : 'addtocart',
            p_id : p_id,
            sku : sku,
            batch : batch,
            qty : qty,
        },
        success: function(response)
        {
            // alert(response);
            if(response > 0)
            {
                swal("Success!","Product added!","success");
                location.reload();
            }
            // alert("returned at id"  : response)
        }

    });
}


function returnproduct()
{
    $.ajax({ 
        url: "ajax/returnProduct.php",
        type: "POST",
        data: {
            action : 'return',            
        },
        // datatype: "json",
        success: function(response)
        {
            if(response > 0)
            {
                swal("Success!","Product in cart returned!","success");
                location.reload();
                // viewreturncart();
            }
            // alert("returned at id"  : response)
        }

    });

}

</script>

</body>
</html>
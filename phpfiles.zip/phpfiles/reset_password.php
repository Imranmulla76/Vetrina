<?php 
 include("registrationinit.php");
$response= "";
$response_status = "none";

$id = $_GET["id"];
$type = $_GET["type"];

 if(isset($_POST["updatepass"]))
 {

    $password = $_POST["password"];
    $cpassword = $_POST["cpassword"];

    if($password == $cpassword)
    {
        $response= "Passowrd Matched , updating password..";
        $response_status = "success";

        if($type=='admin' || $type=='user')
        {
            $setval = "password=:password";
            $where = "where admin_id='$id'";
            $exe=array(":password"=>$password);
            $update = update("admin",$setval,$where,$exe);
            
            if($update)
            {
                $response= "Passowrd Matched , updating password..";
                $response_status = "success";

                 if($type=='admin')
                 {
                     redirectfn("index.php");
                 }
                 else {
                     redirectfn("user_login.php");
                 }
            }
        }
        else if($type=='customer')
        {
            $setval = "password=:password";
            $where = "where customer_id='$id'";
            $exe=array(":password"=>$password);
            $update = update("customer",$setval,$where,$exe);

            if($update)
            {
                $response= "Passowrd Matched , updating password..";
                $response_status = "success";

                redirectfn("customer_login.php");
            }

        }
        else if($type=='vetzone')
        {
            $setval = "password=:password";
            $where = "where vetzone_id='$id'";
            $exe=array(":password"=>$password);
            $update = update("vetzone",$setval,$where,$exe);

            if($update)
            {
                $response= "Passowrd Matched , updating password..";
                $response_status = "success";

                redirectfn("vetzone_login.php");
            }
        }
    }
    else 
    {
        $response= "Passowrd Not Matching";
        $response_status = "error";
    }

    
        
}
?>
<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Recover Account</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <style>
        body
        {
            background-image : url("images/login_bg.jpg");
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
									<div class="text-center mb-3 bg-white p-2" style="border-radius: 20px;">
										<a href="index.html"><img src="images/logo-text.png" style="width:50%" alt=""></a>
									</div>
                                    <h4 class="text-center mb-4 text-white">Recover My Account</h4>
                                    <form action="" method="POST">
                                    <?php if(isset($response_status)){ 
                                            
                                        if($response_status!="none") { 
                                            if($response_status=="error") {
                                            ?>
                                            <div class="form-group bg-danger text-white p-1">  
                                                <?= $response?>
                                            </div>
                                        <?php 
                                            }
                                            if($response_status=="success") {
                                                ?>
                                                <div class="form-group bg-success text-white p-1">  
                                                <?= $response?>
                                                </div>
                                            <?php 
                                                }
                                    
                                        } } ?>
                                         <div class="form-group">
                                            <label class="mb-1 text-white"><strong>New Password</strong></label>
                                            <input type="password" name="password" class="form-control" placeholder="Enter password" value="">
                                        </div>
                                         <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Confirm New Password</strong></label>
                                            <input type="password" name="cpassword" class="form-control" placeholder="Re-enter password" value="">
                                        </div>
                                       
                                        <div class="text-center">
                                            <input  type="submit" name="updatepass" class="btn bg-white text-primary btn-block" value="Update Password" />
                                        </div>

                                    </form>
                                    
                                       
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="./js/custom.min.js"></script>
    <script src="./js/deznav-init.js"></script>

</body>

</html>
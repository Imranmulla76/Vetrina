<?php include("init.php");
        //check_login();
        $table = "instock as i inner join product as p on i.product_id=p.product_id inner join good_reciept as gr on gr.good_reciept_id=i.good_reciept_id";
        $findinstock = find("all",$table,"*","where 1",array());
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
         <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Challan Report</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                <table id="example1" class="table display min-w850">
                                    <thead>
                                        <tr>
                                            <th>Sr.No</th>
                                            <th>Challan No.</th>
                                            <th>Challan Date</th>
                                            <th>Product Name</th>
                                            <th>SKU</th>
                                            <th>Quantity</th>
                                            <th>Batch</th>
                                            <th>Manufacturing Date </th>
                                            <th>Expiry Date</th>
                                            <th>MRP</th>
                                            <th>PTS</th>
                                            <th>PTR</th>
                                            <th>PTC</th>
                                            <th>PTV</th>
                                            <th>PTK</th>
                                            <th> Scheme Lot-I</th>
                                            <th> scheme Lot-II</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Sr.No</th>
                                            <th>Challan No.</th>
                                            <th>Challan Date</th>
                                            <th>Product Name</th>
                                            <th>SKU</th>
                                            <th>Quantity</th>
                                            <th>Batch</th>
                                            <th>Manufacturing Date </th>
                                            <th>Expiry Date</th>
                                            <th>MRP</th>
                                            <th>PTS</th>
                                            <th>PTR</th>
                                            <th>PTC</th>
                                            <th>PTV</th>
                                            <th>PTK</th>
                                            <th> Scheme Lot-I</th>
                                            <th> scheme Lot-II</th>
                                        </tr>
                                        </tr>
                                    </tfoot>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
        

        <!-------main content end----->
        <?php include("footer.php"); ?>
    </div>
    
        <?php include("jslink.php"); ?>
        <script>

            $(document).ready(function() {
                $.post("ajax/challanreportlist.php",function(response){
                    console.log(response);
                });

               $('#example1').DataTable( {
                   "processing": true,
                   "serverSide": true,
                   "ajax": "ajax/challanreportlist.php"    
                } );
            });
        </script>
    
</body>
</html>
<?php 
    include("init.php");

    $user_id = $_SESSION["user_id"]; 
    $role = $_SESSION["roll"]; 
    
     if(isset($_POST["approve_requisition"]))
    {
        $requisition_id = $_POST["requisition_id"];
        $setval = "status=:status";
        $where  = "where requisition_id='$requisition_id'";
        $exe = array(":status"=>"I");
        $update_requisition_status = update("requisition",$where,$setval,$exe);
    }

    $table = "requisition as r inner join requisition_details as rd on r.requisition_id=rd.requisition_id inner join products as p on rd.product_id=p.product_id";
    $getrequisitions = find("all","requisition as r inner join admin as a on r.created_by=a.admin_id","*","where 1",array());
    
?>
<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Coorder_approvalmpatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table bordered id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Created By</th>
                                                <th>Created Date</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                $i=0; foreach($getrequisitions as $key=>$val) { $i++;
                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["username"]?></td>
                                                <td><?=$val["created_date"]?></td>
                                                <td>
                                                    <?php if($val["status"]=="P") {
                                                        echo "<label class='label label-warning'>Pending</label>";
                                                    }
                                                    else if($val["status"]=="I")
                                                    {
                                                        echo "<label class='label label-danger'>In process</label>";
                                                    }
                                                    else
                                                    {
                                                        echo "<label class='label label-success'>Completed</label>";
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <span class="btn btn-info shadow btn-xs sharp" onclick="viewrequisitiondetails(<?=$val['requisition_id']?>)"><i class="fa fa-eye"></i></span>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>        
                            </div>
                        </div>            
                    </div>            
                </div>            
            </div>            
        </div>            
        <!-------main content end----->
        

        <!-- Order Modal -->
    <div class="modal fade req_details" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Requisition Details</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST">
                    <div class="modal-body" id="requisitiondetails">
                        
                        
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- order Modal -->

        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

        <script>

            $(function(){
                <?php if($update_requisition_status) { ?>
                    swal("Requisition Accepted","requisition sent to Production","success");
                <?php } ?>
            });

                function viewrequisitiondetails(req_id)
                {
                    $(".req_details").modal("show");
                    $.ajax({
                        url:"ajax/requisitionDetails.php",
                        method:"POST",
                        data:{req_id:req_id}
                    }).done(function(response){
                        $("#requisitiondetails").html(response);
                    });
                }
         
        </script>
    </body>
</html>




<div class="footer">
            <div class="copyright">
                <p>vetrinahealthcare © Designed &amp; Developed by <a href="http://tdtl.world/" target="_blank">The Data Tech Lab Inc</a> 2022</p>
            </div>
</div>

 <!-- Cart Modal -->
    <div class="modal fade" id="productdetails" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Product Details</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST" enctype="multipart/form-data">
                <div class="modal-body" id="showdetails">
                    

                </div>
                <div class="modal-footer">
                    <div class="" id="addtocartresponse"></div>
                    <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                    <span type="submit" class="btn btn-primary" id="addtocartbutton" onclick="productaddtocart();" name="save_pricing">Add to Sale</span>
                </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Cart Modal -->

    <!-- Cart Modal -->
    <div class="modal fade" id="cart" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Cart</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST" enctype="multipart/form-data">
                <div class="modal-body" id="viewcart">
                    <div class="row mb-2" id="response"></div>
                </div>
                
                <div class="modal-footer">
                    <div class="row">
                        <form action="" method="POST">
                            <div class="col-6">

                            <?php if($_SESSION["type"]=="customer") { ?>
                                <strong for="">Payment Details <span class="text-danger">*</span></strong>
                                <!-- <select name="paymentmode" onchange="paymentForm(this.value)" class="form-control" id=""> -->
                                <select name="paymentmode" class="form-control" id="">
                                    <option value="">Select Payment Mode</option>
                                    <option value="Advanced">Advanced</option>
                                    <option value="Credit">Credit</option>
                                </select>
                            <?php } else { ?>
                                 <strong for="">Payment Details <span class="text-danger">*</span></strong>
                                <select name="paymentmode" onchange="paymentForm(this.value)" class="form-control" id="">
                                    <option value="">Select Payment Mode</option>
                                    <option value="Credit" selected>Credit</option>
                                </select>
                                <?php } ?>    
                            </div>
                            <div class="col-6">
                                <button type="submit" class="btn btn-primary mt-3" name="placeorder" >Place Order</button>
                            </div>
                        </form>
                    </div>

                    <div class="col-12">
                    <div class="row">
                            <div id="paymentform" style="display:none;">
                                <form action="" method="POST" enctype="multipart/form-data">
                                    <br>
                                    <label for="">Payment Amount</label>
                                    <input type="number" class="form-control" name="amount" id="">
                                    <br>
                                    <label for="">Transaction ID</label>
                                    <input type="text" name="transaction_id" class="form-control" id="">
                                    <br>
                                    <label for="">upload Reciept</label>
                                    <input type="file" name="file" class="form-control" id="">
                                    <br>
                                    <button class="btn btn-sm btn-success" name="payment_details">Update Payment Details</button>
                                </form>
                            </div> 
                    </div>
                    </div>

                    <!-- <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button> -->
                </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Cart Modal -->

    <!-----Notify pop up -->

	<div class="modal fade" id="Notify" role="dialog" style="z-index: 9999;">
		<div class="modal-dialog modal-lg">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Notification Details</h4>
				</div>
				<div class="modal-body">
					<div class="row">
                        <div class="col-12">
                                <div id="notifyajax" style="max-height:70vh; overflow-y:scroll;">
                                    Notification Loading...
                                </div>
                        </div>
                    </div>
					

					<div class="modal-footer">

						<span class="btn btn-primary" data-dismiss="modal">Close</span>
					</div>
					<!--End Popup form content-->
				</div>
			</div>
		</div>
	</div>

    
    <!-----Notify pop up -->

<?php 
    include("init.php");

    // $table = "order_table_product as otp inner join placeorder as p otp.order_id=p.stockiest_order_id";
    $user_id = $_SESSION["user_id"]; 
    $role = $_SESSION["roll"]; 

    if($role == "4" || $role == "5" || $role == "6" || $role == "7" || $role == "9") 
    {
        $table = "customer_placeorder as p inner join customer as c on p.user_id=c.customer_id";
        $orders = find("all",$table,"*","where is_placed_order='Y' and p.user_id='$user_id' and p.user_role!='VetZone' group by p.customer_order_id order by p.customer_order_id desc",array());

    }
    else if($role == "10")
    {        
        $table = "placeorder as p inner join vetzone as c on p.user_id=c.vetzone_id";
        $orders = find("all",$table,"*","where is_placed_order='Y' and p.user_id='$user_id' and p.user_role='VetZone' order by p.stockiest_order_id desc ",array());
    }
    else {
        
        $table = "order_approval as op inner join placeorder as p on op.order_id=p.stockiest_order_id inner join customer as c on p.user_id=c.customer_id";
        $orders = find("all",$table,"*","where is_placed_order='Y' and p.user_id='$user_id' group by op.order_id order by p.stockiest_order_id desc",array());
    }
    
    
?>
<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Coorder_approvalmpatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SCM | Vetrina</title>
    <!-- Favicon icon -->
    <?php include("csslink.php"); ?>
</head>
<body>
   <?php include("preloader.php") ?>

    <div id="main-wrapper">
        <?php include("navbar.php"); ?>
        <?php include("chatbox.php"); ?>		
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        <!-----maincontent start----->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table bordered id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Customer Name</th>
                                                <th>Customer Role</th>
                                                <th>Order Date</th>
                                                <th>Status</th>
                                                <th>Dispatch Date</th>
                                                <th>Action</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                
                                                $i=0; foreach($orders as $key=>$val) { $i++;
                                                
                                                    $order_date = $val["created_date"];
                                                    $date = date("d-m-Y",strtotime($order_date));
                                            ?>
                                            <tr>
                                                <td><?=$i?></td>
                                                <td><?=$val["name"]?></td>
                                                <td><?=$val["user_role"]?></td>
                                                <td><?=$date?></td>
                                                <td>
                                                    <?php if($val["status"]=="P") {
                                                        echo "<label class='label label-warning'>Pending</label>";
                                                    }
                                                    else if($val["status"]=="N")
                                                    {
                                                        echo "<label class='label label-danger'>Cancelled</label>";
                                                    }
                                                    else if($val["status"]=="Y")
                                                    {
                                                        echo "<label class='label label-success'>Order Dispatched</label>";
                                                    }
                                                    else if($val["status"]=="I")
                                                    {
                                                        echo "<label class='label label-info'>In Process</label>";
                                                    }
                                                    else if($val["status"]=="D")
                                                    {
                                                        echo "<label class='label label-success'>Dilivered</label>";
                                                    }
                                                    ?>
                                                </td>
                                                 <td>
                                                    <?php if($val["status"]=="Y") { 
                                                        $order_id = $val["stockiest_order_id"];
                                                        $tbl = "placeorder as p inner join order_approval as ap on p.stockiest_order_id=ap.order_id";
                                                        $finddate = find("first",$tbl,"*","where ap.order_id='$order_id' and ap.action='Approve' order by order_approval_id desc",array());
                                                        
                                                        $disdate = date("d-m-Y  H:i",strtotime($finddate["on_date"]));
                                                        echo $disdate;
                                                         } else { ?>
                                                        Not Dispatched.
                                                      <?php } ?>      
                                                </td>
                                                <td>
                                                     <div class="d-flex">
                                                        <form action="" method="POST">
                                                            <?php if($role == "4" || $role == "5" || $role == "6" || $role == "7" || $role == "9") { ?>
                                                                <input type="text" name="order_id" hidden value="<?=$val["customer_order_id"]?>" id="">
                                                                <span type="submit" name="view_details" onclick="view_customer_order_details('<?=$val['customer_order_id']?>')"  class="btn btn-info shadow btn-xs sharp"><i class="fa fa-eye"></i></span>
                                                            <?php } else { ?>
                                                                <input type="text" name="order_id" hidden value="<?=$val["stockiest_order_id"]?>" id="">
                                                                <span type="submit" name="view_details" onclick="view_order_details('<?=$val['stockiest_order_id']?>')"  class="btn btn-info shadow btn-xs sharp"><i class="fa fa-eye"></i></span>
                                                             <?php } ?>
                                                            </form>
                                                            <span onclick="editorders(<?=$val['stockiest_order_id']?>)" class="btn btn-primary shadow btn-xs sharp mr-2"><i class="fa fa-pencil"></i></span>
                                                    </div>
                                                </td>
                                                
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>        
                            </div>
                        </div>            
                    </div>            
                </div>            
            </div>            
        </div>            
        <!-------main content end----->
        

         <!-- Order Modal -->
    <div class="modal fade ordersdetails" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Order Details</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form action="" method="POST">
                    <div class="modal-body" id="order_details">
                        
                        
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- order Modal -->

    <!-- Lr Details Modal -->
    <div class="modal fade lrdetails" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header"> 
                    <h5 class="modal-title">LR Details</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                    
                    <div class="modal-body" id="lrdetails">
                        
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                        <span  onclick="verifylr();" class="btn btn-primary" name="verifylrno">Verify LR Details</span>
                    </div>

            </div>
        </div>
    </div>

    <!-- Lr Details Modal -->

        <?php include("footer.php"); ?>
    </div>
        <?php include("jslink.php"); ?>

        <script>

            function view_order_details(order_id)
            {
                $(".ordersdetails").modal("show");

                $.ajax(
                {
                     url:"ajax/get_order_details.php",
                     method:"POST",
                     data:{order_id:order_id}

                }).done(function(response){
                    $("#order_details").html(response);
                });
            }
           
            function view_customer_order_details(order_id)
            {
                $(".ordersdetails").modal("show");

                $.ajax(
                {
                    <?php if($role == "4" || $role == "5" || $role == "6" || $role == "7" || $role == "9") { ?>
                        url:"ajax/get_customer_to_customer_order_details.php",
                    <?php } else { ?>
                        url:"ajax/get_customer_order_details.php",
                    <?php } ?>    
                     method:"POST",
                     data:{order_id:order_id}

                }).done(function(response){
                    $("#order_details").html(response);
                });
            }

            function getmrprate(product_id,batch,row)
            {
                $.ajax({
                    url:"ajax/getitemrates.php",
                    method:"POST",
                    data:{product_id:product_id, batch:batch, row:row }
                }).done(function(response){
                     var data = JSON.parse(response);
                     $("#mrp"+row).val(data['mrp']);
                     $("#rate"+row).val(data['rate']);
                });
            }

            function editorders(order_id)
            {
                $(".lrdetails").modal("show");

                $.ajax({
                    url:"ajax/lrdetails.php",
                    method:"POST",
                    data:{ order_id:order_id }
                }).done(function(response){
                    $("#lrdetails").html(response);
                });

                // $("#order_id").val(order_id);
            }

            function verifylr()
            {
                var lrno = $("#lrno").val();
                var orderid = $("#order_id").val();
                $.ajax({
                        url:"ajax/verify_lr_details.php",
                        method:"POST",
                        data:{lrno:lrno,orderid:orderid}
                }).done(function(response){
                    $("#response").html(response);
                });
            }

        </script>
    </body>
</html>
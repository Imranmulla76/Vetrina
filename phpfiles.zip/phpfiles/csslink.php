    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link rel="stylesheet" href="./vendor/chartist/css/chartist.min.css">
    <link href="./vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
	<link href="./vendor/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link href="./vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
    <!-- Custom Stylesheet -->
    <link href="./vendor/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    <!-- <link rel="stylesheet" href="./vendor/toastr/css/toastr.min.css"> -->
    
    <!-- NEW BY TUSH -->
    
    <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css"> -->
    
    <!-- cdn databales for EXCEL Download added by Shruti-->
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.2/css/buttons.dataTables.min.css">
    
    
    <style>
        .btn-primary
        {
            background-color:#a2228e;
            border-color: #fcfafb;
        }
        .loader-text-animation
        {
            color:red ;
            animation: colorchangeanime 1s ease infinite;
        }

        @keyframes colorchangeanime {
        0% {
            color:red !important;
        }
        25% {
            color:blue !important;
        }
        50% {
            color:blueviolet !important;
        }
        75% {
            color:violet !important;
        }
        100% {
            color:red !important;
        }
    }

    .form-control 
    {
        border-radius: 1.25rem;
        background: #fff;
        border: 1px solid #f0f1f5;
        color: #000000;
        height: 56px;
    }

    /* for links provided in reports datatables */
    .clickable {
        color: #1a0dab;
    }

    .clickable:hover {
        /* background-color: yellow; */
        cursor: pointer;
    }
    </style>
    
<?php 
    include("init.php");

    $order_id=$_GET["order_id"];
    $vetzone_id = $_SESSION["user_id"];
    $type = $_SESSION["type"];

    $vetzone_meta = find("all","vetzone_meta","*","where vetzone_id='$vetzone_id'",array());
    $vetzonedetails = find("first","vetzone","*","where vetzone_id='$vetzone_id'",array());

    foreach($vetzone_meta as $key=>$val)
    {
        if($val["vetzone_meta_value"]!="")
        {
            define($val["vetzone_meta_key"],$val["vetzone_meta_value"]);
        }
        else
        {
            define($val["vetzone_meta_key"],"0");
        }
    }
   
    $table = "customer_order_table_product as otp inner join customer_placeorder as p on otp.order_id=p.customer_order_id inner join product as pd on otp.product_id=pd.product_id inner join vetzone_end_customer as c on otp.customer_id=c.end_customer_id";
    $order_details = find("all",$table,"*","where otp.order_id='$order_id'",array());

    $getcustomer = find("first","customer_order_table_product as cotp inner join vetzone_end_customer as c on cotp.customer_id=c.end_customer_id","*","where order_id='$order_id'",array());
    $customer_id = $getcustomer["customer_id"];
    

?>



<!DOCTYPE html>
<html>

<head>
  <title>Vetzone POS Bill</title>
   <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->
  <style>
    /* CSS styles */
    body {
      font-family: Arial, sans-serif;
      margin: 10px;
      padding: 0px;
    }

    .container {
      max-width: 207.87px;
      /* margin: 4px; */
      padding: 10px;
    }

    .bill-table {
      width: 207.87px;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    .bill-table th,
    .bill-table td {
      border: 0px solid #ddd;
      padding: 0px;
    }

    .lineonly{
        border-top: 1px solid #320909 !important;
        border-bottom: 1px solid #320909 !important;
        font-size: 9px;
        width: 0px !important;
        /* padding: 5px !important; */

    }

    .btn
    {
      width: 100px;
      height: 32px;
      background-color: #FF9800;
      font-size: large;
      font-weight: 700;
    }
    

   /*  .qtyonly
    {
       border-top: 1px solid #320909 !important;
        border-bottom: 1px solid #320909 !important;
        font-size: 9px;
        width: 0px !important;
        padding: 3px !important;
      }
 */

    .bill-table th {
      background-color: #f2f2f2;
    }

    .total {
      font-weight: bold;
       font-size: 13px;
    }

    .sizeacco{
        font-size: 9px;
        padding-top: 3px !important;
        padding-bottom: 3px !important;
    }

    @media screen and (max-width: 600px) {
      /* Responsive styles */
      .bill-table {
        font-size: 12px;
      }
    }
  </style>
</head>

<body>
  <div id="temp-target">

  <div class="container">
    <h5 style="text-align: center;">Vetrina Helthcare Pvt Ltd</h5>
    <h6 style="text-align: center; margin-top: -15px;">GST IN: 27AAECV1226C1ZR</h6>
    <h4 style="text-align: center; margin-top: -15px;"><?=$vetzonedetails["name"]?></h4>
    <h5 style="text-align: center; margin-top: -15px;">Phone: <?=mob_no?></h5>
    <hr>
    <h3 style="text-align: center; margin-top: -5px;">Sales Bill</h3>
    <p style="font-size: 12px;">Date: 19 May 2023 / 03;15;28 PM</p>
    <p style="font-size: 12px;">Bill No.:<?=$order_id?></p>
    <p style="font-size: 12px;">Customer: <?=$getcustomer["name"]?></p>
    <p style="font-size: 12px;">Mob No.: <?=$getcustomer["mobile"]?></p>
    <table class="bill-table">
      <tr>
        <th class="lineonly">Particulars</th>
        <th class="lineonly">Qty</th>
        <th class="lineonly">Rate</th>
        <th class="lineonly">Amount</th>
      </tr>
      <?php 
        $totalamount = 0;
        foreach($order_details as $key=>$val) { 
        $amount = $val["quantity"]*$val["rate"];
      ?>
      <tr>
        <td class="sizeacco"><?=$val["product_name"]?> <?=$val["sku"]?> HSN: <?=$val["hsn_code"]?></td>
        <td class="sizeacco"><?=$val["quantity"]?></td>
        <td class="sizeacco"><?=$val["rate"]?></td>
        <td class="sizeacco"><?=$amount?></td>
      </tr>
      <?php $totalamount += $amount; } ?>
        
      <tr>
        <td><h4>Total Amt:</h4></td>
        <td colspan="3"><h4>Rs.<?=$totalamount?>/-</h4></td>
        <!-- <td></td> -->
      </tr> 
      
    </table>
    <!-- <p style="text-align: center; font-size: 12px;">GST Breakup Details</p> -->
    
        <!-- <p style="font-size: 12px;">Cash: Rs. <?=$taxable_amt?> </p> -->
        <p style="font-size: 12px;">Customer Care No.8600844450</p>
        <hr>

        <div style="display: flex; justify-content: space-between;">
            <p style="font-size: 12px;">Thank You</p>
            <p style="font-size: 12px;">Visit Again</p>
        </div>
        
    </div>
  </div>
    <button class="btn" onclick="converHTMLFileToPDF()">Print Bill</button>

     <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.3.1/jspdf.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.0/html2canvas.min.js" integrity="sha512-UcDEnmFoMh0dYHu0wGsf5SKB7z7i5j3GuXHCnb3i4s44hfctoLihr896bxM0zL7jGkcHQXXrJsFIL62ehtd6yQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>

        function converHTMLFileToPDF() 
        {
            const { jsPDF } = window.jspdf;
            var doc = new jsPDF('l', 'mm', [1800 , 1210]);

            var pdfjs = document.querySelector('#temp-target');

            // Convert HTML to PDF in JavaScript
            doc.html(pdfjs, {
                callback: function(doc) {
                    doc.save("VetZone Bill.pdf");
                },
                x: 1,
                y: 2
            });

            window.print();
        }
  </script>
</body>

</html>
